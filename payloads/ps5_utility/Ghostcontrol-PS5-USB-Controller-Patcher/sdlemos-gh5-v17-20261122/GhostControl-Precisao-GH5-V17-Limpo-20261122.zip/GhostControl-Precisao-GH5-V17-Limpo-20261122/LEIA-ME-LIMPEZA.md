# Distribuição de fontes V16

Esta distribuição preserva a implementação V16 Precisão e seus testes. Comentários técnicos foram revisados para objetividade; não há mudança deliberada na lógica do runtime. Veja `LEIA-PRIMEIRO-V16.md` para compilação e uso.

Os históricos de V12 a V16, arquivos de captura e ELFs originais estão em um ZIP de preservação separado. Nenhum ELF novo foi compilado nesta edição.

O relatório completo está em `RELATORIO-TECNICO-V16-LIMPO.md`. A lista de arquivos do pacote é verificada por `INVENTARIO-V16-LIMPO-SHA256.txt`.
