/* Host-only FreeBSD USB definitions used by the production descriptor reader. */
#pragma once
#include <stdint.h>
typedef uint8_t uWord[2];
#define UGETW(w) ((uint16_t)((w)[0] | ((w)[1] << 8)))
#define USETW(w, v) ((w)[0] = (uint8_t)(v), (w)[1] = (uint8_t)((v) >> 8))
struct usb_device_descriptor {uWord idVendor, idProduct, bcdDevice;};
struct usb_gen_descriptor {void *ugd_data; uint32_t ugd_maxlen, ugd_actlen; uint8_t ugd_config_index, ugd_iface_index;};
struct usb_ctl_request {void *ucr_data; int ucr_flags, ucr_actlen; struct {uint8_t bmRequestType,bRequest;uWord wValue,wIndex,wLength;} ucr_request;};
struct usb_fs_endpoint {void **ppBuffer;uint32_t *pLength; uint32_t nFrames,aFrames;uint16_t flags,timeout;int status;};
struct usb_fs_uninit {int reserved;};
struct usb_fs_init {struct usb_fs_endpoint *pEndpoints; int ep_index_max;};
struct usb_fs_open {int ep_index,ep_no,max_bufsize,max_frames,max_packet_length;};
struct usb_fs_start {uint8_t ep_index;};
struct usb_fs_stop {uint8_t ep_index;};
struct usb_fs_complete {uint8_t ep_index;};
enum {USB_GET_REPORT_DESC=0x7501,USB_DO_REQUEST,USB_GET_DEVICE_DESC,USB_GET_CONFIG,USB_GET_FULL_DESC,USB_FS_START,USB_FS_STOP,USB_FS_COMPLETE,USB_FS_INIT,USB_FS_UNINIT,USB_FS_OPEN,USB_IFACE_DRIVER_DETACH};
#define USB_SHORT_XFER_OK 1
#define USB_FS_FLAG_SINGLE_SHORT_OK 1
#define USB_FS_FLAG_MULTI_SHORT_OK 2
