/* SPDX-License-Identifier: GPL-3.0-or-later */
/* PR34 4fcb1fb, adapted: production parser vs hardware-capture-derived
 * arrays, motor masks, sustained output and error bounds. No PS5 attached. */
#include <stdint.h>
#include <stddef.h>
#include <stdio.h>
#include <string.h>
#include "vpad_rumble_rs.h"
static int failures;
static void check(const char *name,int ok){
 printf("%s %s\n",ok?"PASS":"FAIL",name);failures+=!ok;
}
static int eq(const uint8_t *buf,size_t len,int large,int small){
 uint8_t a=0xaa,b=0xaa;
 return vpad_rs_decode(buf,len,&a,&b)&&a==(uint8_t)large&&b==(uint8_t)small;
}
/* Four real hardware capture shapes shared by the new PR34 response. */
static const uint8_t cap_idle[256]={
 0,0,0,0,0,0,0,0,0,3,5,0,0,0,0,0,0,0,0,0,0,5,0};
static const uint8_t cap_strong[256]={
 0,0,0,0,0,0,0,0,0,3,0x25,0x14,0,3,0,0,0,0,0,0,0,5,0};
static const uint8_t cap_both[256]={
 0,0,0,0,0,0,0,0,0,3,0x25,0x14,0,3,0,0,0,0,0,0,0,0x25,0x14};
static const uint8_t cap_max[256]={
 0,0,0,0,0,0,0,0,0,3,0x21,0xff,3,0xff,0xff,0xff,0x3f,0,0,0,0,0x21,0xff,3,0xff,0xff,0xff,0x3f};
int main(void){
 uint8_t x[256]={0};uint8_t a=0xaa,b=0xaa;
 check("capture idle",eq(cap_idle,256,0,0));
 check("capture strong 20",eq(cap_strong,256,20,0));
 check("capture both 20",eq(cap_both,256,20,20));
 check("capture max 255",eq(cap_max,256,255,255));
 x[10]=5;x[21]=5;x[13]=0;x[14]=0;x[15]=0x40;
 check("lightbar 00 00 40 only",eq(x,256,0,0));
 x[13]=0xff;x[14]=0;x[15]=0;
 check("lightbar ff 00 00 only",eq(x,256,0,0));
 x[1]=3;
 check("flag byte[1]=3 only",eq(x,256,0,0));
 x[11]=0xff;x[22]=0x7f;
 check("stale motor values idle",eq(x,256,0,0));
 memset(x,0,sizeof x);x[10]=5;x[21]=0x25;x[22]=200;
 check("weak-only 200",eq(x,256,0,200));
 memset(x,0,sizeof x);x[10]=0x25;x[11]=150;x[21]=5;
 check("strong-only 150",eq(x,256,150,0));
 int held=1;
 for(int i=0;i<60;i++)if(!eq(cap_both,256,20,20))held=0;
 check("60 constant polls preserve sustained effect",held);
 memcpy(x,cap_both,sizeof x);x[13]=0x11;x[15]=0x40;
 check("rumble active while lightbar animates",eq(x,256,20,20));
 x[10]=5;x[21]=5;x[13]=0x22;x[15]=0x40;
 check("release during animation",eq(x,256,0,0));
 check("null buf fails",vpad_rs_decode(NULL,256,&a,&b)==0);
 check("short buffer fails",vpad_rs_decode(x,VPAD_RS_MIN_LEN-1,&a,&b)==0);
 check("failure leaves outputs unchanged",a==0xaa&&b==0xaa);
 check("exact minimum accepted",vpad_rs_decode(x,VPAD_RS_MIN_LEN,&a,&b)==1);
 check("strong pointer null fails",vpad_rs_decode(x,256,NULL,&b)==0);
 check("weak pointer null fails",vpad_rs_decode(x,256,&a,NULL)==0);
 printf("RUMBLE parser failures=%d\n",failures);
 return failures!=0;
}
