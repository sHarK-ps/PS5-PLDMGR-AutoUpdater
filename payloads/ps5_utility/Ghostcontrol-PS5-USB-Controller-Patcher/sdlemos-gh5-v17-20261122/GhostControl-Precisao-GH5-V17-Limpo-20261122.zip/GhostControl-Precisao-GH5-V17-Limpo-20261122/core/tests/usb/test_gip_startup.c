/* Production Xbox handshake validation against fake USB_FS endpoint pair.
 * Adapted for GH5 local worker & pending_input replay, not a console test. */
#include <errno.h>
#include <poll.h>
#include <pthread.h>
#include <stdatomic.h>
#include <stdio.h>
#include <string.h>
#include <sys/ioctl.h>
#include <time.h>
#include <unistd.h>
#include <dev/usb/usb_ioctl.h>

enum {PAD_STREAMING,PAD_ANNOUNCES,PAD_SILENT};
static int pad_mode;
static struct usb_fs_endpoint *endpoints;
static int started[2], stopped[2];
static pthread_mutex_t fake_mu=PTHREAD_MUTEX_INITIALIZER;
static const uint8_t held_input[18]={0x20,0x01,0x00,0x0e,0x10,0x10};
static const uint8_t announce[4]={0x02,0x09,0x00,0x00};
static int complete_one(struct usb_fs_complete *done,int idx,int status){
 started[idx]=stopped[idx]=0;done->ep_index=(uint8_t)idx;
 endpoints[idx].status=status;endpoints[idx].aFrames=1;return 0;
}
static int fake_ioctl(int fd,unsigned long request,void *argument){
 int rc=-1;(void)fd;pthread_mutex_lock(&fake_mu);
 if(request==USB_FS_START){started[((struct usb_fs_start*)argument)->ep_index]=1;rc=0;}
 else if(request==USB_FS_STOP){int idx=((struct usb_fs_stop*)argument)->ep_index;
   if(started[idx]) stopped[idx]=1;
   rc=0;}
 else if(request==USB_FS_COMPLETE){
  struct usb_fs_complete*done=argument;
  if(started[1]||stopped[1])rc=complete_one(done,1,stopped[1]?5:0);
  else if(stopped[0])rc=complete_one(done,0,5);
  else if(started[0]&&pad_mode!=PAD_SILENT){
    const uint8_t*packet=pad_mode==PAD_STREAMING?held_input:announce;
    uint32_t len=pad_mode==PAD_STREAMING?sizeof held_input:sizeof announce;
    memcpy(endpoints[0].ppBuffer[0],packet,len);
    endpoints[0].pLength[0]=len;rc=complete_one(done,0,0);
  }else errno=EBUSY;
 }
 pthread_mutex_unlock(&fake_mu);return rc;
}
#define ioctl fake_ioctl
#include "../../src/controller_xbox.c"
#undef ioctl
static int failures;
#define CHECK(x)do{int ok_=(x);printf("%s %s\n",ok_?"PASS":"FAIL",#x);failures+=!ok_;}while(0)
static long now_ms(void){struct timespec ts;clock_gettime(CLOCK_MONOTONIC,&ts);
 return ts.tv_sec*1000L+ts.tv_nsec/1000000L;}
typedef struct {int fd;struct usb_fs_endpoint ep[2];XboxControllerState xbox;} FakeFeed;
static void reset(FakeFeed*f,int mode,int fd){memset(f,0,sizeof *f);
 memset(started,0,sizeof started);memset(stopped,0,sizeof stopped);
 f->fd=fd;f->xbox.out_available=1;endpoints=f->ep;pad_mode=mode;}
static _Atomic int worker_continue;
static int keep_running(void*unused){(void)unused;return atomic_load(&worker_continue);}
static void*worker(void*arg){FakeFeed*f=arg;
 int rc=xbox_gip_handshake(f->fd,f->ep,0x045e,0x0b12,&f->xbox,keep_running,NULL);
 return (void*)(intptr_t)rc;}
int main(void){
 static FakeFeed feed;uint8_t report[64];ScePadData pad;int pipe_fds[2];
 pthread_t thread;void*result=NULL;pthread_mutex_t dispatch=PTHREAD_MUTEX_INITIALIZER;
 if(pipe(pipe_fds))return 2;
 reset(&feed,PAD_STREAMING,pipe_fds[0]);
 CHECK(xbox_gip_handshake(feed.fd,feed.ep,0x045e,0x0b12,&feed.xbox,NULL,NULL)==1);
 CHECK(feed.xbox.pending_input_valid==1);
 CHECK(feed.xbox.pending_input_length==sizeof held_input);
 CHECK(xbox_take_initial_report(&feed.xbox,report,sizeof report)==sizeof held_input);
 CHECK(xbox_take_initial_report(&feed.xbox,report,sizeof report)==0);
 memset(&pad,0,sizeof pad);
 CHECK(xbox_handle_packet(feed.fd,feed.ep,report,sizeof held_input,&pad,&feed.xbox)==1);
 CHECK((pad.buttons&SCE_PAD_BUTTON_CROSS)!=0);
 CHECK((pad.buttons&SCE_PAD_BUTTON_L1)!=0);
 CHECK(feed.xbox.input_count==1);CHECK(feed.xbox.cached_pad_valid==1);
 CHECK(feed.xbox.pending_input_valid==0);
 reset(&feed,PAD_ANNOUNCES,pipe_fds[0]);
 CHECK(xbox_gip_handshake(feed.fd,feed.ep,0x045e,0x0b12,&feed.xbox,NULL,NULL)==1);
 CHECK(feed.xbox.pending_input_valid==0);
 /* Same real handshake invoked on a worker: 8ms tick must keep progressing. */
 reset(&feed,PAD_SILENT,pipe_fds[0]);atomic_store(&worker_continue,1);
 long start=now_ms(),previous=start,worst_gap=0,passes=0;
 CHECK(pthread_create(&thread,NULL,worker,&feed)==0);
 while(now_ms()-start<500){pthread_mutex_lock(&dispatch);++passes;
 pthread_mutex_unlock(&dispatch);usleep(8000);
 long now=now_ms();if(now-previous>worst_gap)worst_gap=now-previous;
 previous=now;}
 CHECK(passes>=40);CHECK(worst_gap<50);
 CHECK(pthread_join(thread,&result)==0);
 CHECK((intptr_t)result==0);
 CHECK(now_ms()-start>=1400);CHECK(now_ms()-start<2600);
 /* Cancellation must be polled by the real handshake. */
 reset(&feed,PAD_SILENT,pipe_fds[0]);atomic_store(&worker_continue,1);
 CHECK(pthread_create(&thread,NULL,worker,&feed)==0);
 usleep(150000);start=now_ms();atomic_store(&worker_continue,0);
 CHECK(pthread_join(thread,&result)==0);
 CHECK((intptr_t)result==-ECANCELED);CHECK(now_ms()-start<300);
 close(pipe_fds[0]);close(pipe_fds[1]);
 printf("GIP host test failures=%d\n",failures);return failures!=0;
}
