/* Host-only stand-in; no PS5 ABI claims. */
#pragma once
