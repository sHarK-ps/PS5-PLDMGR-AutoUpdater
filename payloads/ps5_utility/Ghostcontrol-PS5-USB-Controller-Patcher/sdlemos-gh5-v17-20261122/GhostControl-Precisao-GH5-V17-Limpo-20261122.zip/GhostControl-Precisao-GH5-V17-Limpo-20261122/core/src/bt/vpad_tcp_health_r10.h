/* SPDX-License-Identifier: GPL-3.0-or-later */
#pragma once
#include <stdint.h>
/* TCP source observability, not a verdict on VDA device creation. */
typedef enum {
    GC_VPAD_TCP_R10_READ_ERROR,
    GC_VPAD_TCP_R10_EOF,
    GC_VPAD_TCP_R10_NO_BYTES,
    GC_VPAD_TCP_R10_PRE_ONLY,
    GC_VPAD_TCP_R10_LIVE_ONLY,
    GC_VPAD_TCP_R10_PRE_AND_LIVE
} GcVpadTcpHealthR10;
static inline GcVpadTcpHealthR10 gc_vpad_tcp_health_r10(
    uint64_t pre_bytes, uint64_t live_bytes, int eof, int read_errno)
{
    if (read_errno) return GC_VPAD_TCP_R10_READ_ERROR;
    if (eof) return GC_VPAD_TCP_R10_EOF;
    if (!pre_bytes && !live_bytes) return GC_VPAD_TCP_R10_NO_BYTES;
    if (pre_bytes && !live_bytes) return GC_VPAD_TCP_R10_PRE_ONLY;
    if (!pre_bytes && live_bytes) return GC_VPAD_TCP_R10_LIVE_ONLY;
    return GC_VPAD_TCP_R10_PRE_AND_LIVE;
}
static inline const char *gc_vpad_tcp_health_name_r10(GcVpadTcpHealthR10 r)
{
    switch (r) {
    case GC_VPAD_TCP_R10_READ_ERROR: return "READ_ERROR";
    case GC_VPAD_TCP_R10_EOF: return "EOF";
    case GC_VPAD_TCP_R10_NO_BYTES: return "TCP_CONNECTED_NO_BYTES";
    case GC_VPAD_TCP_R10_PRE_ONLY: return "TCP_BYTES_BEFORE_ONLY";
    case GC_VPAD_TCP_R10_LIVE_ONLY: return "TCP_BYTES_AFTER_ADD_ONLY";
    case GC_VPAD_TCP_R10_PRE_AND_LIVE: return "TCP_BYTES_BEFORE_AND_AFTER";
    }
    return "INVALID";
}
