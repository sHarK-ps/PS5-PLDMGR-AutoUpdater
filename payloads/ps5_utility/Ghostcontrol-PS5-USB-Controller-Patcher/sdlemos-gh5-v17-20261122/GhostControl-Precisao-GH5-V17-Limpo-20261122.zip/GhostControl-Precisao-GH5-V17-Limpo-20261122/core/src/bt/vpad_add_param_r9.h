/* SPDX-License-Identifier: GPL-3.0-or-later */
#pragma once
#include <stdint.h>
/* Keep the R8 sentinel in Conservador; use zeroed reserved fields only in the
 * controlled Precision R9 experiment.  Never guess a virtual-pad handle. */
#ifndef GC_GH5_VDA_ZERO_RESERVED
#define GC_GH5_VDA_ZERO_RESERVED 0
#endif
static inline void gc_vpad_prepare_add_param_r9(int32_t param[8], int zero_reserved)
{
    int i;
    for (i = 0; i < 8; ++i)
        param[i] = zero_reserved ? 0 : (int32_t)0xDEADBEEFu;
    param[0] = 32;
    param[1] = 1; /* unassigned user, not the signed-in account */
}
