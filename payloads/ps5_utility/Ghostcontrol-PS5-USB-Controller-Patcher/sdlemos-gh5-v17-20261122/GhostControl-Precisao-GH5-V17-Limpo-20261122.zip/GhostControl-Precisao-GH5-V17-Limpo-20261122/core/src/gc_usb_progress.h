/* SPDX-License-Identifier: GPL-3.0-or-later */
#pragma once
#include <stdint.h>
#include "gc_usb_decode_result.h"

/* GH5-only receive diagnostics. Never triggers a USB reset or pad publication. */
typedef struct {
    uint64_t generation, opened_ms, started_ms, completed_ms, input_ms, sampled_ms;
    uint64_t sampled_inputs;
    uint64_t starts, completions, busy_returns, other_errors, inputs, decoded, rejected;
    uint64_t endpoint_errors, frame_rejections;
    /* GH5 diagnostic observation: raw-only capture and neutral VDA probe are
     * not decoder failures or decoded physical controls. */
    uint64_t raw_only_skipped, neutral_probe_frames;
    /* Public GH5 test variants: decoder attempts are distinct from transport. */
    uint64_t decode_attempts, skipped, neutral_probes;
    int have_completion, have_input, have_sample, outstanding, suspect, poll_revents;
} GcUsbProgress;

static inline uint64_t gc_usb_progress_age(uint64_t now, uint64_t then)
{ return now >= then ? now - then : 0; }
static inline void gc_usb_progress_start(GcUsbProgress *p, uint64_t now)
{ ++p->starts; p->started_ms = now; p->outstanding = 1; }
static inline void gc_usb_progress_complete(GcUsbProgress *p, uint64_t now)
{ ++p->completions; p->completed_ms = now; p->have_completion = 1; p->outstanding = 0; }
static inline void gc_usb_progress_input(GcUsbProgress *p, uint64_t now)
{ ++p->inputs; p->input_ms = now; p->have_input = 1; }
static inline int gc_usb_progress_due(GcUsbProgress *p, uint64_t now)
{ if (p->have_sample && gc_usb_progress_age(now, p->sampled_ms) < 1000) return 0;
  p->have_sample = 1; p->sampled_ms = now; return 1; }
static inline int gc_usb_progress_suspect(const GcUsbProgress *p, uint64_t now)
{ return p->outstanding && gc_usb_progress_age(now, p->started_ms) >= 1000 &&
  gc_usb_progress_age(now, p->have_completion ? p->completed_ms : p->opened_ms) >= 1000; }

/* Distinguishes intentional GH5 RAW capture / neutral probe from a real HID
 * decoder outcome. Call only after the transport has delivered valid input. */
static inline void gc_usb_progress_account(GcUsbProgress *p,
                                            int gh5_diagnostic, int accepted)
{
    if (gh5_diagnostic) {
        if (accepted) ++p->neutral_probe_frames;
        else ++p->raw_only_skipped;
    } else {
        if (accepted) ++p->decoded;
        else ++p->rejected;
    }
}

/* Public #29 dispatch accounting. Private GH5 diagnostic uses the separate
 * gc_usb_progress_account helper above to retain its historical log schema. */
static inline int gc_usb_progress_decode(GcUsbProgress *p, int result)
{
    switch (result) {
    case GC_USB_DECODE_SKIPPED: ++p->skipped; return 0;
    case GC_USB_DECODE_NEUTRAL_PROBE: ++p->neutral_probes; return 1;
    case GC_USB_DECODE_CONTROLS: ++p->decode_attempts; ++p->decoded; return 1;
    default: ++p->decode_attempts; ++p->rejected; return 0;
    }
}
