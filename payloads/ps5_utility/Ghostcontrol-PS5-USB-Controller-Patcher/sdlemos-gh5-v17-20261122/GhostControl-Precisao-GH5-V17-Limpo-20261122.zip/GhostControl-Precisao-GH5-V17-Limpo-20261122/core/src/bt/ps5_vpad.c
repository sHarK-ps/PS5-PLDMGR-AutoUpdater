#include "ps5_vpad.h"
#include "vpad_klog_evidence_r8.h"
#include "vpad_tcp_health_r10.h"
#include "vpad_add_param_r9.h"
#include "vpad_trace_gate_r9.h"
#include "host.h"
#include "log.h"
#include "util.h"
#ifndef GC_VPAD_RUMBLE_READBACK
#define GC_VPAD_RUMBLE_READBACK 0
#endif
#if GC_VPAD_RUMBLE_READBACK
#include "vpad_rumble_rs.h"
#endif

#include <sys/stat.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#include <ctype.h>
#include <dlfcn.h>
#include <errno.h>
#include <fcntl.h>
#include <stdarg.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

/* ---- ScePadData ------------------------------------------------------------
 *
 * As PS4/PS5 software sees it: 120 bytes, with acceleration before
 * angular velocity. */

typedef struct {
    uint16_t x, y;
    uint8_t  id;
    uint8_t  reserved[3];
} ScePadTouch;

typedef struct {
    uint8_t  touchNum;
    uint8_t  reserved[3];
    uint32_t reserved2;
    ScePadTouch touch[2];
} ScePadTouchData;

typedef struct {
    uint32_t buttons;
    uint8_t  lx, ly, rx, ry;
    uint8_t  l2, r2;
    uint8_t  padding[2];
    float    orientation[4];        /* x, y, z, w */
    float    acceleration[3];       /* g */
    float    angularVelocity[3];    /* rad/s */
    ScePadTouchData touchData;
    uint8_t  connected;
    uint64_t timestamp;             /* microseconds */
    uint8_t  extensionUnitData[16];
    uint8_t  connectedCount;
    uint8_t  reserved[2];
    uint8_t  deviceUniqueDataLen;
    uint8_t  deviceUniqueData[12];
} ScePadData;

_Static_assert(sizeof(ScePadData) == 120, "ScePadData must be 120 bytes");
_Static_assert(offsetof(ScePadData, touchData) == 52, "touch data offset");
_Static_assert(offsetof(ScePadData, timestamp) == 80, "timestamp offset");

/* ---- system interfaces --------------------------------------------------- */

#define VIRTUAL_DEVICE_DUALSENSE 3

int32_t sceUserServiceInitialize(void *params);
int32_t sceUserServiceGetInitialUser(int32_t *user);
int32_t sceUserServiceGetForegroundUser(int32_t *user);
int32_t sceUserServiceGetLoginUserIdList(int32_t list[4]);
int32_t scePadInit(void);
int32_t scePadSetProcessPrivilege(int32_t privilege);
int32_t scePadGetHandle(int32_t user, int32_t type, int32_t index);
int32_t scePadOpen(int32_t user, int32_t type, int32_t index, const void *param);
int32_t scePadClose(int32_t handle);
int32_t scePadReadState(int32_t handle, ScePadData *data);
int32_t scePadVirtualDeviceAddDevice(void *param, int32_t deviceType);
int32_t scePadVirtualDeviceInsertData(int32_t handle, const void *data);
int32_t scePadVirtualDeviceDeleteDevice(int32_t handle);
#if GC_VPAD_RUMBLE_READBACK
/* PR34: only the libScePad stub has been shown to export this name.
 * Declaration/ABI on PS5 FW11.60 remains unverified; default feature OFF. */
int32_t scePadVirtualDeviceGetRemoteSetting(int32_t handle, void *data, uint64_t size);
#endif

/* From the payload SDK (ps5/kernel.h). */
uint64_t kernel_get_ucred_authid(pid_t pid);
int32_t  kernel_set_ucred_authid(pid_t pid, uint64_t authid);
int32_t  kernel_get_ucred_caps(pid_t pid, uint8_t caps[16]);
int32_t  kernel_set_ucred_caps(pid_t pid, const uint8_t caps[16]);

typedef int32_t (*mbus_bind_fn)(uint64_t device_id, int32_t user);

typedef struct {
    char reserved[45];
    char message[3075];
} notify_request;

int sceKernelSendNotificationRequest(int, notify_request *, size_t, int);

/* ---- state ------------------------------------------------------------------ */

#define T_IDENTIFY      3000    /* AddDevice to its DEVICE_ADDED line */
#define T_AMBIGUITY      300    /* after a match, watch for a second one */
#define T_TCP_PREFLIGHT_DEADLINE 2500
#define LINE_MAX_LEN    1024

/* PREFLIGHT has only an opened log socket: AddDevice has NOT been called. */
         enum { VP_FREE, VP_QUEUED, VP_PREFLIGHT, VP_PENDING, VP_READY, VP_FAILED, VP_UNCERTAIN, VP_DELETE_FAILED };

/* GH5 R6: observation only. Never infer a handle or reset a quarantined slot.
 * Transitions and low-frequency snapshots distinguish queued, failed and
 * ambiguous virtual-device states without changing lifecycle semantics. */
#ifndef GC_VPAD_TEST_TRACE
#define GC_VPAD_TEST_TRACE 0
#endif
#if GC_VPAD_TEST_TRACE
static const char *gc_vpad_state_name(int st)
{
    switch (st) {
    case VP_FREE: return "FREE";
    case VP_QUEUED: return "QUEUED";
    case VP_PREFLIGHT: return "PREFLIGHT";
    case VP_PENDING: return "PENDING";
    case VP_READY: return "READY";
    case VP_FAILED: return "FAILED";
    case VP_UNCERTAIN: return "UNCERTAIN";
    case VP_DELETE_FAILED: return "DELETE_FAILED";
    default: return "INVALID";
    }
}
#endif


typedef struct {
    int st;
    int remove_when_found;      /* removed while being identified */
    int32_t handle;
    uint64_t dev;
    uint32_t reject_count;      /* consecutive InsertData refusals (prompt rejects are transient) */
    int insert_confirmed;       /* first accepted InsertData, reset per virtual device */
    int add_attempted;          /* irreversible VDA attempt fence: no retry after API call */
} vslot;

static mbus_bind_fn g_bind;
static int g_ready;                         /* vpad_init succeeded */
static int32_t g_user = -1;
static vslot g_slot[HOST_MAX_PADS];

/* The identification under way: one at a time, so a DEVICE_ADDED line can
 * only belong to the device just asked for. */
static int g_pending = -1;
/* Pre-AddDevice TCP observation. A quiet TCP server is NOT considered broken:
 * no event may be emitted before AddDevice. This is evidence only. */
#ifndef GC_GH5_TCP_PREFLIGHT_MS
#define GC_GH5_TCP_PREFLIGHT_MS 0
#endif
#ifndef GC_GH5_TCP_ONLY
#define GC_GH5_TCP_ONLY 0
#endif
#if GC_GH5_TCP_PREFLIGHT_MS < 0 || GC_GH5_TCP_PREFLIGHT_MS > 1500
#error "GC_GH5_TCP_PREFLIGHT_MS must be between 0 and 1500"
#endif
static int g_preflight_slot = -1;
static long g_preflight_since_ms;
static uint64_t g_pre_bytes, g_pre_lines, g_pre_mbus, g_pre_added;
static long g_preflight_elapsed_ms;
static long g_t_add, g_t_match;
static int g_matches;
static uint64_t g_match_dev;
static int g_log_fd = -1, g_log_is_dev;
static int g_log_close_uncertain;
static char g_line[LINE_MAX_LEN];
static size_t g_line_len;
/* The MBus event is eligible only when a complete newline-terminated line fits. */
static int g_line_overflow;
static uint64_t g_line_dropped;
/* Per-AddDevice window counters: distinguish no kernel-log traffic from a
 * delivered event that the parser rejected. */
static uint64_t g_log_bytes, g_log_lines, g_log_mbus_events;
static uint64_t g_log_device_added;
static int g_log_eof, g_log_read_errno;
/* GH5 R8: measured only inside the AddDevice identification window. */
static long g_log_first_byte_ms = -1;
static long g_log_last_byte_ms = -1;
static int32_t g_add_result;
#if GC_VPAD_TEST_TRACE
static int g_trace_last_state[HOST_MAX_PADS];
static long g_trace_last_ms[HOST_MAX_PADS];
static long g_trace_last_quarantine_notice[HOST_MAX_PADS];
static void gc_vpad_trace_snapshot(long now)
{
    int i;
    for (i = 0; i < HOST_MAX_PADS; ++i) {
        const vslot *v = &g_slot[i];
        /* Rate limit by state + five seconds; quiet for entirely FREE slots. */
        if (v->st == VP_FREE) {
            g_trace_last_state[i] = VP_FREE;
            continue;
        }
        if (g_trace_last_state[i] == v->st &&
            now >= g_trace_last_ms[i] && now - g_trace_last_ms[i] < 5000)
            continue;
        g_trace_last_state[i] = v->st;
        g_trace_last_ms[i] = now;
        log_line("GH5_VDA_R6 state slot=%d state=%s pending=%d remove_when_found=%d "
                 "matches=%d add_rc=%#x log_source=%s log_bytes=%llu "
                 "log_lines=%llu device_added=%llu eof=%d read_errno=%d "
                 "identity_quarantined=%d",
                 i, gc_vpad_state_name(v->st), g_pending,
                 v->remove_when_found, g_matches, (unsigned)g_add_result,
                 g_log_fd < 0 ? "none" : (g_log_is_dev ? "devklog" : "tcp3232"),
                 (unsigned long long)g_log_bytes,
                 (unsigned long long)g_log_lines,
                 (unsigned long long)g_log_device_added,
                 g_log_eof, g_log_read_errno,
                 v->st == VP_UNCERTAIN || v->st == VP_DELETE_FAILED);
    }
}
#endif


/* Raw sensor counts to physical units, uncalibrated: Sony pads report
 * 8192 counts per g and 1024 per degree per second. */
#define ACCEL_PER_G      8192.0f
#define GYRO_PER_DEG_S   1024.0f
#define DEG_TO_RAD       0.01745329252f

void notify(const char *fmt, ...)
{
    notify_request req;
    va_list ap;

    memset(&req, 0, sizeof req);
    va_start(ap, fmt);
    vsnprintf(req.message, sizeof req.message, fmt, ap);
    va_end(ap);
    sceKernelSendNotificationRequest(0, &req, sizeof req, 0);
}

/* ---- the kernel log ----------------------------------------------------------
 *
 * The device a virtual DualSense becomes is only told in the kernel log. The
 * log has one reader, which usually belongs to the HEN's log server; that
 * server re-serves it to any number of clients on TCP 3232. So:
 *   - the server is used when there is one;
 *   - /dev/klog only when there is none, held just for the seconds of one
 *     identification, and every line read is copied into GhostTooth's log so
 *     nothing taken from it is lost;
 *   - if neither answers with the expected lines, nothing is bound. */

/* Experimental variant: a regular file opts in to the direct /dev/klog reader.
 * Never auto-fallback on TCP silence: /dev/klog may be single-consumer.
 * The marker is NOT included with the default VDA activation marker. */
#ifndef GC_GH5_KLOG_DEV_OPTIN
#define GC_GH5_KLOG_DEV_OPTIN 0
#endif
#define GC_GH5_KLOG_DEV_MARKER "/data/ghostcontrol-app-service/gh5-klog-device.enable"
static int log_source_open(void)
{
    struct sockaddr_in sin;
    int fd;
    if (g_log_close_uncertain || g_log_fd >= 0) return -1;
#if GC_GH5_KLOG_DEV_OPTIN
    {
        struct stat marker;
        if (lstat(GC_GH5_KLOG_DEV_MARKER, &marker) == 0) {
            if (!S_ISREG(marker.st_mode)) {
                log_line("GH5_KLOG_R8 direct marker not regular; refusing identification path=%s",
                         GC_GH5_KLOG_DEV_MARKER);
                return -1;
            }
            fd = open("/dev/klog", O_RDONLY | O_NONBLOCK);
            if (fd < 0) {
                int e = errno;
                log_line("GH5_KLOG_R8 direct /dev/klog requested but open failed errno=%d (%s); "
                         "no TCP fallback, no AddDevice", e, strerror(e));
                log_line("GH5_KLOG_R9 source=devklog open_state=%s errno=%d "
                         "AddDevice_called=0; no virtual-device identity was requested",
                         e == EBUSY ? "LOCKED_BY_ANOTHER_READER" : "OPEN_FAILED", e);
                return -1;
            }
            g_log_is_dev = 1;
            log_line("GH5_KLOG_R8 direct /dev/klog explicitly requested; "
                     "single-reader device: avoid concurrent kernel log consumers");
            log_line("vpad: kernel log source=/dev/klog fd=%d", fd);
            return fd;
        }
        if (errno != ENOENT) {
            int e = errno;
            log_line("GH5_KLOG_R8 direct marker inspection failed errno=%d (%s); "
                     "no AddDevice", e, strerror(e));
            return -1;
        }
        log_line("GH5_KLOG_R8 direct marker absent; using standard TCP-first log selection");
    }
#endif
    fd = socket(AF_INET, SOCK_STREAM, 0);

    if (fd >= 0) {
        memset(&sin, 0, sizeof sin);
        sin.sin_family = AF_INET;
        sin.sin_port = htons(3232);
        sin.sin_addr.s_addr = inet_addr("127.0.0.1");
        if (connect(fd, (struct sockaddr *)&sin, sizeof sin) == 0) {
            const int flags = fcntl(fd, F_GETFL);
            if (flags < 0 || fcntl(fd, F_SETFL, flags | O_NONBLOCK) < 0) {
                log_line("vpad: TCP kernel log nonblocking setup failed: errno %d", errno);
                if (close(fd) != 0) g_log_close_uncertain = 1;
                return -1;
            }
            g_log_is_dev = 0;
            log_line("vpad: kernel log source=TCP 127.0.0.1:3232 fd=%d", fd);
            log_line("GH5_KLOG_R9 TCP_CONNECTED endpoint=127.0.0.1:3232 "
                     "provider_payload_unverified=1");
            return fd;
        }
        if (close(fd) != 0) { g_log_close_uncertain = 1; return -1; }
    }
#if GC_GH5_TCP_ONLY
    log_line("GH5_TCP_R10 TCP_ONLY: TCP server unavailable; /dev/klog fallback disabled; AddDevice not called");
    return -1;
#else
    fd = open("/dev/klog", O_RDONLY | O_NONBLOCK);
    if (fd >= 0) {
        g_log_is_dev = 1;
        log_line("vpad: kernel log source=/dev/klog fd=%d", fd);
        return fd;
    }
    log_line("vpad: no kernel log (no server on 3232, /dev/klog errno %d)", errno);
    return -1;
#endif
}

static void log_source_close(void)
{
    if (g_log_fd >= 0) {
        if (g_log_close_uncertain) return;
        if (close(g_log_fd) != 0) { g_log_close_uncertain = 1; return; }
    }
    g_log_fd = -1;
    g_line_len = 0;
    g_line_overflow = 0;
}

/* V12: reject partial/overflowing IDs; a numeric prefix is not an identity.
 * Keep exactly the known legacy [DeviceId:0x...] and newer deviceId=0x...
 * encodings. This is safety validation, not evidence that the klog is live. */
static int vpad_id_field_end(unsigned char c)
{
    return c == '\0' || c == ' ' || c == '\t' || c == '\r' ||
           c == '\n' || c == ',' || c == ']' || c == '}' ||
           c == ')' || c == ';';
}

static int vpad_identifier_byte(unsigned char c)
{
    return isalnum(c) || c == '_';
}

/* Match field names at token boundaries. */
static const char *vpad_token_after(const char *line, const char *token, int whole_word)
{
    const size_t length = strlen(token);
    const char *p = line;
    while ((p = strstr(p, token)) != NULL) {
        if ((p == line || !vpad_identifier_byte((unsigned char)p[-1])) &&
            (!whole_word || !vpad_identifier_byte((unsigned char)p[length])))
            return p + length;
        ++p;
    }
    return NULL;
}

static uint64_t hex_after(const char *s, const char *key)
{
    const char *p = vpad_token_after(s, key, 1);
    uint64_t value = 0;
    unsigned digits = 0;

    if (!p) return 0;
    while (*p == ' ' || *p == '\t') p++;
    if (*p != ':' && *p != '=') return 0;
    p++;
    while (*p == ' ' || *p == '\t') p++;
    if (p[0] == '0' && (p[1] == 'x' || p[1] == 'X')) p += 2;
    while (isxdigit((unsigned char)*p)) {
        const unsigned char c = (unsigned char)*p++;
        if (++digits > 16) return 0;
        value = (value << 4) | (uint64_t)(c <= '9' ? c - '0' :
                                             (c | 0x20) - 'a' + 10);
    }
    if (digits == 0 || !vpad_id_field_end((unsigned char)*p)) return 0;
    return value;
}

/* MBus deviceType defaults to decimal; hexadecimal requires 0x. */
static int vpad_number_is(const char *line, const char *field, unsigned want)
{
    const char *p = vpad_token_after(line, field, 0);
    char *end;
    int base = 10;
    unsigned long value;

    if (!p) return 0;
    while (*p == ' ' || *p == '\t') ++p;
    if (!isdigit((unsigned char)*p)) return 0;
    /* Decimal is the default, even with leading zeroes (e.g. 022 == 22).
     * Hexadecimal is explicit and must carry its 0x prefix. */
    if (p[0] == '0' && (p[1] == 'x' || p[1] == 'X')) base = 16;
    value = strtoul(p, &end, base);
    return end != p && value == want && vpad_id_field_end((unsigned char)*end);
}

/* Accept both supported MBus formats. */
static uint64_t virtual_device_in(const char *line)
{
    const char *bat;
    const int old_format = vpad_number_is(line, "type:", 1) &&
                           vpad_number_is(line, "subType:", 22);
    const int new_format = vpad_number_is(line, "deviceType=", 22);
    if (!vpad_token_after(line, "DEVICE_ADDED", 1) || (!old_format && !new_format))
        return 0;
    bat = vpad_token_after(line, "capabilityBattery:", 0);
    if (bat) {
        while (*bat == ' ' || *bat == '\t') bat++;
        if (*bat != '0' || !vpad_id_field_end((unsigned char)bat[1])) return 0;
    }
    return hex_after(line, new_format ? "deviceId" : "DeviceId");
}

enum { LINE_DROP_OVERLONG = 1, LINE_DROP_BINARY };

/* Return success after draining the nonblocking log source. */
static int log_source_read(void)
{
    char buf[1024];
    int rounds;

    for (rounds = 0; rounds < 8 && g_log_fd >= 0; rounds++) {
        ssize_t n = read(g_log_fd, buf, sizeof buf), i;
        if (n <= 0) {
            if (n < 0 && errno == EINTR) continue;
            if (n < 0 && (errno == EAGAIN || errno == EWOULDBLOCK)) return 1;
            if (n == 0) {
                g_log_eof = 1;
                static int noted_eof;
                if (!noted_eof++) log_line("vpad: kernel log EOF source=%s",
                                           g_log_is_dev ? "/dev/klog" : "TCP");
            } else {
                g_log_read_errno = errno;
                log_line("vpad: kernel log read error source=%s errno=%d (%s)",
                         g_log_is_dev ? "/dev/klog" : "TCP", errno, strerror(errno));
            }
            return 0;
        }
        g_log_bytes += (uint64_t)n;
        if (g_pending >= 0) {
            const long received_at = now_ms();
            if (g_log_first_byte_ms < 0) g_log_first_byte_ms = received_at;
            g_log_last_byte_ms = received_at;
        }
        for (i = 0; i < n; i++) {
            uint64_t dev;
            if (buf[i] != '\n') {
                /* Never synthesize a newline when the finite buffer fills.
                 * Drop the entire overlong physical line, including any
                 * valid-looking DEVICE_ADDED prefix, until its actual LF. */
                if (g_line_overflow) continue;
                if (buf[i] == '\0') {
                    g_line_overflow = LINE_DROP_BINARY;
                    continue;
                }
                if (g_line_len >= sizeof g_line - 1) {
                    g_line_overflow = LINE_DROP_OVERLONG;
                    continue;
                }
                g_line[g_line_len++] = buf[i];
                continue;
            }
            if (g_line_overflow) {
                const char *reason = g_line_overflow == LINE_DROP_BINARY ?
                    "line_binary_dropped" : "line_overlong_dropped";
                g_line_overflow = 0;
                g_line_len = 0;
                if (++g_line_dropped == 1 || g_line_dropped % 32 == 0)
                    log_line("GH5_MBUS_R11 %s total=%llu; "
                             "no DEVICE_ADDED candidate accepted",
                             reason, (unsigned long long)g_line_dropped);
                continue;
            }
            g_line[g_line_len] = '\0';
            g_line_len = 0;
            ++g_log_lines;
            const int added = vpad_token_after(g_line, "DEVICE_ADDED", 1) != NULL;
            const int removed = vpad_token_after(g_line, "DEVICE_REMOVED", 1) != NULL;
            if (added) ++g_log_device_added;
            if (g_log_is_dev) log_line("klog: %s", g_line);  /* kept, not lost */
            if (added || removed) {
                ++g_log_mbus_events;
                log_line("vpad: MBus raw source=%s line=%s",
                         g_log_is_dev ? "/dev/klog" : "TCP", g_line);
                dev = added ? virtual_device_in(g_line) : 0;
                if (dev)
                    log_line("vpad: MBus parsed DEVICE_ADDED DeviceId=%#llx format=%s pending=%d",
                             (unsigned long long)dev,
                             vpad_number_is(g_line, "deviceType=", 22) ? "new-deviceType" : "legacy",
                             g_pending);
                else if (added)
                    log_line("vpad: MBus DEVICE_ADDED not matched by DualSense filter pending=%d",
                             g_pending);
            } else {
                dev = 0;
            }
            if (!dev || g_pending < 0) continue;
            if (g_matches == 0) {
                g_match_dev = dev;
                g_t_match = now_ms();
            }
            if (g_matches == 0 || dev != g_match_dev) g_matches++;
        }
    }
    return 0;
}

/* ---- users and privileges ---------------------------------------------------- */

/* The user to give the pads to: one who is signed in. scePadOpen and the
 * bind answer 0x809b0081 (USER_NOT_LOGIN) for a user who is not, and the
 * foreground or initial user is not necessarily signed in (the first trial
 * of the pad hotkey on a console got exactly that). By default the initial
 * user, who is the one who owns the console, is preferred if signed in; then
 * the foreground user; then the first signed-in one.
 *
 * `want` (from /data/ghosttooth/bind_user) overrides that for an experiment: a
 * game only sees a pad bound to the user who started it, so the pad can be
 * given to another signed-in user. "other" means a signed-in user who is not
 * the initial one; a hexadecimal id means that user. If the wish cannot be met
 * (nobody else signed in, or that id is not signed in) the default applies. */
int32_t vpad_choose_user(const int32_t login[4], int32_t init, int32_t fore, const char *want)
{
    int i, n = 0;

    for (i = 0; i < 4; i++) if (login[i] != -1 && login[i] != 0) n++;
    if (n == 0) return -1;                                       /* nobody is signed in */

    if (want && *want) {
        if (strcmp(want, "other") == 0) {
            for (i = 0; i < 4; i++)
                if (login[i] != -1 && login[i] != 0 && login[i] != init) return login[i];
        } else {
            char *end;
            unsigned long id = strtoul(want, &end, 16);
            if (end != want && *end == '\0')
                for (i = 0; i < 4; i++) if (login[i] != -1 && (uint32_t)login[i] == (uint32_t)id) return login[i];
        }
    }
    for (i = 0; i < 4; i++) if (init != -1 && login[i] == init) return init;
    for (i = 0; i < 4; i++) if (fore != -1 && login[i] == fore) return fore;
    for (i = 0; i < 4; i++) if (login[i] != -1 && login[i] != 0) return login[i];
    return -1;
}

static int32_t main_user(void)
{
    int32_t login[4] = { -1, -1, -1, -1 }, init = -1, fore = -1, seen[6];
    static int32_t logged[6] = { -2, -2, -2, -2, -2, -2 };
    char want[40] = "";
    FILE *f;
    int i;

    if (sceUserServiceGetLoginUserIdList(login) != 0) login[0] = login[1] = login[2] = login[3] = -1;
    if (sceUserServiceGetInitialUser(&init) != 0) init = -1;
    if (sceUserServiceGetForegroundUser(&fore) != 0) fore = -1;
    if ((f = fopen("/data/ghosttooth/bind_user", "r"))) {
        if (fgets(want, sizeof want, f)) {
            for (i = 0; want[i]; i++) if (want[i] == '\n' || want[i] == '\r' || want[i] == ' ') want[i] = 0;
            if (strncmp(want, "0x", 2) == 0) memmove(want, want + 2, strlen(want + 2) + 1);
        }
        fclose(f);
    }

    memcpy(seen, login, sizeof login);
    seen[4] = init;
    seen[5] = fore;
    if (memcmp(seen, logged, sizeof seen) != 0) {                /* log it when it changes */
        memcpy(logged, seen, sizeof seen);
        log_line("users: initial %#x, foreground %#x, signed in %#x %#x %#x %#x%s%s", (unsigned)init,
                 (unsigned)fore, (unsigned)login[0], (unsigned)login[1], (unsigned)login[2],
                 (unsigned)login[3], want[0] ? ", bind_user=" : "", want);
    }
    return vpad_choose_user(login, init, fore, want);
}

#ifndef GC_VPAD_RAISE_CREDS
#define GC_VPAD_RAISE_CREDS 0
#endif

/* Every step is checked and read back; on any failure the original
 * credentials are put back and virtual pads stay off. */
static uint64_t g_orig_authid;
static uint8_t g_orig_caps[16];
static int g_have_orig;
static int g_raised;

/* Sets credentials and reads them back. Returns 0 if they did not stick. */
static int set_creds(uint64_t authid, const uint8_t caps[16])
{
    pid_t me = getpid();
    uint8_t now_caps[16];

    return kernel_set_ucred_authid(me, authid) == 0 && kernel_set_ucred_caps(me, caps) == 0 &&
           kernel_get_ucred_authid(me) == authid && kernel_get_ucred_caps(me, now_caps) == 0 &&
           memcmp(now_caps, caps, 16) == 0;
}

static int elevate(void)
{
    static const uint8_t caps[16] = {
        0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
        0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
    };
    pid_t me = getpid();

    if (!g_have_orig) {
        g_orig_authid = kernel_get_ucred_authid(me);
        if (!g_orig_authid || kernel_get_ucred_caps(me, g_orig_caps) != 0) {
            log_line("vpad: cannot read our credentials");
            return 0;
        }
        g_have_orig = 1;
    }
    if (!set_creds(0x3800000000010003ull, caps)) {
        log_line("vpad: credentials not raised; putting the old ones back");
        set_creds(g_orig_authid, g_orig_caps);
        g_raised = 0;
        return 0;
    }
    g_raised = 1;
    return 1;
}

int vpad_creds_restore(void)
{
    if (!g_have_orig || !g_raised) return 1;
    if (!set_creds(g_orig_authid, g_orig_caps)) {
        log_line("vpad: could not put the original credentials back");
        return 0;
    }
    g_raised = 0;
    log_line("vpad: original credentials restored");
    return 1;
}

int vpad_creds_raise(void)
{
    return g_raised || elevate();
}

int vpad_init(void)
{
    static const char *const mbus[] = {
        "/system/common/lib/libSceMbus.sprx", "libSceMbus.sprx",
    };
    void *lib = NULL;
    int32_t r;
    size_t i;

    /* Route vpad diagnostics to a retrievable, rotating file; otherwise they
     * go to stderr, which the resident companion does not persist. */
    (void)log_open("/data/ghostcontrol-app-service/vpad.log");

#if GC_VPAD_RAISE_CREDS
    if (!elevate()) return 0;
#else
    log_line("vpad: ordinary mode (no credential raise)");
#endif
    if ((r = sceUserServiceInitialize(NULL)) != 0)
        log_line("vpad: sceUserServiceInitialize %#x (already initialised is fine)", (unsigned)r);

    /* libScePad imports from libSceMbus: load it before any scePad call,
     * or scePadInit can fault on an unresolved import. */
    for (i = 0; i < sizeof mbus / sizeof mbus[0] && !lib; i++)
        lib = dlopen(mbus[i], RTLD_NOW | RTLD_GLOBAL);
    if (lib) g_bind = (mbus_bind_fn)dlsym(lib, "sceMbusBindDeviceWithUserId");
    if (!g_bind) {
        log_line("vpad: libSceMbus not available, refusing to touch libScePad");
        return 0;
    }
    /* scePadInit first. scePadSetProcessPrivilege before it answers
     * 0x80920005, "not initialised" (found on the first run on a console,
     * firmware 10.01). The
     * privilege call is not checked as a precondition: the virtual device
     * calls report their own errors. */
    if ((r = scePadInit()) != 0) {
        log_line("vpad: scePadInit failed: %#x", (unsigned)r);
        return 0;
    }
    if ((r = scePadSetProcessPrivilege(1)) != 0)
        log_line("vpad: scePadSetProcessPrivilege answered %#x, carrying on", (unsigned)r);
    g_user = main_user();
    log_line("vpad: main user %#x", (unsigned)g_user);
    g_ready = 1;
    return 1;
}

/* ---- virtual pads ----------------------------------------------------------- */

int vpad_add_is_quarantined(int slot)
{
    return slot >= 0 && slot < HOST_MAX_PADS &&
           (g_slot[slot].st == VP_UNCERTAIN || g_slot[slot].st == VP_DELETE_FAILED);
}

int vpad_add(int slot)
{
    if (!g_ready || slot < 0 || slot >= HOST_MAX_PADS) {
#if GC_VPAD_TEST_TRACE
        log_line("GH5_VDA_R6 queue refused slot=%d backend_ready=%d range_ok=%d",
                 slot, g_ready, slot >= 0 && slot < HOST_MAX_PADS);
#endif
        return 0;
    }
    if (g_slot[slot].st != VP_FREE && g_slot[slot].st != VP_FAILED) {
#if GC_VPAD_TEST_TRACE
        /* Quarantined slots cannot be retried by handle. */
        if (vpad_add_is_quarantined(slot)) {
            /* Rate-limit repeated quarantine notices. */
            const long current = now_ms();
            long *last = &g_trace_last_quarantine_notice[slot];
            if (gc_vpad_quarantine_notice_due_r9(current, last)) {
                log_line("GH5_VDA_R9 queue refused slot=%d quarantine=%s; "
                         "device identity unknown, do not retry before full exit/reboot",
                         slot, gc_vpad_state_name(g_slot[slot].st));
            }
        }
#endif
        return 0;
    }
    memset(&g_slot[slot], 0, sizeof g_slot[slot]);
    g_slot[slot].st = VP_QUEUED;
    g_slot[slot].handle = -1;
    g_slot[slot].add_attempted = 0;
#if GC_VPAD_TEST_TRACE
    g_trace_last_quarantine_notice[slot] = 0;
    log_line("GH5_VDA_R6 queued slot=%d; AddDevice has NOT been called yet", slot);
#endif
    return 1;
}

/* Preserve the established AddDevice parameters and preflight order. */
static void start_adddevice_after_drain(int slot)
{
    int32_t param[8];
    int32_t r;
    g_pre_bytes = g_log_bytes;
    g_pre_lines = g_log_lines;
    g_pre_mbus = g_log_mbus_events;
    g_pre_added = g_log_device_added;
    log_line("GH5_TCP_R10 pre_add source=%s preflight_ms=%ld pre_bytes=%llu pre_lines=%llu pre_mbus=%llu pre_device_added=%llu "
             "evidence_only=1", g_log_is_dev ? "devklog" : "tcp3232",
             g_preflight_elapsed_ms, (unsigned long long)g_pre_bytes,
             (unsigned long long)g_pre_lines, (unsigned long long)g_pre_mbus,
             (unsigned long long)g_pre_added);
    g_line[0] = '\0';
    g_line_overflow = 0;
    g_log_bytes = g_log_lines = g_log_mbus_events = g_log_device_added = 0;
    g_log_eof = g_log_read_errno = 0;
    g_log_first_byte_ms = g_log_last_byte_ms = -1;
    g_matches = 0;
    g_match_dev = 0;

    /* Keep the existing parameter-layout comparison. */
    /* The precision variant uses zeroed reserved fields. */
    gc_vpad_prepare_add_param_r9(param, GC_GH5_VDA_ZERO_RESERVED);
#if GC_VPAD_TEST_TRACE
    log_line("GH5_VDA_R9 AddDevice param_layout=%s size=%d unassigned_user=%d "
             "reserved=%08x %08x %08x %08x %08x %08x",
             GC_GH5_VDA_ZERO_RESERVED ? "zero" : "sentinel-r8",
             (int)param[0], (int)param[1],
             (unsigned)param[2], (unsigned)param[3], (unsigned)param[4],
             (unsigned)param[5], (unsigned)param[6], (unsigned)param[7]);
#endif
    /* Any AddDevice call may create an object; fence retries before invoking it. */
    g_slot[slot].add_attempted = 1;
    r = scePadVirtualDeviceAddDevice(param, VIRTUAL_DEVICE_DUALSENSE);
    g_add_result = r;
#if GC_VPAD_TEST_TRACE
    if ((uint32_t)r == 0x803B0006u)
        log_line("GH5_VDA_R9 AddDevice rc=%#x class=ASSIGNMENT_PENDING_CANDIDATE; "
                 "not a confirmed device on PS5 11.60; requires DEVICE_ADDED",
                 (unsigned)r);
    else if (r != 0)
        log_line("GH5_VDA_R9 AddDevice nonzero slot=%d result=%#x; "
                 "do not assume that a virtual device was created",
                 slot, (unsigned)r);
#endif
    log_line("slot %d: AddDevice %#x, block %08x %08x %08x %08x %08x %08x", slot, (unsigned)r,
             (unsigned)param[2], (unsigned)param[3], (unsigned)param[4], (unsigned)param[5],
             (unsigned)param[6], (unsigned)param[7]);
    g_pending = slot;
    g_t_add = now_ms();
    g_slot[slot].st = VP_PENDING;
}

static void start_identification(int slot)
{
    if (g_user == -1) g_user = main_user(); /* signed in since */
    if (g_user == -1) {
        log_line("slot %d: nobody signed in, no virtual pad", slot);
        g_slot[slot].st = VP_FAILED;
        return;
    }
#if GC_VPAD_RAISE_CREDS
    if (!vpad_creds_raise()) {
        g_slot[slot].st = VP_FAILED;
        return;
    }
#endif
    g_log_fd = log_source_open();
    if (g_log_fd < 0) {
        g_slot[slot].st = VP_FAILED;
        return;
    }
    g_log_bytes = g_log_lines = g_log_mbus_events = g_log_device_added = 0;
    g_log_eof = g_log_read_errno = 0;
    g_preflight_elapsed_ms = 0;
#if GC_GH5_TCP_PREFLIGHT_MS > 0
    if (!g_log_is_dev) {
        g_preflight_slot = slot;
        g_preflight_since_ms = now_ms();
        g_slot[slot].st = VP_PREFLIGHT;
        log_line("GH5_TCP_R10 preflight_begin slot=%d duration_ms=%d drain_deadline_ms=%d source=tcp3232 "
                 "no_AddDevice_yet=1", slot, GC_GH5_TCP_PREFLIGHT_MS, T_TCP_PREFLIGHT_DEADLINE);
        return;
    }
#endif
    if (!log_source_read() || g_line_len || g_line_overflow) {
        log_line("slot %d: kernel log not ready for identification (eof=%d read_errno=%d partial=%zu); AddDevice not called",
                 slot, g_log_eof, g_log_read_errno, g_line_len);
        log_source_close();
        g_slot[slot].st = VP_FAILED;
        return;
    }
    start_adddevice_after_drain(slot);
}

/* Continue without sleeping in vpad_poll. */
static void poll_preflight(long now)
{
    const int slot = g_preflight_slot;
    if (slot < 0) return;
    const int drained = log_source_read();
    const long elapsed = now - g_preflight_since_ms;
    const int partial = g_line_len != 0 || g_line_overflow;
    const char *failure = NULL;
    if (g_log_eof || g_log_read_errno)
        failure = "LOG_READ_ERROR";
    else if ((!drained || partial) && elapsed >= T_TCP_PREFLIGHT_DEADLINE)
        failure = partial ? "PARTIAL_LINE" : "DRAIN_DEADLINE";
    else if (!drained || partial || elapsed < GC_GH5_TCP_PREFLIGHT_MS)
        return;
    if (failure) {
        log_line("GH5_TCP_R10 preflight_aborted slot=%d reason=%s bytes=%llu partial=%zu "
                 "eof=%d read_errno=%d; AddDevice_called=0", slot, failure,
                 (unsigned long long)g_log_bytes, g_line_len, g_log_eof, g_log_read_errno);
        g_preflight_slot = -1;
        log_source_close();
        g_slot[slot].st = VP_FAILED;
        return;
    }
    g_preflight_elapsed_ms = elapsed;
    if (g_log_bytes == 0)
        log_line("GH5_TCP_R10 preflight_result=SILENT_UNPROVEN "
                 "note=quiet_before_AddDevice_is_not_provider_failure");
    else
        log_line("GH5_TCP_R10 preflight_result=PAYLOAD_OBSERVED bytes=%llu lines=%llu",
                 (unsigned long long)g_log_bytes, (unsigned long long)g_log_lines);
    g_preflight_slot = -1;
    start_adddevice_after_drain(slot);
}

static void finish_identification(long now, int drained)
{
    vslot *v = &g_slot[g_pending];
    int slot = g_pending;
    int32_t r;
    /* Require a complete log record before accepting a unique candidate. */
    const int incomplete = !drained || g_log_eof || g_log_read_errno ||
                           g_line_len != 0 || g_line_overflow;
    const int within_window = now - g_t_add < T_IDENTIFY;

    if (g_matches == 0 && within_window) return;
    if (g_matches == 1 && within_window &&
        (incomplete || now - g_t_match < T_AMBIGUITY)) return;

    g_pending = -1;
#if GC_VPAD_TEST_TRACE
    log_line("GH5_VDA_R6 identification_decision slot=%d candidates=%d "
             "unique_dev=%#llx add_rc=%#x",
             slot, g_matches, (unsigned long long)g_match_dev,
             (unsigned)g_add_result);
#endif
    log_line("vpad: slot %d identification source=%s add_rc=%#x bytes=%llu lines=%llu device_added=%llu mbus_events=%llu candidates=%d eof=%d read_errno=%d",
             slot, g_log_is_dev ? "/dev/klog" : "TCP:3232", (unsigned)g_add_result,
             (unsigned long long)g_log_bytes, (unsigned long long)g_log_lines,
             (unsigned long long)g_log_device_added,
             (unsigned long long)g_log_mbus_events, g_matches, g_log_eof, g_log_read_errno);
    {
        const GcVpadKlogEvidence e = gc_vpad_klog_evidence(
            g_log_bytes, g_log_lines, g_log_device_added,
            g_matches, g_log_eof, g_log_read_errno);
        log_line("GH5_KLOG_R8 evidence=%s source=%s first_byte_delay_ms=%ld "
                 "last_byte_age_ms=%ld bytes=%llu lines=%llu device_added=%llu "
                 "matches=%d add_rc=%#x; zero traffic is NOT proof of no device",
                 gc_vpad_klog_evidence_name(e),
                 g_log_is_dev ? "devklog" : "tcp3232",
                 g_log_first_byte_ms < 0 ? -1L : g_log_first_byte_ms - g_t_add,
                 g_log_last_byte_ms < 0 ? -1L : now - g_log_last_byte_ms,
                 (unsigned long long)g_log_bytes,
                 (unsigned long long)g_log_lines,
                 (unsigned long long)g_log_device_added, g_matches,
                 (unsigned)g_add_result);
    }
    if (!g_log_is_dev) {
        const GcVpadTcpHealthR10 verdict = gc_vpad_tcp_health_r10(
            g_pre_bytes, g_log_bytes, g_log_eof, g_log_read_errno);
        log_line("GH5_TCP_R10 health=%s preflight_ms=%ld pre_bytes=%llu "
                 "live_bytes=%llu live_lines=%llu live_device_added=%llu "
                 "live_candidates=%d AddDevice_rc=%#x "
                 "note=TCP_bytes_do_not_alone_prove_virtual_device_created",
                 gc_vpad_tcp_health_name_r10(verdict), g_preflight_elapsed_ms,
                 (unsigned long long)g_pre_bytes, (unsigned long long)g_log_bytes,
                 (unsigned long long)g_log_lines, (unsigned long long)g_log_device_added,
                 g_matches, (unsigned)g_add_result);
    }
    if (!g_matches) {
        if (!g_log_bytes && !g_log_read_errno && !g_log_eof && !g_log_is_dev)
            log_line("GH5_KLOG_R9 TCP_CONNECTED_BUT_SILENT during identification; "
                     "server accepting connections does not prove it publishes MBus");
        if (g_log_read_errno)
            log_line("vpad: kernel log read failed; check log source before matching");
        else if (g_log_eof && !g_log_is_dev)
            log_line("vpad: TCP kernel log stream ended; check klog provider");
        else if (!g_log_bytes)
            log_line("vpad: kernel log supplied no bytes; parser was not exercised");
        else if (!g_log_device_added)
            log_line("vpad: no DEVICE_ADDED event received during identification");
        else
            log_line("vpad: DEVICE_ADDED received but no virtual DualSense matched");
    }
    log_source_close();
    if (g_matches != 1 || incomplete) {
        /* Unknown identities must not be bound or deleted. */
        log_line("slot %d: virtual pad not identified (%d candidates, incomplete_log=%d), left alone",
                 slot, g_matches, incomplete);
        v->st = VP_UNCERTAIN;
#if GC_VPAD_TEST_TRACE
        log_line("GH5_VDA_R6 QUARANTINED slot=%d: unknown virtual identity; "
                 "no bind, no InsertData, no unsafe DeleteDevice. "
                 "Perform full service exit or reboot before retrying.", slot);
#endif
        return;
    }
    v->dev = g_match_dev;
    v->handle = (int32_t)(g_match_dev & 0xFFFFFFFFu);
    if (v->remove_when_found) {
        if (scePadVirtualDeviceDeleteDevice(v->handle) != 0) {
            v->st = VP_DELETE_FAILED; return;
        }
        log_line("slot %d: device %#llx removed: its pad left meanwhile", slot,
                 (unsigned long long)v->dev);
        memset(v, 0, sizeof *v);
        return;
    }
    r = g_bind(v->dev, g_user);
    log_line("slot %d: device %#llx bound to user %#x: %#x", slot, (unsigned long long)v->dev,
             (unsigned)g_user, (unsigned)r);
    if (r != 0) {
        /* Retain identified devices after a failed bind. */
        if (scePadVirtualDeviceDeleteDevice(v->handle) != 0)
            v->st = VP_DELETE_FAILED;
        else memset(v, 0, sizeof *v);
        return;
    }
    v->st = VP_READY;
}

void vpad_poll(long now)
{
    int i;

    if (!g_ready) return;
#if GC_VPAD_TEST_TRACE
    gc_vpad_trace_snapshot(now);
#endif
    if (g_preflight_slot >= 0) {
        poll_preflight(now);
        return;
    }
    if (g_pending >= 0) {
        const int drained = log_source_read();
        finish_identification(now, drained);
        return;
    }
    for (i = 0; i < HOST_MAX_PADS; i++)
        if (g_slot[i].st == VP_QUEUED) {
            start_identification(i);
            return;
        }
}

/* Only failures before AddDevice may release the queued flag. */
int vpad_retryable(int slot)
{
    return slot >= 0 && slot < HOST_MAX_PADS &&
           g_slot[slot].st == VP_FAILED && !g_slot[slot].add_attempted &&
           !g_log_close_uncertain && g_log_fd < 0;
}

int vpad_live(int slot)
{
    return slot >= 0 && slot < HOST_MAX_PADS && g_slot[slot].st == VP_READY;
}

/* PR34 4fcb1fb read-back, opt-in ONLY. The header is host-tested, but the
 * callable API and Bluetooth output are not validated on user's firmware. */
#if GC_VPAD_RUMBLE_READBACK
int vpad_rumble(int slot, uint8_t *strong, uint8_t *weak)
{
    uint8_t buf[256];
    if (slot < 0 || slot >= HOST_MAX_PADS || !strong || !weak || !vpad_live(slot))
        return 0;
    memset(buf, 0, sizeof buf);
    if (scePadVirtualDeviceGetRemoteSetting(g_slot[slot].handle, buf, sizeof buf) != 0)
        return 0;
    return vpad_rs_decode(buf, sizeof buf, strong, weak);
}
#endif

void vpad_update(int slot, const pad_state *st)
{
    ScePadData d;
    struct timespec ts;
    int i;

    if (!vpad_live(slot)) return;
    memset(&d, 0, sizeof d);
    d.buttons = st->buttons;
    d.lx = st->lx;
    d.ly = st->ly;
    d.rx = st->rx;
    d.ry = st->ry;
    d.l2 = st->l2;
    d.r2 = st->r2;
    d.orientation[3] = 1.0f;
    if (st->has_motion) {
        for (i = 0; i < 3; i++) {
            d.acceleration[i] = st->accel[i] / ACCEL_PER_G;
            d.angularVelocity[i] = st->gyro[i] / GYRO_PER_DEG_S * DEG_TO_RAD;
        }
    } else {
        d.acceleration[1] = -1.0f;      /* at rest, held level */
    }
    if (st->has_touch) {
        for (i = 0; i < 2; i++) {
            ScePadTouch *t = &d.touchData.touch[d.touchData.touchNum];
            if (!st->touch[i].down) continue;
            t->x = st->touch[i].x;
            t->y = st->touch[i].y;
            t->id = (uint8_t)i;
            d.touchData.touchNum++;
        }
    }
    d.connected = 1;
    d.connectedCount = 1;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    d.timestamp = (uint64_t)ts.tv_sec * 1000000u + (uint64_t)ts.tv_nsec / 1000u;

    /* Retry transient insert failures without invalidating an owned pad. */
    {
        int32_t ir = scePadVirtualDeviceInsertData(g_slot[slot].handle, &d);
        if (ir != 0) {
            uint32_t n = ++g_slot[slot].reject_count;
            if (n == 1u || (n % 600u) == 0u)
                log_line("slot %d: InsertData refused %#x (count %u), still feeding",
                         slot, (unsigned)ir, n);
        } else {
            if (!g_slot[slot].insert_confirmed) {
                log_line("slot %d: first InsertData accepted device=%#llx handle=%#x user=%#x",
                         slot, (unsigned long long)g_slot[slot].dev,
                         (unsigned)g_slot[slot].handle, (unsigned)g_user);
                g_slot[slot].insert_confirmed = 1;
            }
            if (g_slot[slot].reject_count) {
                log_line("slot %d: InsertData recovered after %u refusals", slot,
                         g_slot[slot].reject_count);
                g_slot[slot].reject_count = 0;
            }
        }
    }
}

/* Delete only identified devices owned by this instance. */
void vpad_remove(int slot)
{
    vslot *v;

    if (slot < 0 || slot >= HOST_MAX_PADS) return;
    v = &g_slot[slot];
    switch (v->st) {
    case VP_READY:
        if (scePadVirtualDeviceDeleteDevice(v->handle) != 0) {
            v->st = VP_DELETE_FAILED; return;
        }
        log_line("slot %d: virtual DualSense removed", slot);
        memset(v, 0, sizeof *v);
        break;
    case VP_PREFLIGHT:
        /* No AddDevice has been called; cancelling this state is safe. */
        if (g_preflight_slot == slot) {
            g_preflight_slot = -1;
            log_source_close();
            log_line("GH5_TCP_R10 preflight_cancelled slot=%d no_AddDevice=1", slot);
        }
        memset(v, 0, sizeof *v);
        break;
    case VP_PENDING:
        v->remove_when_found = 1;       /* finish_identification deletes it */
        break;
    case VP_DELETE_FAILED:
        /* A failed delete leaves the handle quarantined. */
        break;
    case VP_UNCERTAIN:
#if GC_VPAD_TEST_TRACE
        log_line("GH5_VDA_R6 remove ignored slot=%d identity=UNCERTAIN "
                 "(unknown device deliberately untouched)", slot);
#endif
        break; /* Never delete or forget unknown, ambiguous or rejected input. */
    default:
        memset(v, 0, sizeof *v);
        break;
    }
}

void vpad_shutdown(void) { (void)vpad_shutdown_checked(); }

static int32_t g_phys_err;
static int32_t g_phys_handle = -1;
static int g_phys_ours;                 /* we opened it, so we close it */
static int g_phys_close_uncertain;
static long g_phys_retry_at;
static int32_t g_open_logged = 1;
static long g_user_retry_at;

int32_t vpad_physical_error(void) { return g_phys_err; }

/* The handle for the user's pad in this process. A payload has none until
 * it opens the pad, which is what any application does (the system's own
 * UI and the running game each hold the pad too). A refusal is logged and
 * tried again at most every 5 seconds. */
static int32_t physical_handle(void)
{
    int32_t h;

    if (g_phys_close_uncertain) return -1;
    if (g_phys_handle >= 0) return g_phys_handle;
    h = scePadGetHandle(g_user, 0, 0);
    if (h < 0 && now_ms() >= g_phys_retry_at) {
        g_phys_retry_at = now_ms() + 5000;
        h = scePadOpen(g_user, 0, 0, NULL);
        if (h != g_open_logged) {                   /* only when the answer changes */
            log_line("vpad: scePadOpen of the user's pad (user %#x): %#x", (unsigned)g_user, (unsigned)h);
            g_open_logged = h;
        }
        if (h >= 0) g_phys_ours = 1;
        /* The user may sign in or out meanwhile: look again. */
        if (h == (int32_t)0x809B0081) g_user = main_user();
    }
    if (h >= 0) g_phys_handle = h;
    return h;
}

static int close_physical_checked(void)
{
    if (g_phys_close_uncertain) return -1;
    if (g_phys_handle >= 0 && g_phys_ours && scePadClose(g_phys_handle) != 0) {
        /* No documented nonconsumption guarantee: quarantine this owner even
         * if init later succeeds. Do not read, reopen or reclose its handle. */
        g_phys_close_uncertain = 1;
        return -1;
    }
    g_phys_handle = -1;
    g_phys_ours = 0;
    return 0;
}
void vpad_close_physical(void) { (void)close_physical_checked(); }

const char *vpad_release_blocker(void)
{
    if (g_log_close_uncertain) return "vpad_log_close_uncertain";
    if (g_phys_close_uncertain) return "vpad_physical_close_uncertain";
    for (int i = 0; i < HOST_MAX_PADS; ++i) {
        if (g_slot[i].st == VP_PENDING) return "vpad_identification_pending";
        if (g_slot[i].st == VP_UNCERTAIN) return "vpad_identity_uncertain";
        if (g_slot[i].st == VP_DELETE_FAILED) return "vpad_delete_uncertain";
    }
    return NULL;
}
int vpad_shutdown_checked(void)
{
    const char *blocker = vpad_release_blocker();
    if (blocker) {
#if GC_VPAD_TEST_TRACE
        log_line("GH5_VDA_R6 shutdown blocked reason=%s; "
                 "do not assume the service has exited", blocker);
#endif
        return -1;
    }
    for (int i = 0; i < HOST_MAX_PADS; ++i) {
        vpad_remove(i);
        if (g_slot[i].st != VP_FREE) return -1;
    }
    if (close_physical_checked() != 0) return -1;
    log_source_close();
    if (g_log_fd >= 0 || g_log_close_uncertain) return -1;
    g_ready = 0;
    return 0;
}

int vpad_read_physical(uint32_t *buttons)
{
    ScePadData d;
    int32_t h, r;

    /* Only reads the user's own pad, through the handle libScePad gives for
     * it: never opens, takes over or disconnects it. */
    if (!g_ready) {
        g_phys_err = (int32_t)0xFFFF0001;               /* not ready */
        return 0;
    }
    if (g_user == -1) {                 /* nobody was signed in; look again now and then */
        if (now_ms() >= g_user_retry_at) {
            g_user_retry_at = now_ms() + 5000;
            g_user = main_user();
        }
        if (g_user == -1) {
            g_phys_err = (int32_t)0xFFFF0004;           /* nobody signed in */
            return 0;
        }
    }
    h = physical_handle();
    if (h < 0) {
        g_phys_err = h;
        return 0;
    }
    r = scePadReadState(h, &d);
    if (r != 0) {
        g_phys_err = r;
        (void)close_physical_checked(); /* failed close quarantines the owner */
        return 0;
    }
    if (!d.connected) {
        g_phys_err = (int32_t)0xFFFF0002;               /* no pad connected */
        return 0;
    }
    g_phys_err = 0;
    /* The system takes the pad's input while it has focus: that reads as the
     * 'intercepted' bit, and then the buttons are not ours to use. */
    if (d.buttons & 0x80000000u) {
        g_phys_err = (int32_t)0xFFFF0003;               /* intercepted */
        return 0;
    }
    *buttons = d.buttons;
    return 1;
}
