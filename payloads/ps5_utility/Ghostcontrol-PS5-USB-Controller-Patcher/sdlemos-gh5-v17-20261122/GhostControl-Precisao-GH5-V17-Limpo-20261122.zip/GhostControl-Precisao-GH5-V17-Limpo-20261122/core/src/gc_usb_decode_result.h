/* SPDX-License-Identifier: GPL-3.0-or-later */
#pragma once
/* An observed transport sample is not automatically publishable controls. */
enum GcUsbDecodeResult {
    GC_USB_DECODE_REJECTED = 0,
    GC_USB_DECODE_CONTROLS = 1,
    GC_USB_DECODE_SKIPPED = 2,
    GC_USB_DECODE_NEUTRAL_PROBE = 3
};
