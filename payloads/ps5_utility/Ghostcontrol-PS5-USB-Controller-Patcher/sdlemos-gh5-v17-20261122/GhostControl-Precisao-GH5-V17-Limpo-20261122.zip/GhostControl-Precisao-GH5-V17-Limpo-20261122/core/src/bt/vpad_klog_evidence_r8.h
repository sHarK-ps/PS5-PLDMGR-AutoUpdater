/* SPDX-License-Identifier: GPL-3.0-or-later */
#pragma once
#include <stdint.h>
/* Pure, host-testable classification of the LIVE AddDevice observation window.
 * No class here means that a virtual device definitively exists or not. */
typedef enum {
    GC_VPAD_KLOG_READ_ERROR,
    GC_VPAD_KLOG_EOF,
    GC_VPAD_KLOG_SILENT,
    GC_VPAD_KLOG_PARTIAL_LINE,
    GC_VPAD_KLOG_TRAFFIC_NO_DEVICE_EVENT,
    GC_VPAD_KLOG_EVENT_UNMATCHED,
    GC_VPAD_KLOG_EVENT_AMBIGUOUS,
    GC_VPAD_KLOG_ONE_CANDIDATE
} GcVpadKlogEvidence;
static inline GcVpadKlogEvidence gc_vpad_klog_evidence(
    uint64_t bytes, uint64_t lines, uint64_t device_added,
    int matches, int eof, int read_errno)
{
    if (read_errno) return GC_VPAD_KLOG_READ_ERROR;
    if (eof) return GC_VPAD_KLOG_EOF;
    if (!bytes) return GC_VPAD_KLOG_SILENT;
    if (!lines) return GC_VPAD_KLOG_PARTIAL_LINE;
    if (!device_added) return GC_VPAD_KLOG_TRAFFIC_NO_DEVICE_EVENT;
    if (matches == 0) return GC_VPAD_KLOG_EVENT_UNMATCHED;
    if (matches > 1) return GC_VPAD_KLOG_EVENT_AMBIGUOUS;
    return GC_VPAD_KLOG_ONE_CANDIDATE;
}
static inline const char *gc_vpad_klog_evidence_name(GcVpadKlogEvidence e)
{
    switch (e) {
    case GC_VPAD_KLOG_READ_ERROR: return "READ_ERROR";
    case GC_VPAD_KLOG_EOF: return "EOF";
    case GC_VPAD_KLOG_SILENT: return "SILENT";
    case GC_VPAD_KLOG_PARTIAL_LINE: return "PARTIAL_LINE";
    case GC_VPAD_KLOG_TRAFFIC_NO_DEVICE_EVENT: return "TRAFFIC_NO_DEVICE_ADDED";
    case GC_VPAD_KLOG_EVENT_UNMATCHED: return "DEVICE_ADDED_FILTER_UNMATCHED";
    case GC_VPAD_KLOG_EVENT_AMBIGUOUS: return "AMBIGUOUS";
    case GC_VPAD_KLOG_ONE_CANDIDATE: return "ONE_CANDIDATE";
    }
    return "INVALID";
}
