#include "gc_vda_klog.h"

#include <ctype.h>
#include <stdlib.h>
#include <string.h>

/* Native-app MBus parser; reject malformed identifiers. */
static int field_end(unsigned char c)
{
    return c == '\0' || c == ' ' || c == '\t' || c == '\r' ||
           c == '\n' || c == ',' || c == ']' || c == '}' ||
           c == ')' || c == ';';
}

static int identifier_byte(unsigned char c)
{
    return isalnum(c) || c == '_';
}

static const char *find_token(const char *line, const char *key, int whole_word)
{
    const size_t length = strlen(key);
    const char *p = line;
    while ((p = strstr(p, key)) != NULL) {
        if ((p == line || !identifier_byte((unsigned char)p[-1])) &&
            (!whole_word || !identifier_byte((unsigned char)p[length])))
            return p + length;
        p++;
    }
    return NULL;
}

static int token_number_is(const char *line, const char *key, unsigned want)
{
    const char *p = find_token(line, key, 0);
    char *end;
    unsigned long value;
    int base = 10;
    if (!p) return 0;
    while (*p == ' ' || *p == '\t') p++;
    if (p[0] == '0' && (p[1] == 'x' || p[1] == 'X')) base = 16;
    value = strtoul(p, &end, base);
    return end != p && value == want && field_end((unsigned char)*end);
}

static int parse_hex_after(const char *line, const char *first,
                           const char *second, uint64_t *value)
{
    const char *p = find_token(line, first, 0);
    uint64_t result = 0;
    unsigned digits = 0;
    if (!p && second) p = find_token(line, second, 0);
    if (!p) return 0;
    while (isxdigit((unsigned char)*p)) {
        const unsigned char c = (unsigned char)*p++;
        if (++digits > 16) return 0;
        result = (result << 4) | (uint64_t)(c <= '9' ? c - '0' :
                                               (c | 0x20) - 'a' + 10);
    }
    if (!digits || !result || !field_end((unsigned char)*p)) return 0;
    *value = result;
    return 1;
}

int gc_vda_klog_parse(const char *line, GcVdaKlogEvent *event)
{
    if (!line || !event) return 0;
    memset(event, 0, sizeof(*event));
    if (find_token(line, "DEVICE_ADDED", 1)) {
        const int legacy = token_number_is(line, "type:", 1) &&
                           token_number_is(line, "subType:", 22);
        const int modern = token_number_is(line, "deviceType=", 22);
        const char *bat = find_token(line, "capabilityBattery:", 0);
        /* Preserve the old legacy battery requirement. Modern lines can
         * omit that field; if supplied, it must be a valid zero token. */
        if ((modern || (legacy && bat)) &&
            (!bat || token_number_is(line, "capabilityBattery:", 0)) &&
            parse_hex_after(line, "DeviceId:0x", "deviceId=0x", &event->device_id)) {
            event->type = GC_VDA_KLOG_ADDED;
            return 1;
        }
    }
    if (find_token(line, "DEVICE_OWNER_CHANGED", 1)) {
        uint64_t device_id = 0;
        uint64_t user_id = 0;
        if (!parse_hex_after(line, "DeviceId:0x", "deviceId=0x", &device_id) ||
            !parse_hex_after(line, "UserId:0x", "userId=0x", &user_id) ||
            user_id > UINT32_MAX)
            return 0;
        event->type = GC_VDA_KLOG_OWNER_CHANGED;
        event->device_id = device_id;
        event->user_id = (int32_t)(uint32_t)user_id;
        return 1;
    }
    return 0;
}

int32_t gc_vda_select_handle(int32_t result, const int32_t output[6],
                             int32_t sentinel, uint64_t device_id)
{
    if (device_id)
        return (int32_t)(device_id & 0xffffffffu);
    if (result > 0)
        return result;
    for (int index = 0; index < 6; ++index)
        if (output[index] != sentinel && output[index] > 0)
            return output[index];
    return result < 0 ? result : -1;
}
