/* SPDX-License-Identifier: GPL-3.0-or-later */
#pragma once
/* Suppress repeated quarantine notices while keeping the very first notice,
 * and recover gracefully if a clock reset/mismatch is observed. */
static inline int gc_vpad_quarantine_notice_due_r9(long now, long *last_ms)
{
    if (!last_ms) return 0;
    if (*last_ms == 0 || now < *last_ms || now - *last_ms >= 5000) {
        *last_ms = now ? now : 1;
        return 1;
    }
    return 0;
}
