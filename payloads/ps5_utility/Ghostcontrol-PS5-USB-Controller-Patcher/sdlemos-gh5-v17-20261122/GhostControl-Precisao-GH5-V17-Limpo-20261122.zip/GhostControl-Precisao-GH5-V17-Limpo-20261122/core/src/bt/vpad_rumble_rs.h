/* SPDX-License-Identifier: GPL-3.0-or-later */
/* PR34 4fcb1fb: two classic-motor records in GetRemoteSetting, captured from
 * a real PS5 + USB DualShock 4. This parser does not imply Bluetooth output
 * or firmware-11.60 ABI validation. Offsets are zero-based. */
#ifndef GC_VPAD_RUMBLE_RS_H
#define GC_VPAD_RUMBLE_RS_H
#include <stddef.h>
#include <stdint.h>
enum {
    VPAD_RS_REC0_HDR = 10,
    VPAD_RS_REC0_VAL = 11,
    VPAD_RS_REC1_HDR = 21,
    VPAD_RS_REC1_VAL = 22,
    VPAD_RS_ACTIVE = 0x20,
    VPAD_RS_MIN_LEN = VPAD_RS_REC1_VAL + 1
};
static inline uint8_t vpad_rs_motor(const uint8_t *buf, int hdr, int val)
{
    return (buf[hdr] & VPAD_RS_ACTIVE) ? buf[val] : (uint8_t)0;
}
/* On invalid input the outputs are untouched. */
static inline int vpad_rs_decode(const uint8_t *buf, size_t len,
                                  uint8_t *strong, uint8_t *weak)
{
    if (!buf || !strong || !weak || len < (size_t)VPAD_RS_MIN_LEN) return 0;
    *strong = vpad_rs_motor(buf, VPAD_RS_REC0_HDR, VPAD_RS_REC0_VAL);
    *weak = vpad_rs_motor(buf, VPAD_RS_REC1_HDR, VPAD_RS_REC1_VAL);
    return 1;
}
#endif
