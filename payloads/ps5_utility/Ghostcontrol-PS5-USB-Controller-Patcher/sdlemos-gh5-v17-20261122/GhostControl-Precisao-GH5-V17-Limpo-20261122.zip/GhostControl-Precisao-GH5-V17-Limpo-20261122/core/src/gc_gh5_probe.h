/* SPDX-License-Identifier: GPL-3.0-or-later
 * R7 marker probe: recheck an absent marker; never unlatch an active probe.
 * A file is never created here. The marker must be placed by the tester.
 */
#pragma once
#include <stdint.h>
#include <errno.h>
#include <sys/stat.h>

#define GC_GH5_PROBE_RECHECK_MS UINT64_C(1000)
#define GC_GH5_PROBE_REMINDER_MS UINT64_C(15000)

enum {
    GC_GH5_MARKER_UNKNOWN = 0,
    GC_GH5_MARKER_MISSING = 1,
    GC_GH5_MARKER_NOT_FILE = 2,
    GC_GH5_MARKER_ENABLED = 3
};

typedef struct {
    uint64_t next_check_ms;
    uint64_t next_log_ms;
    unsigned checks;
    int enabled;
    int last_status;
    int last_errno;
} GcGh5ProbeState;

typedef struct {
    int checked;
    int report;
    int status;
    int error;
    uint64_t file_size;
    unsigned check_number;
} GcGh5ProbeObservation;

static inline const char *gc_gh5_marker_status(int status)
{
    switch (status) {
    case GC_GH5_MARKER_MISSING: return "missing-or-unreadable";
    case GC_GH5_MARKER_NOT_FILE: return "not-regular-file";
    case GC_GH5_MARKER_ENABLED: return "ENABLED";
    default: return "unknown";
    }
}

/* Work in the real code is one stat() per second while disabled.
 * Once enabled, the state is sticky for this process and never rechecks:
 * this prevents changing the virtual-pad publication policy mid-session.
 * The first check, any state/error transition and one 15-s reminder are logged.
 */
static inline GcGh5ProbeObservation gc_gh5_probe_step(
    GcGh5ProbeState *state, const char *path, uint64_t now_ms)
{
    GcGh5ProbeObservation out = {0};
    struct stat info;
    int status, error = 0;
    if (!state || !path) return out;
    if (state->enabled) { out.status = GC_GH5_MARKER_ENABLED; return out; }
    if (state->checks && now_ms < state->next_check_ms) {
        out.status = state->last_status;
        out.error = state->last_errno;
        return out;
    }
    errno = 0;
    if (stat(path, &info) != 0) {
        status = GC_GH5_MARKER_MISSING;
        error = errno;
    } else if (!S_ISREG(info.st_mode)) {
        status = GC_GH5_MARKER_NOT_FILE;
    } else {
        status = GC_GH5_MARKER_ENABLED;
        out.file_size = info.st_size < 0 ? 0 : (uint64_t)info.st_size;
    }
    out.checked = 1;
    out.status = status;
    out.error = error;
    out.report = !state->checks || status != state->last_status ||
                 error != state->last_errno || now_ms >= state->next_log_ms;
    state->last_status = status;
    state->last_errno = error;
    state->enabled = (status == GC_GH5_MARKER_ENABLED);
    ++state->checks;
    out.check_number = state->checks;
    state->next_check_ms = now_ms + GC_GH5_PROBE_RECHECK_MS;
    if (out.report) state->next_log_ms = now_ms + GC_GH5_PROBE_REMINDER_MS;
    return out;
}
