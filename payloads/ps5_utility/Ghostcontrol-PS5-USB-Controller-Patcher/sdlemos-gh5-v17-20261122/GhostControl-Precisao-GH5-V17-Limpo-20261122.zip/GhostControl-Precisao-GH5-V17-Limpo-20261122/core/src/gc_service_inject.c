/* SPDX-License-Identifier: GPL-3.0-or-later
 * Turns a service-owned USB or Bluetooth pad into a virtual DualSense.
 * Identification uses the kernel log line for the device this process just
 * added. It does not attach to another process.
 */
#include "gc_service_inject.h"
#include "gc_service_session_private.h"
#include "gc_service_features.h"
#include <stdatomic.h>
#include <stdlib.h>
#include "gc_config.h"
#include "gc_rawmap.h"
#include "gc_types.h"
#include "gc_usb.h"
#include "gc_usb_fallback.h"
#include "gc_usb_progress.h"
#include "gc_gh5_mode.h"
#include "gc_gh5_probe.h"
#include "controller_ds4.h"
#include "controller_mamba.h"
#include "controller_nintendo.h"
#include "controller_xbox.h"
#include "controller_ds3.h"
#include "usb_helpers.h"
#include <stdarg.h>
#include <stdint.h>
#include "ps5_vpad.h"
#include "host.h"
#include "log.h"
#include <dev/usb/usb.h>
#include <dev/usb/usb_ioctl.h>
#include <dev/usb/usbdi.h>
#include <errno.h>
#include <fcntl.h>
#include <limits.h>
#include <pthread.h>
#include <poll.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <unistd.h>

#define USB_SLOTS 4
#define USB_REPORT 64
#ifndef GC_GH5_USB_DIAGNOSTIC
#define GC_GH5_USB_DIAGNOSTIC 0
#endif
#ifndef GC_GH5_DIAGNOSTIC_LOG_LIMIT
#define GC_GH5_DIAGNOSTIC_LOG_LIMIT 256
#endif
#ifndef GC_GH5_PRECISION_DIAGNOSTIC
#define GC_GH5_PRECISION_DIAGNOSTIC 0
#endif
#define GH5_VPAD_PROBE_MARKER "/data/ghostcontrol-app-service/gh5-vpad-probe.enable"
#ifndef GC_GH5_TEST_TAG
#define GC_GH5_TEST_TAG "R5-unspecified"
#endif

static int inject_ready;
static int sources_active;
static uint64_t policy_generation[HOST_MAX_PADS];
static int bt_owned[HOST_MAX_PADS];
static int usb_owned[HOST_MAX_PADS];
/* Transport-local indices are not resident slot numbers. Claims/removal
 * fences share one mutex; a lost slot is reserved until teardown finishes. */
static int bt_map[GC_BT_MAX_PADS];
/* Process-lifetime per-producer history, deliberately not reset by close/init. */
static GcBtOrigin bt_seen[GC_BT_MAX_PADS];
static GcBtOrigin bt_active[GC_BT_MAX_PADS];
static int origin_valid(const GcBtOrigin *o)
{ return o && o->occurrence && o->handle <= 0xfff; }
static int origin_same(const GcBtOrigin *a, const GcBtOrigin *b)
{ return origin_valid(a) && b && a->occurrence == b->occurrence && a->handle == b->handle; }
static int bt_source[HOST_MAX_PADS];
static int slot_live[HOST_MAX_PADS];
static uint64_t slot_epoch[HOST_MAX_PADS];
/* Do not reset on init/close: a restarted resident loop must not reuse tokens. */
static uint64_t next_connection_generation;
static uint64_t next_occurrence_generation;
static pthread_once_t session_once = PTHREAD_ONCE_INIT;
static char process_session[GC_INSTANCE_SESSION_MAX];
static int session_ready;
static GcConfigStore *prepared_store;
static _Atomic int source_fault;
static _Thread_local unsigned source_depth;
static char candidate_selector[HOST_MAX_PADS][GC_INSTANCE_ID_MAX];
static int retirement_pending[HOST_MAX_PADS];
static int policy_revoked[HOST_MAX_PADS];
static void initialize_session(void)
{
    unsigned char random[16];
    static const char hex[] = "0123456789abcdef";
#if defined(__PROSPERO__)
    /* The PS5 SDK libc exports arc4random_buf but no getentropy. */
    arc4random_buf(random, sizeof random);
#else
    if (getentropy(random, sizeof random) != 0) return;
#endif
    for (size_t i = 0; i < sizeof random; ++i) {
        process_session[i*2] = hex[random[i] >> 4];
        process_session[i*2+1] = hex[random[i] & 15];
    }
    session_ready = 1;
}
static long add_retry_at[HOST_MAX_PADS];
static pad_state last_state[HOST_MAX_PADS];
static int last_valid[HOST_MAX_PADS];
/* One stderr note per slot while a device is owned but not yet decodable, so a
 * held-back virtual pad is explained once instead of every tick. */
static int no_input_noted[HOST_MAX_PADS];
static int binding_observed[HOST_MAX_PADS];
static uint16_t slot_vid[HOST_MAX_PADS];
static uint16_t slot_pid[HOST_MAX_PADS];
static int want_add[HOST_MAX_PADS];
static int want_remove[HOST_MAX_PADS];
static pad_state queued[HOST_MAX_PADS];
static int queued_valid[HOST_MAX_PADS];
static pthread_mutex_t inject_mu = PTHREAD_MUTEX_INITIALIZER;
static GcBt *inject_bt;
static GcConfigStore *inject_config;
static GcServiceSource source_info[HOST_MAX_PADS];
static uint8_t source_raw[HOST_MAX_PADS][GC_SERVICE_REPORT_MAX];
static size_t source_raw_length[HOST_MAX_PADS];
/* Descriptor-qualified physical values are separate from original normalized
 * input. The per-slot cache spans report IDs and is protected by inject_mu. */
static GcHidLayout source_hid_layout[HOST_MAX_PADS];
static GcHidState source_hid_values[HOST_MAX_PADS];
static int output_allowed[HOST_MAX_PADS];
static int backend_added[HOST_MAX_PADS];

/* Source transitions serialize with backend add/update, not with IPC readers.
 * Recursive only for same-thread source callbacks from a bounded backend call.
 * Lock order: config writer lease -> dispatch_mu -> inject_mu. Source callbacks
 * never take a config writer lease. No external operation holds inject_mu. */
static pthread_once_t dispatch_once = PTHREAD_ONCE_INIT;
static pthread_mutex_t dispatch_mu;
static int dispatch_ready;
static void initialize_dispatch(void)
{
    pthread_mutexattr_t attr;
    if (pthread_mutexattr_init(&attr) != 0) return;
    if (pthread_mutexattr_settype(&attr, PTHREAD_MUTEX_RECURSIVE) == 0 &&
        pthread_mutex_init(&dispatch_mu, &attr) == 0) dispatch_ready = 1;
    pthread_mutexattr_destroy(&attr);
}
static int source_dispatch_lock(void)
{
    if (pthread_once(&dispatch_once, initialize_dispatch) != 0 || !dispatch_ready) return 0;
    if (pthread_mutex_lock(&dispatch_mu) != 0) {
        atomic_store_explicit(&source_fault, 1, memory_order_release); return 0;
    }
    if (source_depth == UINT_MAX) {
        atomic_store_explicit(&source_fault, 1, memory_order_release);
        pthread_mutex_unlock(&dispatch_mu); return 0;
    }
    ++source_depth;
    return 1;
}
static void source_dispatch_unlock(void)
{
    if (!source_depth) abort();
    --source_depth;
    if (pthread_mutex_unlock(&dispatch_mu) != 0) abort();
}
/* Every cache/logical-state access shares the transition fence. The hook owns
 * that fence only, so it can clear state without snapshot/writer recursion. */
static void source_snapshot_lock(void)
{
    if (!source_dispatch_lock()) abort(); /* unrecoverable synchronization fault */
    if (pthread_mutex_lock(&inject_mu) != 0) abort();
}
static void source_snapshot_unlock(void)
{
    if (pthread_mutex_unlock(&inject_mu) != 0) abort();
    source_dispatch_unlock();
}
static int begin_dispatch(int slot, GcConfigStore *config, uint64_t generation,
                          uint64_t epoch, int needs_input)
{
    if (atomic_load_explicit(&source_fault, memory_order_acquire)) return 0;
    if (config && gc_config_policy_acquire(config, generation) != 0) return 0;
    if (!source_dispatch_lock()) {
        if (config) gc_config_policy_release(config);
        return 0;
    }
    source_snapshot_lock();
    int allowed = inject_config == config && inject_ready &&
        !retirement_pending[slot] && output_allowed[slot] && policy_generation[slot] == generation &&
        slot_epoch[slot] == epoch && source_info[slot].connected &&
        source_info[slot].output_type == GC_CONTROLLER_OUTPUT_DS5 &&
        (bt_owned[slot] || usb_owned[slot]) && !want_remove[slot] &&
        (!needs_input || last_valid[slot]);
    if (allowed && config && source_info[slot].binding.identity.state == GC_INSTANCE_STABLE) {
        GcControllerResolution resolved;
        if (gc_config_resolve_controller(config, &source_info[slot].binding, &resolved) != 0 ||
            (resolved.kind == GC_RESOLVE_INSTANCE &&
             gc_config_instance_check_held(config, GC_INSTANCE_REQUIRE_LIVE, NULL, 0) != 0)) allowed = 0;
    }
    source_snapshot_unlock();
    if (!allowed) {
        source_dispatch_unlock();
        if (config) gc_config_policy_release(config);
    }
    return allowed;
}
static void end_dispatch(GcConfigStore *config)
{
    source_dispatch_unlock();
    if (config) gc_config_policy_release(config);
}

void gc_service_inject_set_config(GcConfigStore *config)
{
    source_snapshot_lock();
    inject_config = config;
    /* NULL is a quiescent constructor/destructor operation, after unregister. */
    if (!config && !sources_active) prepared_store = NULL;
    source_snapshot_unlock();
}

/* Caller holds inject_mu. Never infer virtual identity from physical input. */
static void clear_sample(int slot)
{
    binding_observed[slot] = 0;
    memset(&source_info[slot], 0, sizeof source_info[slot]);
    memset(source_raw[slot], 0, sizeof source_raw[slot]);
    source_raw_length[slot] = 0;
    memset(&source_hid_layout[slot], 0, sizeof source_hid_layout[slot]);
    memset(&source_hid_values[slot], 0, sizeof source_hid_values[slot]);
    output_allowed[slot] = 0;
    policy_generation[slot] = 0;
    candidate_selector[slot][0] = 0;
}

static void raw_sample(int slot, const uint8_t *raw, size_t length)
{
    if (length > GC_SERVICE_REPORT_MAX) length = GC_SERVICE_REPORT_MAX;
    memcpy(source_raw[slot], raw, length);
    source_raw_length[slot] = length;
}

typedef struct {
    int used;
    int fd;
    int fd_owned, fs_initialized, close_uncertain;
    int slot;
    char path[32];
    uint16_t vid, pid;
    GcUsbInterfaceKind kind;
    int interface_index, interface_number, alternate_setting;
    uint8_t in_ep;
    uint8_t report[USB_REPORT];
    /* Two pipes: index 0 reads input, index 1 carries Nintendo output reports.
     * The array is registered with USB_FS_INIT and must outlive the session. */
    struct usb_fs_endpoint ep[2];
    uint8_t *bufp;
    uint32_t lenp;
    /* PR #32: request no more than one IN endpoint packet per USB_FS transfer. */
    uint32_t in_xfer_len;
    int busy;
    GcUsbFallback fallback; /* PR #29: per-connection fallback state */
    GcUsbProgress progress; /* upstream cd58070, per-connection observation only */
    /* Nintendo pads stay silent until 0x80 0x02 / 0x80 0x04 arrive, then speak
     * 0x30/0x3F. The handshake state machine is the resident line's proven one. */
    int nintendo;
    int hs_state;
    uint8_t nintendo_seq;
    unsigned char out_buf[64];
    uint32_t out_len;
    uint8_t *out_ptr;
    /* PR #32 protocol-specific state. Rhythm instruments (VID 12BA) are NOT DS3. */
    int gip;
    int gip_ready;
    XboxControllerState xbox;
    int ds4_out;
    int ds3;
    ScePadData decoded; /* Preserve controls split across HID report IDs. */
#if GC_GH5_PRECISION_DIAGNOSTIC
    /* Per-connection counters. Reset when this feed is reopened, never when
     * the operating system reuses the same numeric file descriptor. */
    uint64_t trace_generation;
    uint64_t trace_start_ok, trace_complete_ok, trace_ebusy;
    uint64_t trace_probe_skips, trace_neutral_frames;
    uint64_t trace_decode_attempts, trace_decode_success, trace_decode_failure;
    uint64_t trace_neutral_state_prepared;
    uint8_t trace_raw_prev[2][USB_REPORT];
    size_t trace_raw_prev_len[2];
    uint64_t trace_raw_seen[2], trace_raw_logged[2], trace_raw_dropped[2];
    uint64_t trace_raw_drop_total[2];
    uint64_t trace_raw_bucket_sec[2];
    unsigned trace_raw_bucket_count[2];
    uint64_t trace_started_ms, trace_last_complete_ms, trace_last_input_ms;
    uint64_t trace_last_summary_ms;
    int trace_completed_ep;
#endif
} UsbFeed;

static UsbFeed usb_feed[USB_SLOTS];
static uint64_t usb_progress_generation;
static uint64_t gc_fallback_now_ms(void);

/* Public PR #29 cd58070: independent, per-feed observation only.
 * "possible-stall" is a threshold, never a reset/retry instruction. */
static void usb_progress_log(UsbFeed *feed)
{
    if (feed->vid != 0x12ba || feed->pid != 0x0100) return;
    GcUsbProgress *p = &feed->progress;
    const uint64_t now = gc_fallback_now_ms();
    if (!gc_usb_progress_due(p, now)) return;
    const int suspect = gc_usb_progress_suspect(p, now);
    const int resumed = p->suspect && p->inputs != p->sampled_inputs;
    const char *phase = "observe";
    if (suspect)
        phase = "possible-stall";
    else if (p->suspect)
        phase = resumed ? "progress-resumed" : "awaiting-input";
    /* Count resumed input only after a valid report. */
    p->suspect = suspect || (p->suspect && !resumed);
    p->sampled_inputs = p->inputs;
    log_line("usb progress: generation=%llu path=%s fd=%d iface=%d endpoint_address=%#x transfer_index=0 phase=%s starts=%llu completions=%llu EBUSY=%llu complete_errors=%llu endpoint_errors=%llu frame_rejections=%llu inputs=%llu decoded=%llu rejected=%llu raw_only_skipped=%llu neutral_probe_frames=%llu decode_attempts=%llu decode_skipped=%llu neutral_probes=%llu busy=%d poll_revents=%#x outstanding_ms=%lld since_complete_ms=%lld since_input_ms=%lld GET_REPORT_attempts=%llu",
             (unsigned long long)p->generation, feed->path, feed->fd,
             feed->interface_number, feed->in_ep, phase,
             (unsigned long long)p->starts, (unsigned long long)p->completions,
             (unsigned long long)p->busy_returns, (unsigned long long)p->other_errors,
             (unsigned long long)p->endpoint_errors,
             (unsigned long long)p->frame_rejections,
             (unsigned long long)p->inputs, (unsigned long long)p->decoded,
             (unsigned long long)p->rejected,
             (unsigned long long)p->raw_only_skipped,
             (unsigned long long)p->neutral_probe_frames,
             (unsigned long long)p->decode_attempts,
             (unsigned long long)p->skipped,
             (unsigned long long)p->neutral_probes,
             feed->busy, p->poll_revents,
             p->outstanding ? (long long)gc_usb_progress_age(now, p->started_ms) : -1LL,
             p->have_completion ? (long long)gc_usb_progress_age(now, p->completed_ms) : -1LL,
             p->have_input ? (long long)gc_usb_progress_age(now, p->input_ms) : -1LL,
             (unsigned long long)feed->fallback.get_report_attempts);
}


/* Monotonic milliseconds shared by the upstream #29 fallback and GH5 traces. */
static uint64_t gc_fallback_now_ms(void)
{
    struct timespec ts;
    if (clock_gettime(CLOCK_MONOTONIC, &ts) != 0) return 0;
    return (uint64_t)ts.tv_sec * UINT64_C(1000) +
        (uint64_t)ts.tv_nsec / UINT64_C(1000000);
}


#if GC_GH5_PRECISION_DIAGNOSTIC
static uint64_t gh5_next_connection_generation;
static uint64_t gh5_clock_ms(void)
{
    struct timespec ts;
    if (clock_gettime(CLOCK_MONOTONIC, &ts) != 0) return 0;
    return (uint64_t)ts.tv_sec * UINT64_C(1000) +
           (uint64_t)ts.tv_nsec / UINT64_C(1000000);
}

/* Bounded one-second heartbeat: one line for each live Guitar Hero feed.
 * EBUSY is counted, not interpreted as a completed transfer. Metadata
 * describing completed frames is only printed after a successful ioctl. */
static void gh5_progress_summary(UsbFeed *feed, int force)
{
    if (!feed->used || feed->vid != 0x12ba || feed->pid != 0x0100) return;
    const uint64_t now = gh5_clock_ms();
    if (!now) return;
    if (!force && feed->trace_last_summary_ms &&
        now - feed->trace_last_summary_ms < UINT64_C(1000)) return;
    const long long since_complete = feed->trace_last_complete_ms
        ? (long long)(now - feed->trace_last_complete_ms) : -1;
    const long long since_input = feed->trace_last_input_ms
        ? (long long)(now - feed->trace_last_input_ms) : -1;
    const long long outstanding_age = feed->busy && feed->trace_started_ms
        ? (long long)(now - feed->trace_started_ms) : -1;
    log_line("gh5: progress generation=%llu path=%s fd=%d iface=%d/%d ep=0x%02x slot=%d START_ok=%llu COMPLETE_ok=%llu EBUSY=%llu interrupt_received=%llu GET_REPORT_attempts=%llu GET_REPORT_ok=%llu GET_REPORT_failed=%llu probe_disabled_skips=%llu neutral_probe_frames=%llu decode_attempts=%llu decode_success=%llu decode_failure=%llu neutral_state_prepared=%llu RAW_interrupt_logged=%llu RAW_control_logged=%llu RAW_interrupt_dropped=%llu RAW_control_dropped=%llu since_complete_ms=%lld since_input_ms=%lld outstanding_ms=%lld busy=%d last_completed_transfer_index=%d",
        (unsigned long long)feed->trace_generation, feed->path, feed->fd,
        feed->interface_index, feed->interface_number, (unsigned)feed->in_ep,
        feed->slot, (unsigned long long)feed->trace_start_ok,
        (unsigned long long)feed->trace_complete_ok,
        (unsigned long long)feed->trace_ebusy,
        (unsigned long long)feed->fallback.interrupt_in_received,
        (unsigned long long)feed->fallback.get_report_attempts,
        (unsigned long long)feed->fallback.get_report_successes,
        (unsigned long long)feed->fallback.get_report_failures,
        (unsigned long long)feed->trace_probe_skips,
        (unsigned long long)feed->trace_neutral_frames,
        (unsigned long long)feed->trace_decode_attempts,
        (unsigned long long)feed->trace_decode_success,
        (unsigned long long)feed->trace_decode_failure,
        (unsigned long long)feed->trace_neutral_state_prepared,
        (unsigned long long)feed->trace_raw_logged[0],
        (unsigned long long)feed->trace_raw_logged[1],
        (unsigned long long)feed->trace_raw_drop_total[0],
        (unsigned long long)feed->trace_raw_drop_total[1],
        since_complete, since_input, outstanding_age, feed->busy,
        feed->trace_completed_ep);
    feed->trace_last_summary_ms = now;
}
#endif

/* GIP device initialization must not run synchronously from usb_tick(): that
 * tick is protected by source_dispatch_lock and the handshake can wait 1.6 s.
 * A worker owns the handshake while the feed is marked pending; the normal
 * USB loop resumes only after the worker publishes completion. */
static pthread_t gip_worker_threads[USB_SLOTS];
static _Atomic int gip_worker_state[USB_SLOTS]; /* 0 idle, 1 running, 2 done */
static _Atomic int gip_worker_cancel[USB_SLOTS];
static _Atomic int gip_worker_result[USB_SLOTS];
static int gip_worker_joinable[USB_SLOTS];

static int gip_worker_keep_running(void *context)
{
    const intptr_t slot = (intptr_t)context;
    return slot >= 0 && slot < USB_SLOTS &&
        !atomic_load_explicit(&gip_worker_cancel[slot], memory_order_acquire);
}

static void *gip_handshake_worker(void *context)
{
    const int slot = (int)(intptr_t)context;
    UsbFeed *feed = &usb_feed[slot];
    const int result = xbox_gip_handshake(feed->fd, feed->ep, feed->vid, feed->pid,
        &feed->xbox, gip_worker_keep_running, context);
    atomic_store_explicit(&gip_worker_result[slot], result, memory_order_relaxed);
    atomic_store_explicit(&gip_worker_state[slot], 2, memory_order_release);
    return NULL;
}

/* Called only by the service thread. On cancellation the GIP helper checks
 * the callback at <=20 ms intervals and drains USB_FS cancellation through its
 * bounded cancel path, rather than holding source_dispatch_lock for 1.6 s. */
static int gip_worker_join(UsbFeed *feed, int cancel, int *result_out)
{
    const int slot = (int)(feed - usb_feed);
    if (slot < 0 || slot >= USB_SLOTS || !gip_worker_joinable[slot]) {
        if (result_out) *result_out = 0;
        return 0;
    }
    if (cancel)
        atomic_store_explicit(&gip_worker_cancel[slot], 1, memory_order_release);
    const int rc = pthread_join(gip_worker_threads[slot], NULL);
    if (rc != 0) {
        log_line("usb: %s GIP worker join failed rc=%d; keeping USB handle open",
                 feed->path, rc);
        feed->close_uncertain = 1;
        return -1;
    }
    gip_worker_joinable[slot] = 0;
    if (result_out)
        *result_out = atomic_load_explicit(&gip_worker_result[slot], memory_order_acquire);
    atomic_store_explicit(&gip_worker_state[slot], 0, memory_order_release);
    atomic_store_explicit(&gip_worker_cancel[slot], 0, memory_order_release);
    return 1;
}

static int usb_release_fd(UsbFeed *feed)
{
    if (feed->close_uncertain) return -1;
    if (!feed->fd_owned) return 0;
    if (feed->fs_initialized) {
        struct usb_fs_uninit un;
        memset(&un, 0, sizeof un);
        if (ioctl(feed->fd, USB_FS_UNINIT, &un) != 0) {
            const int err = errno;
            if (err != ENXIO && err != ENODEV && err != ENOTTY) return -1;
            log_line("usb: %s FS_UNINIT errno=%d: device gone, closing handle",
                     feed->path, err);
        }
        feed->fs_initialized = 0;
    }
    if (close(feed->fd) != 0) { feed->close_uncertain = 1; return -1; }
    feed->fd_owned = 0;
    feed->fd = -1;
    return 0;
}

static void remember(int slot, const pad_state *st, uint16_t vid, uint16_t pid)
{
    if (slot < 0 || slot >= HOST_MAX_PADS || !st) return;
    source_snapshot_lock();
    last_state[slot] = *st;
    last_valid[slot] = binding_observed[slot] = 1;
    if (vid) slot_vid[slot] = vid;
    if (pid) slot_pid[slot] = pid;
    source_snapshot_unlock();
}

/* Caller holds inject_mu. Reserve a source slot before calling any backend. */
static int available_slot(int preferred)
{
    if (preferred >= 0 && preferred < HOST_MAX_PADS &&
        !bt_owned[preferred] && !usb_owned[preferred] && !want_remove[preferred])
        return preferred;
    for (int slot = 0; slot < HOST_MAX_PADS; ++slot)
        if (!bt_owned[slot] && !usb_owned[slot] && !want_remove[slot]) return slot;
    return -1;
}

static void retire_samples(int slot);

/* Caller holds inject_mu. Snapshot intent even before the first resident tick. */
static void describe_output(int slot)
{
    GcServiceSource *info = &source_info[slot];
    GcControllerResolution resolved = {0};
    int found = inject_config ? gc_config_resolve_controller(inject_config, &info->binding, &resolved) : 0;
    uint64_t generation = resolved.generation;
    if (policy_generation[slot] && generation != policy_generation[slot]) {
        int observed = binding_observed[slot];
        retire_samples(slot);
        binding_observed[slot] = observed; /* publication is not physical revocation */
        for (int i = 0; i < USB_SLOTS; ++i) if (usb_feed[i].used && usb_feed[i].slot == slot) {
            memset(&usb_feed[i].decoded, 0, sizeof usb_feed[i].decoded);
            usb_feed[i].decoded.leftStick.x = usb_feed[i].decoded.leftStick.y = 128;
            usb_feed[i].decoded.rightStick.x = usb_feed[i].decoded.rightStick.y = 128;
        }
    }
    info->output_type = resolved.has_rule ? resolved.rule.output_type : GC_CONTROLLER_OUTPUT_DS5;
    const char *error = slot_live[slot] ? "" : "backend_pending";
    if (found != 0) error = "source_binding_mismatch";
    else if (resolved.kind == GC_RESOLVE_POLICY_UNAVAILABLE) error = "instance_policy_quarantined";
    else if (info->binding.identity.state == GC_INSTANCE_COLLISION || resolved.kind == GC_RESOLVE_IDENTITY_COLLISION) error = "identity_collision";
    else if (resolved.kind == GC_RESOLVE_IDENTITY_UNAVAILABLE) error = "identity_unavailable";
    else if (resolved.kind == GC_RESOLVE_BINDING_MISMATCH) error = "source_binding_mismatch";
    else if (resolved.kind == GC_RESOLVE_PROFILE_UNAVAILABLE) error = "profile_association_unavailable";
    else if (resolved.kind == GC_RESOLVE_VETO) error = "disabled_or_ignored";
    else if (info->output_type != GC_CONTROLLER_OUTPUT_DS5) error = "unsupported_output_type";
    else if (!inject_ready) error = "backend_unavailable";
    if (retirement_pending[slot]) error = "output_retirement_pending";
    if (policy_revoked[slot]) error = "instance_policy_quarantined";
    if (atomic_load_explicit(&source_fault, memory_order_acquire)) error = "instance_capability_unavailable";
    policy_generation[slot] = generation;
    snprintf(info->output_error, sizeof info->output_error, "%s", error);
    int allowed = !*error || !strcmp(error, "backend_pending");
    if (output_allowed[slot] != allowed) {
        output_allowed[slot] = allowed;
        add_retry_at[slot] = 0;
        want_add[slot] = allowed;
    }
    if (!allowed) slot_live[slot] = 0;
}

/* Transition-fenced retirement preserves inventory, never cached input. */
static void retire_samples(int slot)
{
    binding_observed[slot] = 0;
    memset(&last_state[slot], 0, sizeof last_state[slot]);
    memset(&queued[slot], 0, sizeof queued[slot]);
    last_valid[slot] = queued_valid[slot] = slot_live[slot] = 0;
    source_info[slot].input_available = source_info[slot].virtual_live = 0;
    memset(source_raw[slot], 0, sizeof source_raw[slot]); source_raw_length[slot] = 0;
    memset(&source_hid_values[slot], 0, sizeof source_hid_values[slot]);
    memset(&source_hid_layout[slot], 0, sizeof source_hid_layout[slot]);
    output_allowed[slot] = want_add[slot] = 0;
    policy_generation[slot] = 0;
    fprintf(stderr, "inject: slot %d retire_samples (backend_added=%d)\n", slot, backend_added[slot]);
    retirement_pending[slot] = backend_added[slot];
}
static void binding_common(int slot, GcInstanceTransport transport, uint64_t occurrence)
{
    GcServiceSource *info = &source_info[slot];
    GcControllerMatch *m = &info->binding;
    memset(m, 0, sizeof *m);
    m->transport = transport;
    snprintf(m->session_id, sizeof m->session_id, "%s", process_session);
    snprintf(m->path, sizeof m->path, "%s", info->path);
    snprintf(m->protocol, sizeof m->protocol, "%s", info->protocol);
    m->vid = info->vid; m->pid = info->pid;
    m->connection_generation = info->connection_generation;
    m->occurrence_generation = occurrence;
    m->interface_index = m->interface_number = m->alternate_setting = -1;
}
static void reevaluate_collisions(void)
{
    for (int slot = 0; slot < HOST_MAX_PADS; ++slot) {
        if (!source_info[slot].connected || !candidate_selector[slot][0]) continue;
        int collision = 0;
        for (int other = 0; other < HOST_MAX_PADS; ++other)
            if (other != slot && source_info[other].connected &&
                candidate_selector[other][0] &&
                source_info[other].binding.occurrence_generation != source_info[slot].binding.occurrence_generation &&
                !strcmp(candidate_selector[slot], candidate_selector[other])) collision = 1;
        GcControllerIdentity *id = &source_info[slot].binding.identity;
        GcInstanceState next = collision ? GC_INSTANCE_COLLISION : GC_INSTANCE_STABLE;
        if (id->state != next) retire_samples(slot);
        id->state = next;
        id->proof = collision ? GC_INSTANCE_PROOF_NONE : GC_INSTANCE_PROOF_CLASSIC_PEER;
        snprintf(id->instance_id, sizeof id->instance_id, "%s", collision ? "" : candidate_selector[slot]);
    }
}

/* Caller owns the source transition/snapshot fence. History survives retirement. */
static void retire_bt(int source)
{
    int slot = bt_map[source];
    bt_map[source] = -1;
    memset(&bt_active[source], 0, sizeof bt_active[source]);
    if (slot < 0) return;
    ++slot_epoch[slot]; want_remove[slot] = 1; want_add[slot] = 0;
    queued_valid[slot] = last_valid[slot] = slot_live[slot] = 0;
    memset(&queued[slot], 0, sizeof queued[slot]);
    memset(&last_state[slot], 0, sizeof last_state[slot]);
    slot_vid[slot] = slot_pid[slot] = 0;
    clear_sample(slot);
}
static int on_ready(void *ud, int source, const GcBtOrigin *origin, const GcBtController *controller)
{
    int slot;
    (void)ud;
    if (source < 0 || source >= GC_BT_MAX_PADS || !controller || !origin_valid(origin)) return -1;
    if (!source_dispatch_lock()) return -1;
    source_snapshot_lock();
    int existing = bt_map[source];
    int refresh = existing >= 0 && origin_same(origin, &bt_active[source]);
    if (!refresh && origin->occurrence <= bt_seen[source].occurrence) {
        source_snapshot_unlock(); source_dispatch_unlock(); return -1;
    }
    if (!refresh) {
        bt_seen[source] = *origin; /* failed adoption is also nonauthorizing history */
        if (existing >= 0) { retire_bt(source); reevaluate_collisions(); }
        existing = -1;
    }
    if (!sources_active || (existing < 0 && (
        next_connection_generation == UINT64_MAX || next_occurrence_generation == UINT64_MAX ||
        (slot = available_slot(source)) < 0))) {
        source_snapshot_unlock();
        source_dispatch_unlock();
        return -1;
    }
    uint64_t connection, occurrence;
    if (existing >= 0) {
        slot = existing;
        connection = source_info[slot].connection_generation;
        occurrence = source_info[slot].binding.occurrence_generation;
        retire_samples(slot);
    } else {
        connection = ++next_connection_generation;
        occurrence = ++next_occurrence_generation;
    }
    bt_map[source] = slot;
    bt_active[source] = *origin;
    bt_source[slot] = source;
    bt_owned[slot] = 1;
    ++slot_epoch[slot];
    want_add[slot] = 1;
    add_retry_at[slot] = 0;
    queued_valid[slot] = last_valid[slot] = slot_live[slot] = 0;
    slot_vid[slot] = controller->vid;
    slot_pid[slot] = controller->pid;
    clear_sample(slot);
    GcServiceSource *info = &source_info[slot];
    info->connection_generation = connection;
    snprintf(info->path, sizeof info->path, "bt-%02X:%02X:%02X:%02X:%02X:%02X",
             controller->addr[0], controller->addr[1], controller->addr[2],
             controller->addr[3], controller->addr[4], controller->addr[5]);
    /* Host profile is a display name, not a persisted protocol token. BT
     * controllers otherwise arrive through HID, not USB Xbox GIP/XUSB. */
    snprintf(info->protocol, sizeof info->protocol, "%s",
             ds4_is_compatible_vidpid(controller->vid, controller->pid) ||
             !strcmp(controller->profile, "DualShock 4") ||
             !strcmp(controller->profile, "ds4") ? "ds4" : "hid");
    snprintf(info->name, sizeof info->name, "%s", controller->profile);
    snprintf(info->transport, sizeof info->transport, "bluetooth");
    info->vid = controller->vid; info->pid = controller->pid;
    info->slot = slot; info->connected = 1;
    binding_common(slot, controller->instance_transport, occurrence);
    unsigned nonzero = 0, nonff = 0;
    for (size_t i = 0; i < 6; ++i) { nonzero |= controller->addr[i]; nonff |= controller->addr[i] ^ 255u; }
    if (session_ready && nonzero && nonff &&
        controller->instance_transport == GC_INSTANCE_TRANSPORT_CLASSIC &&
        controller->instance_proof == GC_INSTANCE_PROOF_CLASSIC_PEER) {
        snprintf(candidate_selector[slot], sizeof candidate_selector[slot],
                 "bt-classic:%02X%02X%02X%02X%02X%02X", controller->addr[0],
                 controller->addr[1], controller->addr[2], controller->addr[3], controller->addr[4], controller->addr[5]);
    }
    reevaluate_collisions();
    describe_output(slot);
    source_snapshot_unlock();
    source_dispatch_unlock();
    return 0;
}

static void on_state(void *ud, int slot, const GcBtOrigin *origin, const GcBtPad *pad)
{
    pad_state st;
    (void)ud;
    if (!pad || slot < 0 || slot >= HOST_MAX_PADS) return;
    memset(&st, 0, sizeof st);
    st.buttons = pad->buttons;
    st.lx = pad->lx;
    st.ly = pad->ly;
    st.rx = pad->rx;
    st.ry = pad->ry;
    st.l2 = pad->l2;
    st.r2 = pad->r2;
    st.has_motion = pad->has_motion;
    if (pad->has_motion) {
        memcpy(st.gyro, pad->gyro, sizeof st.gyro);
        memcpy(st.accel, pad->accel, sizeof st.accel);
    }
    st.has_touch = pad->has_touch;
    for (int i = 0; i < 2; ++i) {
        st.touch[i].down = pad->touch[i].down;
        st.touch[i].x = pad->touch[i].x;
        st.touch[i].y = pad->touch[i].y;
    }
    source_snapshot_lock();
    slot = origin_same(origin, &bt_active[slot]) ? bt_map[slot] : -1;
    if (slot >= 0 && bt_owned[slot] && !want_remove[slot] &&
        source_info[slot].binding.identity.state != GC_INSTANCE_COLLISION &&
        !policy_revoked[slot] && !atomic_load_explicit(&source_fault, memory_order_acquire)) {
        queued[slot] = st;
        queued_valid[slot] = 1;
        last_state[slot] = st;
        last_valid[slot] = binding_observed[slot] = 1;
        source_info[slot].input_available = 1;
    }
    source_snapshot_unlock();
}

static void on_report(void *ud, int source, const GcBtOrigin *origin, const uint8_t *raw, int length)
{
    (void)ud;
    if (!raw || length <= 0 || source < 0 || source >= GC_BT_MAX_PADS) return;
    source_snapshot_lock();
    int slot = origin_same(origin, &bt_active[source]) ? bt_map[source] : -1;
    if (slot >= 0 && bt_owned[slot] && !want_remove[slot] &&
        source_info[slot].binding.identity.state != GC_INSTANCE_COLLISION &&
        !policy_revoked[slot] && !atomic_load_explicit(&source_fault, memory_order_acquire))
        raw_sample(slot, raw, (size_t)length);
    source_snapshot_unlock();
}

static void on_lost(void *ud, int source, const GcBtOrigin *origin)
{
    (void)ud;
    if (source < 0 || source >= GC_BT_MAX_PADS) return;
    if (!source_dispatch_lock()) return;
    source_snapshot_lock();
    if (origin_same(origin, &bt_active[source])) {
        retire_bt(source);
        reevaluate_collisions();
    }
    source_snapshot_unlock();
    source_dispatch_unlock();
}

static const GcBtOps inject_ops = {
    NULL, on_ready, on_report, on_state, on_lost
};

const GcBtOps *gc_service_inject_ops(void)
{
    return &inject_ops;
}

void gc_service_inject_set_bt(GcBt *bt)
{
    source_snapshot_lock();
    inject_bt = bt;
    source_snapshot_unlock();
}

static void clear_source_cache(void)
{
    source_snapshot_lock();
    memset(bt_active, 0, sizeof bt_active);
    memset(bt_owned, 0, sizeof bt_owned);
    memset(usb_owned, 0, sizeof usb_owned);
    memset(last_state, 0, sizeof last_state);
    memset(last_valid, 0, sizeof last_valid);
    memset(slot_vid, 0, sizeof slot_vid);
    memset(slot_pid, 0, sizeof slot_pid);
    memset(want_add, 0, sizeof want_add);
    memset(want_remove, 0, sizeof want_remove);
    memset(queued, 0, sizeof queued);
    memset(queued_valid, 0, sizeof queued_valid);
    memset(slot_live, 0, sizeof slot_live);
    memset(slot_epoch, 0, sizeof slot_epoch);
    memset(add_retry_at, 0, sizeof add_retry_at);
    memset(backend_added, 0, sizeof backend_added);
    memset(retirement_pending, 0, sizeof retirement_pending);
    memset(policy_revoked, 0, sizeof policy_revoked);
    for (int slot = 0; slot < HOST_MAX_PADS; ++slot) clear_sample(slot);
    for (int i = 0; i < GC_BT_MAX_PADS; ++i) bt_map[i] = -1;
    for (int i = 0; i < HOST_MAX_PADS; ++i) bt_source[i] = -1;
    source_snapshot_unlock();
}

void gc_service_inject_init(void)
{
    int i;
    if (sources_active && gc_service_inject_close_checked() != 0) return;
    for (i = 0; i < USB_SLOTS; ++i)
        if (usb_feed[i].fd_owned || usb_feed[i].close_uncertain) return;
    if (pthread_once(&session_once, initialize_session) != 0) session_ready = 0;
    if (!source_dispatch_lock()) return;
    clear_source_cache();
    for (i = 0; i < USB_SLOTS; ++i) usb_feed[i].fd = -1;
    sources_active = 1;
    inject_ready = vpad_init();
    /* Public GH5 mode defaults to mapped; the PRIVATE capture interception
     * overrides it, so never advertise a private RAW ELF as mapped gameplay. */
    const char *gh5_runtime_mode = gc_gh5_mode_name();
#if GC_GH5_USB_DIAGNOSTIC
    gh5_runtime_mode = "private-RAW-or-marker-neutral";
#endif
    log_line("GH5 build: variant=%s source=%s mode=%s receiver=12ba:0100 "
             "testtag=%s (not an ELF hash)",
             GC_BUILD_VARIANT, GC_BUILD_REVISION, gh5_runtime_mode,
             GC_GH5_TEST_TAG);
    if (!inject_ready) {
        fprintf(stderr, "inject: virtual DualSense setup did not start\n");
    } else {
        fprintf(stderr, "inject: backend initialized; no virtual device confirmed yet\n");
    }
    source_dispatch_unlock();
}

const char *gc_service_inject_release_blocker(void)
{
    if (!source_dispatch_lock()) return "inject_dispatch_unavailable";
    const char *why = NULL;
    for (int i = 0; i < USB_SLOTS; ++i)
        if (usb_feed[i].close_uncertain) { why = "inject_usb_close_uncertain"; break; }
    if (!why) why = vpad_release_blocker();
    source_dispatch_unlock();
    return why;
}
int gc_service_inject_close_checked(void)
{
    if (!source_dispatch_lock()) return -1;
    for (int i = 0; i < USB_SLOTS; ++i) {
        /* PR32 f93df51 shutdown parity: join a live handshake BEFORE freeing
         * fd/endpoint buffers. Never close a worker-owned USB handle. */
        if (gip_worker_joinable[i] && gip_worker_join(&usb_feed[i], 1, NULL) < 0) {
            source_dispatch_unlock(); return -1;
        }
        if (usb_release_fd(&usb_feed[i]) != 0) {
            source_dispatch_unlock(); return -1;
        }
        if (usb_feed[i].path[0]) gc_usb_hid_layout_forget(usb_feed[i].path);
    }
    if (vpad_shutdown_checked() != 0) { source_dispatch_unlock(); return -1; }
    memset(usb_feed, 0, sizeof usb_feed);
    for (int i = 0; i < USB_SLOTS; ++i) usb_feed[i].fd = -1;
    inject_ready = 0;
    sources_active = 0;
    inject_bt = NULL;
    clear_source_cache();
    source_dispatch_unlock();
    return 0;
}
void gc_service_inject_close(void) { (void)gc_service_inject_close_checked(); }

static void apply_bt(long now)
{
    for (int slot = 0; slot < HOST_MAX_PADS; ++slot) {
        int remove, add;
        uint64_t epoch, generation;
        GcConfigStore *config;
        if (!source_dispatch_lock()) continue;
        source_snapshot_lock();
        remove = want_remove[slot];
        epoch = slot_epoch[slot];
        source_snapshot_unlock();
        if (remove) {
            if (inject_ready) vpad_remove(slot);
            source_snapshot_lock();
            if (epoch == slot_epoch[slot]) {
                want_remove[slot] = bt_owned[slot] = backend_added[slot] = 0;
                bt_source[slot] = -1;
            }
            source_snapshot_unlock();
            source_dispatch_unlock();
            continue;
        }
        source_dispatch_unlock();
        source_snapshot_lock();
        epoch = slot_epoch[slot];
        generation = policy_generation[slot];
        config = inject_config;
        add = inject_ready && bt_owned[slot] && output_allowed[slot] &&
              want_add[slot] && now >= add_retry_at[slot] &&
              !vpad_add_is_quarantined(slot);
        source_snapshot_unlock();
        if (add && begin_dispatch(slot, config, generation, epoch, 0)) {
            int accepted = vpad_add(slot);
            source_snapshot_lock();
            if (epoch == slot_epoch[slot] && !want_remove[slot]) {
                if (accepted) { want_add[slot] = 0; backend_added[slot] = 1; }
                else add_retry_at[slot] = now + 1000;
            }
            source_snapshot_unlock();
            end_dispatch(config);
            if (!accepted) fprintf(stderr, "inject: backend add slot %d refused; retry pending\n", slot);
        }
        source_snapshot_lock();
        if (bt_owned[slot] && !want_remove[slot] && queued_valid[slot]) {
            last_state[slot] = queued[slot];
            last_valid[slot] = binding_observed[slot] = 1;
            queued_valid[slot] = 0;
        }
        source_snapshot_unlock();
    }
}

/* The reservation is atomic with the Bluetooth ready callback. */
static int free_slot(void)
{
    int slot;
    if (!source_dispatch_lock()) return -1;
    source_snapshot_lock();
    slot = next_connection_generation == UINT64_MAX || next_occurrence_generation == UINT64_MAX ? -1 : available_slot(-1);
    if (slot >= 0) {
        usb_owned[slot] = 1;
        ++slot_epoch[slot];
        last_valid[slot] = slot_live[slot] = 0;
        clear_sample(slot);
        source_info[slot].connection_generation = ++next_connection_generation;
    }
    source_snapshot_unlock();
    source_dispatch_unlock();
    return slot;
}

/* Read one coherent configuration generation before publishing output policy.
 * Source epochs remain independent: policy edits never release physical slots. */
static void refresh_policy(void)
{
    source_snapshot_lock();
    for (int slot = 0; slot < HOST_MAX_PADS; ++slot) {
        GcServiceSource *info = &source_info[slot];
        if (!info->connected || want_remove[slot]) continue;
        describe_output(slot);
    }
    source_snapshot_unlock();
    /* Removal runs outside the snapshot lock: backend callbacks may lose sources. */
    for (int slot = 0; slot < HOST_MAX_PADS; ++slot) {
        if (!source_dispatch_lock()) continue;
        source_snapshot_lock();
        int remove = backend_added[slot] && !output_allowed[slot] && !want_remove[slot];
        if (remove) backend_added[slot] = 0;
        source_snapshot_unlock();
        if (remove && inject_ready) vpad_remove(slot);
        source_dispatch_unlock();
    }
}

/* Caller holds inject_mu: physical values and original input share a slot. */
static void remap_state(int slot, const GcProfile *profile, pad_state *state)
{
    ScePadData pad;
    memset(&pad, 0, sizeof pad);
    pad.buttons = state->buttons;
    pad.leftStick.x = state->lx; pad.leftStick.y = state->ly;
    pad.rightStick.x = state->rx; pad.rightStick.y = state->ry;
    pad.analogButtons.l2 = state->l2; pad.analogButtons.r2 = state->r2;
    if (!strcmp(source_info[slot].protocol, "hid") && source_hid_values[slot].count)
        gc_hid_apply_profile_values(&source_hid_layout[slot],
            source_hid_values[slot].values, source_hid_values[slot].count, profile, &pad);
    /* Physical bindings precede semantic transforms; neither touches source input. */
    gc_profile_apply(profile, &pad);
    state->buttons = pad.buttons;
    state->lx = pad.leftStick.x; state->ly = pad.leftStick.y;
    state->rx = pad.rightStick.x; state->ry = pad.rightStick.y;
    state->l2 = pad.analogButtons.l2; state->r2 = pad.analogButtons.r2;
}

/* PR34 4fcb1fb is opt-in: prevent duplicate native-DS4 output while #29
 * and the user/firmware's transport mapping have not been hardware checked. */
#ifndef GC_VPAD_RUMBLE_READBACK
#define GC_VPAD_RUMBLE_READBACK 0
#endif
#if GC_VPAD_RUMBLE_READBACK
/* Mirrors the existing BT host initialization palette. Only known/admitted
 * BT origins reach gc_bt_set_output; origin generations reset cached levels. */
static const struct { uint8_t r, g, b, player; } k_source_colour[GC_BT_MAX_PADS] = {
    {0x00,0x00,0x40,1}, {0x40,0x00,0x00,2},
    {0x00,0x40,0x00,3}, {0x20,0x00,0x20,4}
};
static void feed_source_rumble(GcBt *bt, int source, int slot,
                                const GcBtOrigin *origin, int live)
{
    static GcBtOrigin last_origin[GC_BT_MAX_PADS];
    static uint8_t last_strong[GC_BT_MAX_PADS],last_weak[GC_BT_MAX_PADS];
    static int have_last[GC_BT_MAX_PADS];
    uint8_t strong=0,weak=0;
    if (source < 0 || source >= GC_BT_MAX_PADS || !bt) return;
    if (!origin_same(origin,&last_origin[source])) have_last[source]=0;
    if (!live || slot < 0) { have_last[source]=0;return; }
    /* API failure => explicitly request STOP if this owner had live motors. */
    if (!vpad_rumble(slot,&strong,&weak)) {strong=0;weak=0;}
    if (have_last[source] && strong==last_strong[source] && weak==last_weak[source])
        return;
    last_origin[source]=*origin;
    last_strong[source]=strong;last_weak[source]=weak;have_last[source]=1;
    gc_bt_set_output(bt,source,origin,strong,weak,
        k_source_colour[source].r,k_source_colour[source].g,
        k_source_colour[source].b,k_source_colour[source].player);
}
#endif

static void push_sources(void)
{
    for (int slot = 0; slot < HOST_MAX_PADS; ++slot) {
        pad_state state;
        uint64_t epoch;
        int active, valid, live;
        source_snapshot_lock();
        active = inject_ready && output_allowed[slot] &&
                 (bt_owned[slot] || usb_owned[slot]) && !want_remove[slot];
        valid = last_valid[slot];
        state = last_state[slot];
        epoch = slot_epoch[slot];
        GcConfigStore *config = inject_config;
        GcControllerResolution resolved = {0};
        int result = config ? gc_config_resolve_controller(config, &source_info[slot].binding, &resolved) : 0;
        uint64_t generation = resolved.generation;
        if (result || (config && generation != policy_generation[slot]) ||
            (resolved.kind != GC_RESOLVE_NONE && resolved.kind != GC_RESOLVE_MODEL && resolved.kind != GC_RESOLVE_INSTANCE)) active = 0;
        if (resolved.has_profile) remap_state(slot, &resolved.profile, &state);
        source_snapshot_unlock();
        live = active && vpad_live(slot);
        if (live && valid) {
            /* Probe first; exclude store commits only across bounded dispatch.
             * Backend operations must not mutate/join writers on this store. */
            if (begin_dispatch(slot, config, generation, epoch, 1)) {
                vpad_update(slot, &state);
                end_dispatch(config);
                live = vpad_live(slot);
                if (config && gc_config_generation(config) != generation) live = 0;
            } else live = 0;
        }
        source_snapshot_lock();
        if (epoch == slot_epoch[slot] && !want_remove[slot]) {
            slot_live[slot] = live;
            source_info[slot].virtual_live = live;
            source_info[slot].input_available = last_valid[slot];
            if (output_allowed[slot])
                snprintf(source_info[slot].output_error, sizeof source_info[slot].output_error,
                         "%s", live ? "" : "backend_pending");
        }
        source_snapshot_unlock();
    }
    if (source_dispatch_lock()) {
        int virtual_live[GC_BT_MAX_PADS];
        GcBtOrigin origins[GC_BT_MAX_PADS];
#if GC_VPAD_RUMBLE_READBACK
        int source_slots[GC_BT_MAX_PADS];
#endif
        source_snapshot_lock();
        GcBt *bt = inject_bt;
        for (int source = 0; source < GC_BT_MAX_PADS; ++source) {
            int slot = bt_map[source];
#if GC_VPAD_RUMBLE_READBACK
            source_slots[source] = slot;
#endif
            virtual_live[source] = slot >= 0 && slot_live[slot];
            origins[source] = bt_active[source];
        }
        source_snapshot_unlock();
        source_dispatch_unlock();
        if (bt)
            for (int source = 0; source < GC_BT_MAX_PADS; ++source) {
                gc_bt_set_virtual(bt, source, &origins[source], virtual_live[source]);
#if GC_VPAD_RUMBLE_READBACK
                feed_source_rumble(bt, source, source_slots[source],
                                   &origins[source], virtual_live[source]);
#endif
            }
    }
}

static int usb_xusb_qualified(const GcUsbDevice *device)
{
    /* kind comes from descriptor selection, not payload sniffing. Recheck the
     * selected interface metadata; VID/PID alone never grants admission. */
    return device && device->kind == GC_USB_INTERFACE_XUSB && !device->hid &&
        device->alternate_setting == 0 && device->interface_index >= 0 &&
        device->interface_number >= 0 && device->interface_number <= 255 &&
        mamba_is_xinput_interface(device->subclass, device->protocol) &&
        device->in_count > 0 && device->in_count <= 15 &&
        (device->in[0] & 0x80u) && (device->in[0] & 0x0fu) &&
        !(device->in[0] & 0x70u);
}

static int usb_supported(const GcUsbDevice *device)
{
    if (!device) return 0;
    if (usb_xusb_qualified(device)) return 1;
    if (device->kind == GC_USB_INTERFACE_GIP && device->in_count && device->out_count) return 1;
    if ((device->kind == GC_USB_INTERFACE_HID || device->kind == GC_USB_INTERFACE_HID_RAW) &&
        ds3_is_compatible_vidpid(device->vid, device->pid)) return 1;
    if ((device->kind == GC_USB_INTERFACE_HID || device->kind == GC_USB_INTERFACE_HID_RAW) &&
        ds4_is_compatible_vidpid(device->vid, device->pid)) return 1;
#if GC_GH5_USB_DIAGNOSTIC
    if ((device->kind == GC_USB_INTERFACE_HID || device->kind == GC_USB_INTERFACE_HID_RAW) &&
        device->vid == 0x12ba && device->pid == 0x0100 && device->in_count) return 1;
#endif
    return device->kind == GC_USB_INTERFACE_HID && device->layout.count > 0;
}

/* Compare descriptor meaning, not C padding or unused field storage. */
static int hid_layout_same(const GcHidLayout *left, const GcHidLayout *right)
{
    if (left->count != right->count || left->count > GC_HID_MAX_FIELDS ||
        left->numbered != right->numbered || left->axes != right->axes ||
        left->features != right->features ||
        left->ps3_gh_guitar != right->ps3_gh_guitar) return 0;
    for (size_t index = 0; index < left->count; ++index) {
        const GcHidField *a = &left->fields[index], *b = &right->fields[index];
        if (a->offset != b->offset || a->page != b->page || a->usage != b->usage ||
            a->array_base != b->array_base || a->bits != b->bits || a->report != b->report ||
            a->minimum != b->minimum || a->maximum != b->maximum ||
            a->array_usage_min != b->array_usage_min || a->array_usage_max != b->array_usage_max ||
            a->is_array != b->is_array || a->null_state != b->null_state) return 0;
    }
    return 1;
}

/* The profile a slot resolved to, if the wizard saved one for this controller.
 * Raw bit maps are the only way in for a device whose descriptor declares no
 * standard usages, and they must be usable without shipping a new app. */
static int slot_profile(int slot, GcProfile *out)
{
    int have = 0;
    if (!out || slot < 0 || slot >= HOST_MAX_PADS) return 0;
    source_snapshot_lock();
    GcConfigStore *config = inject_config;
    GcControllerResolution resolved = {0};
    if (config &&
        gc_config_resolve_controller(config, &source_info[slot].binding, &resolved) == 0 &&
        resolved.has_profile) {
        *out = resolved.profile;
        have = 1;
    }
    source_snapshot_unlock();
    return have;
}

#if GC_GH5_USB_DIAGNOSTIC
static int gh5_vpad_probe_enabled(void)
{
    static GcGh5ProbeState state;
    static pthread_mutex_t probe_mu = PTHREAD_MUTEX_INITIALIZER;
    int enabled;
    /* Source callbacks may share a process: serialize the state and logs. */
    if (pthread_mutex_lock(&probe_mu) != 0) return 0;
    const uint64_t now = gc_fallback_now_ms();
    const GcGh5ProbeObservation o = gc_gh5_probe_step(
        &state, GH5_VPAD_PROBE_MARKER, now);
    if (o.checked && o.report) {
        log_line("gh5: R7 marker check #%u result=%s errno=%d "
                 "file_bytes=%llu marker=%s uid=%lu euid=%lu",
                 o.check_number, gc_gh5_marker_status(o.status),
                 o.error, (unsigned long long)o.file_size,
                 GH5_VPAD_PROBE_MARKER,
                 (unsigned long)getuid(), (unsigned long)geteuid());
#if GC_GH5_PROBE_PATH_TRACE
        /* Explain ENOENT vs EACCES vs wrong path without guessing.
         * No fallback paths are accepted; only the documented path enables VDA. */
        {
            struct stat dir_st;
            const char *directory = "/data/ghostcontrol-app-service";
            errno = 0;
            int dir_rc = stat(directory, &dir_st);
            int dir_error = dir_rc == 0 ? 0 : errno;
            log_line("gh5: R7 path-trace pid=%ld parent=%s parent_exists=%d "
                     "parent_is_dir=%d parent_mode=%#o errno=%d "
                     "marker_status=%s retry_ms=%llu",
                     (long)getpid(), directory, dir_rc == 0,
                     dir_rc == 0 ? !!S_ISDIR(dir_st.st_mode) : 0,
                     dir_rc == 0 ? (unsigned)(dir_st.st_mode & 0777) : 0u,
                     dir_error, gc_gh5_marker_status(o.status),
                     (unsigned long long)GC_GH5_PROBE_RECHECK_MS);
        }
#endif
        log_line("gh5: VDA probe mode %s (marker=%s)",
                 state.enabled ? "ENABLED: preparing neutral input for VDA identification" :
                                 "disabled: raw USB logging only",
                 GH5_VPAD_PROBE_MARKER);
    }
    enabled = state.enabled;
    pthread_mutex_unlock(&probe_mu);
    return enabled;
}

/* Per-generation, per-source bounded change capture. No six-second lifetime cap.
 * Backpressure is explicit; dropped transitions are NOT silently claimed captured. */
static void gh5_trace_report(UsbFeed *feed, const GcUsbDevice *device,
                             const uint8_t *report, size_t data_length, int from_control)
{
    const unsigned stream = from_control ? 1u : 0u;
    const uint64_t timestamp = gc_fallback_now_ms();
    const uint64_t second = timestamp / UINT64_C(1000);
    const unsigned budget = from_control ? 3u : 24u;
    char hex[USB_REPORT * 3 + 1];
    size_t length = data_length > USB_REPORT ? USB_REPORT : data_length;
    size_t used = 0;
    ++feed->trace_raw_seen[stream];
    if (feed->trace_raw_bucket_sec[stream] != second) {
        if (feed->trace_raw_dropped[stream])
            log_line("gh5: RAW dropped source=%s generation=%llu count=%llu",
                     from_control ? "CONTROL_GET_REPORT" : "INTERRUPT_IN",
                     (unsigned long long)feed->trace_generation,
                     (unsigned long long)feed->trace_raw_dropped[stream]);
        feed->trace_raw_bucket_sec[stream] = second;
        feed->trace_raw_bucket_count[stream] = 0;
        feed->trace_raw_dropped[stream] = 0;
    }
    if (length == feed->trace_raw_prev_len[stream] &&
        memcmp(feed->trace_raw_prev[stream], report, length) == 0) return;
    if (feed->trace_raw_bucket_count[stream] >= budget) {
        ++feed->trace_raw_dropped[stream];
        ++feed->trace_raw_drop_total[stream];
        /* Keep previous LAST LOGGED frame, not last seen: a stable state that
         * missed this bucket will be emitted in the next available bucket. */
        return;
    }
    memcpy(feed->trace_raw_prev[stream], report, length);
    feed->trace_raw_prev_len[stream] = length;
    ++feed->trace_raw_bucket_count[stream];
    ++feed->trace_raw_logged[stream];
    for (size_t i = 0; i < length && used + 4 < sizeof hex; ++i) {
        int n = snprintf(hex + used, sizeof hex - used, "%s%02x", i ? " " : "", report[i]);
        if (n < 0 || (size_t)n >= sizeof hex - used) break;
        used += (size_t)n;
    }
    hex[used] = '\0';
    log_line("gh5: RAW source=%s generation=%llu t_ms=%llu sample=%llu slot=%d path=%s len=%u kind=%d iface=%d/%d ep=%02x bytes=%s",
             from_control ? "CONTROL_GET_REPORT" : "INTERRUPT_IN",
             (unsigned long long)feed->trace_generation,
             (unsigned long long)timestamp,
             (unsigned long long)feed->trace_raw_seen[stream], feed->slot,
             feed->path, (unsigned)length, (int)device->kind,
             device->interface_index, device->interface_number, feed->in_ep, hex);
}

#endif

static int usb_decode_report(UsbFeed *feed, const GcUsbDevice *device, pad_state *state,
                             const uint8_t *report, uint32_t length, int from_control)
{
    (void)from_control;
    ScePadData decoded = feed->decoded;
    int ok;
    int allow_raw_learning = 0;
    /* Bring-up trace: reports either arrive and decode, or they never arrive.
     * Without this the two look identical from outside ("no input"). */
    {
        static int traced;
        if (traced < 16) {
            ++traced;
            log_line("usb feed: slot %d len=%u id=%#x kind=%d",
                     feed->slot, (unsigned)length,
                     (unsigned)(length ? report[0] : 0),
                     (int)device->kind);
        }
    }
#if GC_GH5_USB_DIAGNOSTIC
    if (device->vid == 0x12ba && device->pid == 0x0100) {
        static int announced_probe;
        gh5_trace_report(feed, device, report, length, from_control);
        /* A CONTROL_GET_REPORT reply is not the guitar interrupt-IN input.
         * Never allow it to create a neutral virtual-pad probe frame. */
        if (from_control) return 0;
        if (!gh5_vpad_probe_enabled()) {
#if GC_GH5_PRECISION_DIAGNOSTIC
            ++feed->trace_probe_skips;
#endif
            return 0;
        }
#if GC_GH5_PRECISION_DIAGNOSTIC
        ++feed->trace_neutral_frames;
#endif
        if (!announced_probe++)
            log_line("gh5: raw-report VDA probe active; preparing neutral frames only");
        memset(&decoded, 0, sizeof decoded);
        decoded.leftStick.x = decoded.leftStick.y = 128;
        decoded.rightStick.x = decoded.rightStick.y = 128;
        decoded.quat.w = 1.0f;
        feed->decoded = decoded;
        pad_state_reset(state);
        return 1;
    }
#endif
    if (feed->nintendo) {
        /* The resident line's Nintendo state machine: it answers the 0x81
         * handshake reports by sending subcommands over the OUT pipe and only
         * then parses 0x30/0x3F. A generic HID decode never sees a report at all. */
        const int handled = nintendo_handle_packet(feed->fd, feed->ep, report,
                                                   length, &feed->hs_state,
                                                   &feed->nintendo_seq, &decoded);
        ok = handled > 0;
        if (handled < 0)
            log_line("usb: %s nintendo OUT failed (%s)", feed->path, strerror(errno));
    } else if (feed->gip) {
        const int handled = xbox_handle_packet(feed->fd, feed->ep, report,
                                               length, &decoded, &feed->xbox);
        if (handled < 0)
            log_line("usb: %s GIP OUT failed (%s)", feed->path, strerror(errno));
        if (handled <= 0) return 0;
        ok = 1;
    } else if (usb_xusb_qualified(device))
        ok = mamba_xinput_handle_packet(-1, NULL, report, length, &decoded);
    else if ((device->kind == GC_USB_INTERFACE_HID || device->kind == GC_USB_INTERFACE_HID_RAW) &&
        ds4_is_compatible_vidpid(device->vid, device->pid))
        ok = ds4_handle_packet(-1, NULL, report, length, &decoded);
    else if (feed->ds3) {
        if (ds3_handle_packet(-1, NULL, report, length, &decoded) <= 0)
            return 0;
        ok = 1;
    } else if (device->kind == GC_USB_INTERFACE_HID) {
        /* Only real interrupt input qualifies an undecoded source for raw learning. */
        allow_raw_learning = !from_control;
        source_snapshot_lock();
        GcHidState physical = source_hid_values[feed->slot];
        if (!hid_layout_same(&source_hid_layout[feed->slot], &device->layout)) {
            memset(&physical, 0, sizeof physical);
            memset(&decoded, 0, sizeof decoded);
            decoded.leftStick.x = decoded.leftStick.y = 128;
            decoded.rightStick.x = decoded.rightStick.y = 128;
            decoded.quat.w = 1.0f;
        }
        ok = gc_hid_input(&device->layout, report, length, &decoded) &&
             gc_hid_state_update(&physical, &device->layout, report, length);
        /* Cache the descriptor even when the decode fails: a report with no
         * standard usages decodes to nothing (gc_hid_input returns 0), yet its
         * field layout is exactly what the setup learner needs to know which
         * bytes carry buttons. */
        if (device->layout.count || device->layout.raw_count)
            source_hid_layout[feed->slot] = device->layout;
        if (ok)
            source_hid_values[feed->slot] = physical;
        source_snapshot_unlock();
        /* A saved profile applies to every HID source. It can add bindings the
         * descriptor cannot express, and for a pad that declares no standard
         * usages it is the only decoder there is. Profiles are data files, so a
         * newly supported controller arrives without an app update. */
        GcProfile slot_prof;
        /* A saved profile cannot convert a rejected control reply to input. */
        if ((!from_control || ok) && slot_profile(feed->slot, &slot_prof)) {
            if (!ok) {
                memset(&decoded, 0, sizeof decoded);
                decoded.leftStick.x = decoded.leftStick.y = 128;
                decoded.rightStick.x = decoded.rightStick.y = 128;
                decoded.quat.w = 1.0f;
            }
            gc_profile_apply(&slot_prof, &decoded);
            gc_rawmap_apply(&slot_prof, report, length, &decoded);
            ok = 1;   /* configured by profile, even when nothing mapped yet */
        }
    } else
        return 0; /* An unknown protocol is not a DS4 report. */
    if (!ok) {
        /* #29 ddb0104: known-protocol handshakes are not control input. */
        if (!allow_raw_learning) return 0;
        /* A descriptor that declares no standard usages yields no fields, and
         * with no saved profile yet there is nothing to map. The report is
         * still real input from a real device: publish a neutral state so the
         * source counts as readable and Custom Controller Setup can learn its
         * raw bits. Without this the wizard refuses to list the only device it
         * could use to build the profile -- a deadlock, not a dead pad. */
        if (length > 0) {
            memset(&decoded, 0, sizeof decoded);
            decoded.leftStick.x = decoded.leftStick.y = 128;
            decoded.rightStick.x = decoded.rightStick.y = 128;
            decoded.quat.w = 1.0f;
            feed->decoded = decoded;
            pad_state_reset(state);
            return 1;
        }
        return 0;
    }
    feed->decoded = decoded;
    pad_state_reset(state);
    state->buttons = decoded.buttons;
    state->lx = decoded.leftStick.x;
    state->ly = decoded.leftStick.y;
    state->rx = decoded.rightStick.x;
    state->ry = decoded.rightStick.y;
    state->l2 = decoded.analogButtons.l2;
    state->r2 = decoded.analogButtons.r2;
    return 1;
}

static int usb_decode(UsbFeed *feed, const GcUsbDevice *device, pad_state *state)
{
    /* The public RAW/neutral modes apply to 12ba:0100 only. Never let an
     * observed sample imply decoded controls or increment a decode failure. */
    const int policy = gc_gh5_policy(device->vid, device->pid);
    if (policy == GC_USB_DECODE_SKIPPED) return policy;
    if (policy == GC_USB_DECODE_NEUTRAL_PROBE) {
        pad_state_reset(state);
        memset(&feed->decoded, 0, sizeof feed->decoded);
        feed->decoded.leftStick.x = feed->decoded.leftStick.y = 128;
        feed->decoded.rightStick.x = feed->decoded.rightStick.y = 128;
        feed->decoded.quat.w = 1.0f;
        return policy;
    }
    return usb_decode_report(feed, device, state, feed->report, feed->lenp, 0)
        ? GC_USB_DECODE_CONTROLS : GC_USB_DECODE_REJECTED;
}

/* Switch Pro and compatibles: they answer nothing until the two 0x80 reports
 * arrive, which is why they look dead to a generic HID bring-up. */
static int usb_is_nintendo(uint16_t vid, uint16_t pid)
{
    return vid == 0x057e &&
           (pid == 0x2009 || pid == 0x2017 || pid == 0x2019 || pid == 0x201a);
}

/* controller_nintendo.c and usb_helpers.c log through the resident line's status
 * log; vpad.log is this build's retrievable equivalent. */
void ghostpad_status_log(const char *fmt, ...)
{
    char buffer[256];
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(buffer, sizeof buffer, fmt, ap);
    va_end(ap);
    log_line("%s", buffer);
}

/* The two reports the resident line sends before its handshake state machine. */
static void usb_nintendo_kick(UsbFeed *feed)
{
    const int ok1 = usb_send_cmd(feed->fd, &feed->ep[1], 0x80, 0x02) == 0;
    usleep(30000);
    const int ok2 = usb_send_cmd(feed->fd, &feed->ep[1], 0x80, 0x04) == 0;
    usleep(50000);
    log_line("usb: %s nintendo kick [80 02]=%d [80 04]=%d", feed->path, ok1, ok2);
}

static int usb_class_request(int fd, uint8_t type, uint8_t request, uint16_t value,
                              uint16_t index, void *data, uint16_t length)
{
    struct usb_ctl_request control;
    memset(&control, 0, sizeof control);
    control.ucr_data = data;
    control.ucr_request.bmRequestType = type;
    control.ucr_request.bRequest = request;
    USETW(control.ucr_request.wValue, value);
    USETW(control.ucr_request.wIndex, index);
    USETW(control.ucr_request.wLength, length);
    if (ioctl(fd, USB_DO_REQUEST, &control) != 0) return -1;
    return control.ucr_actlen;
}

static int usb_open_feed(UsbFeed *feed, const GcUsbDevice *device)
{
    struct usb_fs_init init;
    struct usb_fs_open op;
    const int is_gh5 = device && device->vid == 0x12ba && device->pid == 0x0100;
    if (feed->fd_owned || feed->close_uncertain) return 0;
    memset(feed, 0, sizeof *feed);
    feed->fd = -1;
    if (!device->in_count || !usb_supported(device)) return 0;
    feed->decoded.leftStick.x = feed->decoded.leftStick.y = 128;
    feed->decoded.rightStick.x = feed->decoded.rightStick.y = 128;
    feed->decoded.quat.w = 1.0f;
    feed->fd = open(device->path, O_RDWR | O_NONBLOCK);
    if (feed->fd < 0) return 0;
    feed->fd_owned = 1;
    /* The kernel HID driver owns the interface on a stock console. Without
     * detaching it first, our interrupt transfer never completes: FS_COMPLETE
     * stays EBUSY forever and the pad reports no input at all, for every HID
     * device rather than just the one that exposed it. The resident line
     * (gc_main.c) always detaches before it opens a pad; this path did not. */
    {
        int detach_index = device->interface_index;
        const int detach_rc = ioctl(feed->fd, USB_IFACE_DRIVER_DETACH, &detach_index);
        const int detach_errno = detach_rc != 0 ? errno : 0;
        if (is_gh5)
            log_line("gh5: HID driver detach iface=%d rc=%d errno=%d", detach_index,
                     detach_rc, detach_errno);
        if (detach_rc != 0) {
            static int noted_detach;
            if (noted_detach++ < 4)
                log_line("usb: %s detach iface %d failed errno=%d (%s)",
                         device->path, detach_index, detach_errno, strerror(detach_errno));
        }
    }
    /* Same story as the detach: the resident line sends SET_IDLE(0) after it
     * opens a HID pad and this path did not. A device that waits for traffic
     * before it starts reporting has nothing to answer until this arrives. */
    if (device->kind == GC_USB_INTERFACE_HID) {
        const int idle_rc = gc_usb_hid_set_idle(feed->fd, (uint8_t)device->interface_number, 0);
        if (is_gh5)
            log_line("gh5: HID SET_IDLE(0) iface=%u rc=%d errno=%d",
                     (unsigned)device->interface_number, idle_rc, idle_rc != 0 ? errno : 0);
    }
    feed->slot = -1;
    feed->bufp = feed->report;
    feed->lenp = USB_REPORT;
    memset(feed->ep, 0, sizeof feed->ep);
    feed->ep[0].ppBuffer = (void **)&feed->bufp;
    feed->ep[0].pLength = &feed->lenp;
    feed->ep[0].nFrames = 1;
    feed->ep[0].flags = USB_FS_FLAG_SINGLE_SHORT_OK;
    feed->nintendo = usb_is_nintendo(device->vid, device->pid) && device->out_count;
    feed->gip = device->kind == GC_USB_INTERFACE_GIP && device->out_count;
    feed->ds4_out = device->vid == 0x054c &&
        (device->pid == 0x05c4 || device->pid == 0x09cc) && device->out_count;
    /* DS3 protocol list excludes Sony Rhythm VID 0x12ba instruments. */
    feed->ds3 = (device->kind == GC_USB_INTERFACE_HID || device->kind == GC_USB_INTERFACE_HID_RAW) &&
        ds3_is_compatible_vidpid(device->vid, device->pid);
    const int ds3_sony = feed->ds3 && device->vid == 0x054c &&
        device->pid == 0x0268 && device->out_count;
    const int ep_max = (feed->nintendo || feed->gip || feed->ds4_out || ds3_sony) ? 2 : 1;
    /* ep[1] is left zeroed on purpose: usb_send_out() owns the OUT buffers and
     * refuses to write through an endpoint that already has pointers installed. */
    memset(&init, 0, sizeof init);
    init.pEndpoints = feed->ep;
    init.ep_index_max = ep_max;
    if (ioctl(feed->fd, USB_FS_INIT, &init) != 0) {
        const int err = errno;
        if (is_gh5) log_line("gh5: USB_FS_INIT failed errno=%d (%s)", err, strerror(err));
        (void)usb_release_fd(feed);
        return 0;
    }
    feed->fs_initialized = 1;
    memset(&op, 0, sizeof op);
    op.ep_index = 0;
    op.ep_no = device->in[0];
    op.max_bufsize = USB_REPORT;
    op.max_frames = 1;
    if (ioctl(feed->fd, USB_FS_OPEN, &op) != 0) {
        const int err = errno;
        if (is_gh5) log_line("gh5: USB_FS_OPEN IN ep=%02x failed errno=%d (%s)",
                             device->in[0], err, strerror(err));
        (void)usb_release_fd(feed);
        return 0;
    }
    feed->in_xfer_len = (op.max_packet_length > 0 && op.max_packet_length <= USB_REPORT)
        ? op.max_packet_length : USB_REPORT;
    feed->lenp = feed->in_xfer_len;
    if (is_gh5)
        log_line("gh5: USB_FS_OPEN IN ep=%02x max_packet=%u requested=%u interface=%u index=%d",
                 device->in[0], op.max_packet_length, feed->in_xfer_len,
                 (unsigned)device->interface_number, device->interface_index);
    if (feed->nintendo) {
        memset(&op, 0, sizeof op);
        op.ep_index = 1;
        op.ep_no = device->out[0];
        op.max_bufsize = sizeof feed->out_buf;
        op.max_frames = 1;
        if (ioctl(feed->fd, USB_FS_OPEN, &op) != 0) {
            log_line("usb: %s OUT open errno=%d (%s)", device->path, errno, strerror(errno));
            (void)usb_release_fd(feed);
            return 0;
        }
        /* Ask the pad to start talking before anything waits on its IN pipe. */
        usb_nintendo_kick(feed);
        feed->hs_state = HS_WAIT_81_01;
        feed->nintendo_seq = 1;
    }
    if (feed->ds3) {
        const int operational = ds3_set_operational_usb(feed->fd, (uint8_t)device->interface_number);
        log_line("usb: %s DS3 operational=%d", device->path, operational);
        if (operational != 0 && device->kind == GC_USB_INTERFACE_HID && device->layout.count) {
            log_line("usb: %s DS3 start-up failed; using generic HID", device->path);
            feed->ds3 = 0;
        }
        if (feed->ds3 && ds3_sony) {
            uint8_t enable[4] = { 0x42, 0x0c, 0x00, 0x00 };
            static const uint8_t led1[36] = {
                0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                0x02, 0xff, 0x27, 0x10, 0x00, 0x32, 0xff, 0x27, 0x10, 0x00, 0x32,
                0xff, 0x27, 0x10, 0x00, 0x32, 0xff, 0x27, 0x10, 0x00, 0x32,
                0x00, 0x00, 0x00, 0x00, 0x00
            };
            const int en = usb_class_request(feed->fd, 0x21, 0x09, 0x03f4,
                (uint16_t)device->interface_number, enable, sizeof enable);
            int led = -1;
            memset(&op, 0, sizeof op);
            op.ep_index = 1; op.ep_no = device->out[0];
            op.max_bufsize = 64; op.max_frames = 1;
            if (ioctl(feed->fd, USB_FS_OPEN, &op) == 0)
                led = usb_send_out(feed->fd, &feed->ep[1], led1, sizeof led1, "ds3_led");
            log_line("usb: %s DS3 enable(0xF4)=%d led=%d", device->path, en, led);
        }
    }
    if (feed->ds4_out) {
        memset(&op, 0, sizeof op);
        op.ep_index = 1; op.ep_no = device->out[0];
        op.max_bufsize = 64; op.max_frames = 1;
        if (ioctl(feed->fd, USB_FS_OPEN, &op) == 0) {
            static const uint8_t lightbar[32] = {
                0x05, 0x07, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x40
            };
            const int sent = usb_send_out(feed->fd, &feed->ep[1], lightbar,
                                          sizeof lightbar, "ds4_lightbar");
            log_line("usb: %s DS4 lightbar set=%d", device->path, sent);
        } else {
            log_line("usb: %s DS4 OUT open errno=%d (%s)", device->path, errno, strerror(errno));
        }
    }
    if (feed->gip) {
        memset(&op, 0, sizeof op);
        op.ep_index = 1; op.ep_no = device->out[0];
        op.max_bufsize = sizeof feed->xbox.transfer_output; op.max_frames = 1;
        if (ioctl(feed->fd, USB_FS_OPEN, &op) != 0) {
            log_line("usb: %s GIP OUT open errno=%d (%s)", device->path, errno, strerror(errno));
            (void)usb_release_fd(feed);
            return 0;
        }
        feed->xbox.out_available = 1;
        /* The handshake is started after the feed identity and buffers have
         * been committed below. usb_tick() will skip this feed while pending. */
        feed->ep[0].ppBuffer = (void **)&feed->bufp;
        feed->ep[0].pLength = &feed->lenp;
        feed->ep[0].nFrames = 1;
        feed->ep[0].aFrames = 0;
        feed->ep[0].status = 0;
        feed->ep[0].timeout = 0;
        feed->ep[0].flags = USB_FS_FLAG_SINGLE_SHORT_OK;
        feed->lenp = feed->in_xfer_len;
    }
    snprintf(feed->path, sizeof feed->path, "%s", device->path);
    feed->vid = device->vid; feed->pid = device->pid; feed->kind = device->kind;
#if GC_GH5_PRECISION_DIAGNOSTIC
    if (is_gh5) {
        feed->trace_generation = ++gh5_next_connection_generation;
        feed->trace_completed_ep = -1;
    }
#endif
    feed->interface_index = device->interface_index;
    feed->interface_number = device->interface_number;
    feed->alternate_setting = device->alternate_setting;
    feed->in_ep = device->in[0];
    feed->progress.generation = ++usb_progress_generation;
    feed->progress.opened_ms = gc_fallback_now_ms();
    feed->used = 1;
    feed->slot = -1;
    if (feed->gip) {
        const int worker_slot = (int)(feed - usb_feed);
        atomic_store_explicit(&gip_worker_cancel[worker_slot], 0, memory_order_release);
        atomic_store_explicit(&gip_worker_result[worker_slot], 0, memory_order_relaxed);
        atomic_store_explicit(&gip_worker_state[worker_slot], 1, memory_order_release);
        const int thread_rc = pthread_create(&gip_worker_threads[worker_slot], NULL,
            gip_handshake_worker, (void *)(intptr_t)worker_slot);
        if (thread_rc != 0) {
            atomic_store_explicit(&gip_worker_state[worker_slot], 0, memory_order_release);
            log_line("usb: %s GIP worker create failed rc=%d", feed->path, thread_rc);
            (void)usb_release_fd(feed);
            memset(feed, 0, sizeof *feed);
            feed->fd = -1;
            return 0;
        }
        gip_worker_joinable[worker_slot] = 1;
        log_line("usb: %s GIP handshake started asynchronously", feed->path);
    }
    return 1;
}

static void usb_close_feed(UsbFeed *feed)
{
    if (!feed->used) return;
    if (!source_dispatch_lock()) return;
    if (feed->gip && gip_worker_joinable[(int)(feed - usb_feed)] &&
        gip_worker_join(feed, 1, NULL) < 0) {
        source_dispatch_unlock();
        return;
    }
#if GC_GH5_PRECISION_DIAGNOSTIC
    gh5_progress_summary(feed, 1); /* final line before fd/path are recycled */
#endif
    if (usb_release_fd(feed) != 0) { source_dispatch_unlock(); return; }
    gc_usb_hid_layout_forget(feed->path);
    if (feed->vid == 0x12ba && feed->pid == 0x0100)
        log_line("gh5 precision: cached layout invalidated on feed retirement path=%s", feed->path);
    if (feed->slot >= 0) {
        source_snapshot_lock();
        ++slot_epoch[feed->slot];
        last_valid[feed->slot] = slot_live[feed->slot] = 0;
        slot_vid[feed->slot] = slot_pid[feed->slot] = 0;
        clear_sample(feed->slot);
        backend_added[feed->slot] = 0;
        source_snapshot_unlock();
        if (inject_ready) vpad_remove(feed->slot);
        source_snapshot_lock();
        usb_owned[feed->slot] = 0;
        source_snapshot_unlock();
    }
    memset(feed, 0, sizeof *feed);
    feed->fd = -1;
    source_dispatch_unlock();
}

/* 1 if the feed was retired. Transient faults stay on the same slot. */
static int usb_note_io(UsbFeed *feed, int err, int endpoint_status, int short_invalid)
{
    GcUsbIoClass kind = gc_usb_io_classify(err, endpoint_status, short_invalid);
    if (kind == GC_USB_IO_OK) return 0;
    if (kind == GC_USB_IO_FATAL) {
        fprintf(stderr, "inject: usb %s retired: fatal io (errno=%d endpoint_status=%#x short_invalid=%d)\n",
                feed->path, err, endpoint_status, short_invalid);
        usb_close_feed(feed);
        return 1;
    }
    if (feed->slot >= 0) {
        source_snapshot_lock();
        if (source_info[feed->slot].connected &&
            source_info[feed->slot].io_faults != UINT_MAX)
            ++source_info[feed->slot].io_faults;
        source_snapshot_unlock();
    }
    return 0;
}

/* A path is a location, not an identity or endpoint binding. Retire the old
 * source before accepting an observed model/interface change at that location.
 * A transient HID->HID_RAW classification downgrade (the report-descriptor
 * read can fail while this service holds the interface) is not a model
 * change: the physical identity and endpoints are unchanged, so the source
 * is kept and the scan is tolerated until qualification returns. */
static int usb_same_source(const UsbFeed *feed, const GcUsbDevice *device)
{
    if (!device->in_count || strcmp(feed->path, device->path) ||
        feed->vid != device->vid || feed->pid != device->pid ||
        feed->interface_index != device->interface_index ||
        feed->interface_number != device->interface_number ||
        feed->alternate_setting != device->alternate_setting ||
        feed->in_ep != device->in[0])
        return 0;
    if (usb_supported(device))
        return 1;
    /* While this service holds the interface, the report-descriptor read can
     * fail transiently, downgrading the scan's classification from HID to
     * HID_RAW for one tick. The physical identity and endpoints are
     * unchanged, so keep the source; a genuine loss of qualification (a HID
     * scan whose parsed layout is gone) still retires it. */
    return feed->kind == GC_USB_INTERFACE_HID &&
        device->kind == GC_USB_INTERFACE_HID_RAW;
}

static void usb_tick(void)
{
    GcUsbDevice devices[8];
    size_t count, i, n;
#if GC_GH5_PRECISION_DIAGNOSTIC
    /* Execute even if nothing has arrived on the interrupt pipe since the
     * previous pass; an input stall otherwise produces no diagnostic line. */
    for (n = 0; n < USB_SLOTS; ++n)
        gh5_progress_summary(&usb_feed[n], 0);
#endif
    count = gc_usb_devices(devices, 8);
    for (n = 0; n < USB_SLOTS; ++n) {
        int still = 0;
        if (!usb_feed[n].used) continue;
        for (i = 0; i < count; ++i)
            if (usb_same_source(&usb_feed[n], &devices[i])) {
                still = 1;
                if (usb_feed[n].kind != devices[i].kind)
                    fprintf(stderr, "inject: usb %s classification %d->%d tolerated (identity unchanged, source kept)\n",
                            usb_feed[n].path, (int)usb_feed[n].kind, (int)devices[i].kind);
            }
        if (!still) {
            size_t j; int seen = 0;
            for (j = 0; j < count; ++j)
                if (!strcmp(usb_feed[n].path, devices[j].path)) {
                    seen = 1;
                    fprintf(stderr, "inject: usb %s retired: field change dev[vid %04x pid %04x kind %d iface %d/%d alt %d in %u in_count %u] feed[vid %04x pid %04x kind %d iface %d/%d alt %d in %u]\n",
                            usb_feed[n].path, devices[j].vid, devices[j].pid, devices[j].kind,
                            devices[j].interface_index, devices[j].interface_number, devices[j].alternate_setting,
                            devices[j].in[0], devices[j].in_count,
                            usb_feed[n].vid, usb_feed[n].pid, usb_feed[n].kind,
                            usb_feed[n].interface_index, usb_feed[n].interface_number,
                            usb_feed[n].alternate_setting, usb_feed[n].in_ep);
                }
            if (!seen)
                fprintf(stderr, "inject: usb %s retired: absent from scan (count=%zu)\n", usb_feed[n].path, count);
            usb_close_feed(&usb_feed[n]);
        }
    }
    for (i = 0; i < count; ++i) {
        int have = 0;
        UsbFeed *feed = NULL;
        struct usb_fs_start st;
        struct usb_fs_complete done;
        pad_state state;
        /* PR #29: skip unqualified USB interfaces before opening a feed.
         * Besides avoiding meaningless ioctl failures, this prevents an
         * unrelated HID device from flooding app-service.log every 8 ms. */
        if (!usb_supported(&devices[i])) continue;
        for (n = 0; n < USB_SLOTS; ++n)
            if (usb_feed[n].used && !strcmp(usb_feed[n].path, devices[i].path)) {
                have = 1;
                feed = &usb_feed[n];
                break;
            }
        if (!have) {
            for (n = 0; n < USB_SLOTS; ++n)
                if (!usb_feed[n].used) { feed = &usb_feed[n]; break; }
            if (!feed || !usb_open_feed(feed, &devices[i])) {
                /* Experimental diagnostics only: preserve every open attempt,
                 * but rate-limit repeated identical 040B:0897 log lines. The
                 * device is NOT blacklisted and USB enumeration is unchanged. */
                if (devices[i].vid == 0x040b && devices[i].pid == 0x0897) {
                    static unsigned gh5_unrelated_040b_attempts;
                    const unsigned attempt = ++gh5_unrelated_040b_attempts;
                    if (attempt <= 4u || (attempt % 256u) == 0u)
                        log_line("usb: %s 040b:0897 open failed (%s) attempts=%u (log rate-limited; retries unchanged)",
                                 devices[i].path, strerror(errno), attempt);
                } else {
                    /* stderr is not captured anywhere a session can read, so the one
                     * line that explains "no input" was invisible. */
                    log_line("usb: %s %04x:%04x open failed (%s)",
                             devices[i].path, devices[i].vid, devices[i].pid,
                             strerror(errno));
                }
                continue;
            }
            log_line("usb: %s %04x:%04x opened kind=%d iface=%d/%d IN=%02x max-layout=%u raw-layout=%u",
                     devices[i].path, devices[i].vid, devices[i].pid, (int)devices[i].kind,
                     devices[i].interface_index, devices[i].interface_number,
                     devices[i].in[0], (unsigned)devices[i].layout.count,
                     (unsigned)devices[i].layout.raw_count);
        }
        /* PR #32 review follow-up: do not keep source_dispatch_lock while the
         * Xbox GIP handshake waits on USB. The worker is independently bounded;
         * this feed is skipped until its state/result is joined by the service. */
        if (feed->gip && !feed->gip_ready) {
            const int worker_slot = (int)(feed - usb_feed);
            const int worker_state = atomic_load_explicit(
                &gip_worker_state[worker_slot], memory_order_acquire);
            if (worker_state == 1) continue;
            if (worker_state == 2) {
                int handshake = 0;
                if (gip_worker_join(feed, 0, &handshake) < 0) continue;
                if (handshake < 0) {
                    log_line("usb: %s GIP handshake failed result=%d", feed->path, handshake);
                    usb_close_feed(feed);
                    continue;
                }
                /* xbox_gip_handshake uses endpoint[0] with XboxControllerState's
                 * private transfer buffer. Restore the service feed's stable USB
                 * report pointers only after the worker has been joined. */
                feed->bufp = feed->report;
                feed->lenp = feed->in_xfer_len ? feed->in_xfer_len : USB_REPORT;
                feed->ep[0].ppBuffer = (void **)&feed->bufp;
                feed->ep[0].pLength = &feed->lenp;
                feed->ep[0].nFrames = 1;
                feed->ep[0].aFrames = 0;
                feed->ep[0].status = 0;
                feed->ep[0].timeout = 0;
                feed->ep[0].flags = USB_FS_FLAG_SINGLE_SHORT_OK;
                feed->gip_ready = 1;
                log_line("usb: %s GIP handshake complete result=%d", feed->path, handshake);
            } else {
                continue;
            }
        }
        if (feed->slot < 0) {
            int slot = free_slot();
            if (slot < 0) continue;
            feed->slot = slot;
            source_snapshot_lock();
            GcServiceSource *info = &source_info[slot];
            snprintf(info->path, sizeof info->path, "%s", devices[i].path);
            snprintf(info->protocol, sizeof info->protocol, "%s",
                     usb_xusb_qualified(&devices[i]) ? "xusb" :
                     (devices[i].kind == GC_USB_INTERFACE_GIP) ? "gip" :
                     ds3_is_compatible_vidpid(devices[i].vid, devices[i].pid) ? "ds3" :
                     ds4_is_compatible_vidpid(devices[i].vid, devices[i].pid) ? "ds4" :
                     (devices[i].vid == 0x12ba && devices[i].pid == 0x0100) ? "gh5-raw" : "hid");
            if (usb_xusb_qualified(&devices[i]))
                snprintf(info->name, sizeof info->name, "%s", mamba_name(devices[i].vid, devices[i].pid));
            else
                snprintf(info->name, sizeof info->name, "USB %04x:%04x", devices[i].vid, devices[i].pid);
            snprintf(info->transport, sizeof info->transport, "usb");
            info->vid = devices[i].vid; info->pid = devices[i].pid;
            info->slot = slot; info->connected = 1;
            uint64_t occurrence = 0;
            for (int other = 0; other < HOST_MAX_PADS; ++other)
                if (other != slot && source_info[other].connected &&
                    source_info[other].binding.transport == GC_INSTANCE_TRANSPORT_USB &&
                    !strcmp(source_info[other].path, info->path)) occurrence = source_info[other].binding.occurrence_generation;
            if (!occurrence) occurrence = ++next_occurrence_generation;
            binding_common(slot, GC_INSTANCE_TRANSPORT_USB, occurrence);
            info->binding.interface_index = devices[i].interface_index;
            info->binding.interface_number = devices[i].interface_number;
            info->binding.alternate_setting = devices[i].alternate_setting;
            info->binding.in_endpoint = devices[i].in[0];
            info->binding.out_endpoint = devices[i].out_count ? devices[i].out[0] : 0;
            describe_output(slot);
            source_snapshot_unlock();
        }
        /* The handshake may have consumed the first change-only GIP INPUT
         * packet. Replay it through the ordinary decoder before arming the
         * normal feed loop, so held controls cannot disappear until changed. */
        if (feed->gip && feed->gip_ready && feed->xbox.pending_input_valid) {
            const uint32_t initial = xbox_take_initial_report(&feed->xbox,
                                                              feed->report, sizeof feed->report);
            if (initial) {
                feed->lenp = initial;
                source_snapshot_lock();
                raw_sample(feed->slot, feed->report, feed->lenp);
                source_snapshot_unlock();
                if (usb_decode(feed, &devices[i], &state))
                    remember(feed->slot, &state, devices[i].vid, devices[i].pid);
            } else {
                log_line("usb: %s discarded invalid queued GIP INPUT", feed->path);
            }
            continue;
        }
        usb_progress_log(feed);
        /* PR #29 bbf6e42: base HID GET_REPORT fallback on interrupt delivery,
         * not decoded publication. RAW-only GH5 packets are received but are
         * intentionally not published. The state is owned by this UsbFeed. */
        if (devices[i].kind == GC_USB_INTERFACE_HID &&
            gc_gh5_allows_fallback(devices[i].vid, devices[i].pid)) {
            if (gc_usb_fallback_due(&feed->fallback, gc_fallback_now_ms())) {
                uint8_t reply[USB_REPORT];
                struct usb_ctl_request poll;
                const unsigned report_id =
                    devices[i].layout.numbered && devices[i].layout.count
                    ? devices[i].layout.fields[0].report : 0;
                memset(&poll, 0, sizeof poll);
                memset(reply, 0, sizeof reply);
                poll.ucr_data = reply;
                poll.ucr_flags = USB_SHORT_XFER_OK;
                poll.ucr_request.bmRequestType = 0xA1;
                poll.ucr_request.bRequest = 0x01;
                USETW(poll.ucr_request.wValue, (uint16_t)(0x0100u | report_id));
                USETW(poll.ucr_request.wIndex, (uint16_t)devices[i].interface_number);
                USETW(poll.ucr_request.wLength, (uint16_t)sizeof reply);
                const int rc = ioctl(feed->fd, USB_DO_REQUEST, &poll);
                const int poll_errno = rc != 0 ? errno : 0;
                static int noted;
                if (noted++ < 4)
                    log_line("usb: %s GET_REPORT id=%#x rc=%d actlen=%d errno=%d",
                             devices[i].path, report_id, rc, poll.ucr_actlen, poll_errno);
                const int received = rc == 0 && poll.ucr_actlen > 0 &&
                    (size_t)poll.ucr_actlen <= sizeof reply;
                if (received) ++feed->fallback.get_report_successes;
                else ++feed->fallback.get_report_failures;
                int reply_nonzero = 0;
                for (int k = 0; received && k < poll.ucr_actlen; ++k)
                    reply_nonzero |= reply[k];
                if (received && reply_nonzero) {
                    /* Control replies use a separate buffer and require successful decode. */
                    if (usb_decode_report(feed, &devices[i], &state,
                                          reply, (uint32_t)poll.ucr_actlen, 1)) {
                        source_snapshot_lock();
                        raw_sample(feed->slot, reply, (size_t)poll.ucr_actlen);
                        source_snapshot_unlock();
                        feed->fallback.control_decoded = 1;
                        remember(feed->slot, &state, devices[i].vid, devices[i].pid);
                        continue;
                    }
                }
            }
        }
        if (!feed->busy) {
            feed->lenp = feed->in_xfer_len ? feed->in_xfer_len : USB_REPORT;
            feed->ep[0].nFrames = 1;
            feed->ep[0].aFrames = 0;
            feed->ep[0].status = 0;
            memset(&st, 0, sizeof st);
            st.ep_index = 0;
            if (ioctl(feed->fd, USB_FS_START, &st) == 0) {
                feed->busy = 1;
                gc_usb_progress_start(&feed->progress, gc_fallback_now_ms());
#if GC_GH5_PRECISION_DIAGNOSTIC
                if (feed->vid == 0x12ba && feed->pid == 0x0100) {
                    ++feed->trace_start_ok;
                    feed->trace_started_ms = gh5_clock_ms();
                }
#endif
                if (feed->vid == 0x12ba && feed->pid == 0x0100) {
                    static unsigned gh5_starts;
                    if (gh5_starts++ < 12)
                        log_line("gh5: USB_FS_START ok requested=%u ep=%02x", feed->lenp, feed->in_ep);
                }
            } else {
                int err = errno;
                static int noted_start;
                if (noted_start++ < 4)
                    log_line("usb: %s FS_START failed errno=%d (%s)",
                             feed->path, err, strerror(err));
                if (usb_note_io(feed, err, 0, 0)) continue;
                continue;
            }
        }
        /* PR #29: do not call USB_FS_COMPLETE until the USB file descriptor
         * reports that the in-flight transfer is ready. This avoids spinning
         * on EBUSY while the host controller is still processing the request. */
        short gh5_poll_revents = 0;
        if (feed->busy) {
            struct pollfd ready;
            memset(&ready, 0, sizeof ready);
            ready.fd = feed->fd;
            ready.events = POLLIN | POLLOUT | POLLRDNORM | POLLWRNORM;
            const int polled = poll(&ready, 1, 0);
            gh5_poll_revents = ready.revents;
            feed->progress.poll_revents = polled >= 0 ? ready.revents : 0;
            if (polled < 0) {
                const int err = errno;
                if (err == EINTR) continue;
                static unsigned gh5_poll_errors;
                if (feed->vid == 0x12ba && feed->pid == 0x0100 && gh5_poll_errors++ < 12)
                    log_line("gh5: poll error rc=%d errno=%d revents=%#x", polled, err, ready.revents);
                if (usb_note_io(feed, err, 0, 0)) continue;
                continue;
            }
            if (polled == 0 || !(ready.revents &
                (POLLIN | POLLOUT | POLLRDNORM | POLLWRNORM | POLLERR | POLLHUP | POLLNVAL))) {
                static unsigned gh5_poll_waits;
                if (feed->vid == 0x12ba && feed->pid == 0x0100 && gh5_poll_waits++ < 12)
                    log_line("gh5: poll not ready rc=%d revents=%#x busy=%d", polled,
                             ready.revents, feed->busy);
                continue;
            }
            if (feed->vid == 0x12ba && feed->pid == 0x0100) {
                static unsigned gh5_poll_ready;
                if (gh5_poll_ready++ < 12)
                    log_line("gh5: poll ready revents=%#x", ready.revents);
            }
        }
        memset(&done, 0, sizeof done);
        if (ioctl(feed->fd, USB_FS_COMPLETE, &done) != 0) {
            const int err = errno;
            if (err == EBUSY) {
                /* EBUSY leaves the transfer pending. */
                ++feed->progress.busy_returns;
                if (feed->vid == 0x12ba && feed->pid == 0x0100) {
#if GC_GH5_PRECISION_DIAGNOSTIC
                    ++feed->trace_ebusy;
#endif
                    static unsigned gh5_pending_samples;
                    const unsigned sample = ++gh5_pending_samples;
                    if (sample <= 16u || (sample % 64u) == 0u)
                        log_line("gh5: USB_FS_COMPLETE pending-snapshot path=%s fd=%d iface=%d ep=%02x errno=%d (%s) busy=%d poll_revents=%#x pending_nFrames=%u pending_aFrames=%u pending_len=%u requested=%u pending_ep_status=%#x sample=%u",
                                 feed->path, feed->fd, feed->interface_number,
                                 feed->in_ep, err, strerror(err), feed->busy,
                                 gh5_poll_revents, (unsigned)feed->ep[0].nFrames,
                                 (unsigned)feed->ep[0].aFrames, (unsigned)feed->lenp,
                                 (unsigned)feed->in_xfer_len,
                                 (unsigned)feed->ep[0].status, sample);
                }
                continue;
            }
            ++feed->progress.other_errors;
            static int noted_complete;
            if (noted_complete++ < 6)
                log_line("usb: %s FS_COMPLETE failed errno=%d (%s) busy=%d",
                         feed->path, err, strerror(err), feed->busy);
            /* In-flight EAGAIN/ETIMEDOUT keeps busy so the transfer is not restarted. */
            usb_note_io(feed, err, 0, 0);
            continue;
        }
        /* Nonzero transfer indices (e.g. Nintendo OUT) MUST NOT clear
         * the pending interrupt-IN buffer or its busy/endpoint status. */
        if (done.ep_index != 0) continue;
        gc_usb_progress_complete(&feed->progress, gc_fallback_now_ms());
        if (feed->ep[0].status) {
            ++feed->progress.endpoint_errors;
            int status = feed->ep[0].status;
            static int noted_status;
            if (noted_status++ < 6)
                log_line("usb: %s endpoint status %#x", feed->path, status);
            feed->busy = 0;
            if (usb_note_io(feed, 0, status, 0)) continue;
            continue;
        }
        feed->busy = 0;
#if GC_GH5_PRECISION_DIAGNOSTIC
        if (feed->vid == 0x12ba && feed->pid == 0x0100) {
            ++feed->trace_complete_ok;
            feed->trace_started_ms = 0;
            feed->trace_last_complete_ms = gh5_clock_ms();
            feed->trace_completed_ep = done.ep_index;
        }
#endif
        if (feed->vid == 0x12ba && feed->pid == 0x0100) {
            static unsigned gh5_completions;
            if (gh5_completions++ < 24)
                log_line("gh5: FS_COMPLETE ok ep=%d frames=%u len=%u requested=%u status=%#x",
                         done.ep_index, feed->ep[0].aFrames, (unsigned)feed->lenp,
                         feed->in_xfer_len, feed->ep[0].status);
        }
        if (feed->ep[0].aFrames != 1 ||
            feed->lenp == 0 || feed->lenp > sizeof feed->report) {
            ++feed->progress.frame_rejections;
            usb_note_io(feed, 0, 0, 1);
            continue;
        }
        gc_usb_progress_input(&feed->progress, gc_fallback_now_ms());
        gc_usb_fallback_interrupt(&feed->fallback, gc_fallback_now_ms());
        source_snapshot_lock();
        if (policy_revoked[feed->slot] || atomic_load_explicit(&source_fault,memory_order_acquire)) {
            source_snapshot_unlock(); continue;
        }
        raw_sample(feed->slot, feed->report, feed->lenp);
        source_snapshot_unlock();
#if GC_GH5_PRECISION_DIAGNOSTIC
        if (feed->vid == 0x12ba && feed->pid == 0x0100)
            feed->trace_last_input_ms = gh5_clock_ms();
#endif
        const int decoded_ok = usb_decode(feed, &devices[i], &state);
#if GC_GH5_PRECISION_DIAGNOSTIC
        if (feed->vid == 0x12ba && feed->pid == 0x0100) {
#if GC_GH5_USB_DIAGNOSTIC
            /* This counter tracks preparation, not VDA publication. */
            if (decoded_ok) ++feed->trace_neutral_state_prepared;
#else
            ++feed->trace_decode_attempts;
            if (decoded_ok) ++feed->trace_decode_success;
            else ++feed->trace_decode_failure;
#endif
        }
#endif
        /* RAW-only and neutral diagnostic frames never count as HID decoder
         * failures/successes. Keep actual controller results independent. */
        int gh5_diagnostic_input = 0;
#if GC_GH5_USB_DIAGNOSTIC
        gh5_diagnostic_input = feed->vid == 0x12ba && feed->pid == 0x0100;
#endif
#if GC_GH5_USB_DIAGNOSTIC
        gc_usb_progress_account(&feed->progress, gh5_diagnostic_input, decoded_ok);
        if (!decoded_ok) continue;
#else
        (void)gh5_diagnostic_input;
        if (!gc_usb_progress_decode(&feed->progress, decoded_ok)) continue;
#endif
        remember(feed->slot, &state, devices[i].vid, devices[i].pid);
    }
}

void gc_service_inject_tick(long now)
{
    source_snapshot_lock();
    int active = sources_active;
    GcConfigStore *recovery_config = inject_config;
    source_snapshot_unlock();
    if (!active) return;
    for (int slot = 0; slot < HOST_MAX_PADS; ++slot) {
        if (!source_dispatch_lock()) return;
        if (retirement_pending[slot]) {
            fprintf(stderr, "inject: slot %d retiring (retirement_pending)\n", slot);
            if (inject_ready) vpad_remove(slot);
            backend_added[slot] = retirement_pending[slot] = 0;
        }
        source_dispatch_unlock();
    }
    /* Recovery never reuses samples captured during quarantine. Writer precedes
     * source, and only a fresh complete publication reopens sample collection. */
    if (recovery_config && gc_config_policy_acquire(recovery_config,gc_config_generation(recovery_config)) == 0) {
        if (source_dispatch_lock()) {
            for (int slot = 0; slot < HOST_MAX_PADS; ++slot) {
                if (policy_revoked[slot] && !retirement_pending[slot]) {
                    GcControllerResolution resolved;
                    if (gc_config_resolve_controller(recovery_config,&source_info[slot].binding,&resolved) == 0 &&
                        resolved.kind != GC_RESOLVE_POLICY_UNAVAILABLE) policy_revoked[slot] = 0;
                }
            }
            source_dispatch_unlock();
        }
        gc_config_policy_release(recovery_config);
    }
    if (source_dispatch_lock()) { usb_tick(); source_dispatch_unlock(); }
    refresh_policy();
    apply_bt(now);
    for (int slot = 0; slot < HOST_MAX_PADS; ++slot) {
        char held_path[96];
        char held_protocol[24];
        held_path[0] = 0;
        held_protocol[0] = 0;
        source_snapshot_lock();
        /* Require validated input before advertising any virtual pad. */
        int add = inject_ready && usb_owned[slot] && output_allowed[slot] &&
                  last_valid[slot] &&
                  !backend_added[slot] && now >= add_retry_at[slot] &&
                  !vpad_add_is_quarantined(slot);
        int waiting_for_input = inject_ready && usb_owned[slot] && output_allowed[slot] &&
                  !last_valid[slot] && !backend_added[slot];
        if (waiting_for_input) {
            snprintf(held_path, sizeof held_path, "%s",
                     source_info[slot].path[0] ? source_info[slot].path : "source");
            snprintf(held_protocol, sizeof held_protocol, "%s",
                     source_info[slot].protocol[0] ? source_info[slot].protocol : "unknown");
        }
        uint64_t epoch = slot_epoch[slot], generation = policy_generation[slot];
        GcConfigStore *config = inject_config;
        source_snapshot_unlock();
        if (waiting_for_input && !no_input_noted[slot]) {
            /* Record why virtual-pad creation was deferred. */
            no_input_noted[slot] = 1;
            log_line("slot %d: virtual pad waiting for first readable input from %s (%s)",
                     slot, held_path, held_protocol);
        }
        if (!waiting_for_input && !backend_added[slot]) no_input_noted[slot] = 0;
        if (add && begin_dispatch(slot, config, generation, epoch, 0)) {
            int accepted = vpad_add(slot);
            source_snapshot_lock();
            if (epoch == slot_epoch[slot] && !want_remove[slot]) {
                if (accepted) backend_added[slot] = 1;
                else add_retry_at[slot] = now + 1000;
            }
            source_snapshot_unlock();
            end_dispatch(config);
        }
    }
    if (inject_ready) vpad_poll(now);
#if GC_GH5_USB_DIAGNOSTIC || GC_GH5_TCP_PREFLIGHT_MS > 0
    /* Release queued state only if AddDevice was never called. */
    if (inject_ready) {
        for (int slot = 0; slot < HOST_MAX_PADS; ++slot) {
            if (!vpad_retryable(slot)) continue;
            source_snapshot_lock();
            if (usb_owned[slot] && backend_added[slot] && !want_remove[slot]) {
                backend_added[slot] = 0;
                add_retry_at[slot] = now + 1000;
                log_line("GH5_VDA_R11 safe_pre_add_retry slot=%d delay_ms=1000 "
                         "AddDevice_never_called=1; uncertain_device_not_retried", slot);
            }
            source_snapshot_unlock();
        }
    }
#endif
    refresh_policy();
    push_sources();
}

int gc_service_inject_live(int slot)
{
    int live;
    if (slot < 0 || slot >= HOST_MAX_PADS) return 0;
    source_snapshot_lock();
    live = slot_live[slot];
    source_snapshot_unlock();
    return live;
}

int gc_service_inject_identity(int slot, uint16_t *vid, uint16_t *pid)
{
    int valid;
    if (slot < 0 || slot >= HOST_MAX_PADS) return 0;
    source_snapshot_lock();
    valid = last_valid[slot];
    if (vid) *vid = valid ? slot_vid[slot] : 0;
    if (pid) *pid = valid ? slot_pid[slot] : 0;
    source_snapshot_unlock();
    return valid;
}

static int copy_state(pad_state st, ScePadData *out)
{
    memset(out, 0, sizeof *out);
    out->buttons = st.buttons;
    out->leftStick.x = st.lx;
    out->leftStick.y = st.ly;
    out->rightStick.x = st.rx;
    out->rightStick.y = st.ry;
    out->analogButtons.l2 = st.l2;
    out->analogButtons.r2 = st.r2;
    out->quat.w = 1.0f;
    if (st.has_motion) {
        /* Match the normalized Sony sensor-count convention of this source.
         * Calibration/alternate sensor scales need per-protocol handling. */
        out->vel.x = st.gyro[0] / 1024.0f * 0.01745329252f;
        out->vel.y = st.gyro[1] / 1024.0f * 0.01745329252f;
        out->vel.z = st.gyro[2] / 1024.0f * 0.01745329252f;
        out->accel.x = st.accel[0] / 8192.0f;
        out->accel.y = st.accel[1] / 8192.0f;
        out->accel.z = st.accel[2] / 8192.0f;
    }
    if (st.has_touch) {
        for (int i = 0; i < 2; ++i) {
            if (!st.touch[i].down) continue;
            ScePadTouch *touch = &out->touchData.touch[out->touchData.fingers++];
            touch->finger = (uint8_t)i;
            touch->x = st.touch[i].x;
            touch->y = st.touch[i].y;
        }
    }
    out->connected = 1;
    return 1;
}

int gc_service_inject_copy(int slot, ScePadData *out)
{
    if (!out || slot < 0 || slot >= HOST_MAX_PADS) return 0;
    memset(out, 0, sizeof *out);
    source_snapshot_lock();
    int valid = last_valid[slot];
    if (valid) copy_state(last_state[slot], out);
    source_snapshot_unlock();
    return valid;
}

size_t gc_service_inject_sources(GcServiceSource *out, size_t capacity)
{
    size_t count = 0;
    source_snapshot_lock();
    for (int slot = 0; slot < HOST_MAX_PADS; ++slot) {
        if (!source_info[slot].connected || want_remove[slot]) continue;
        if (out && count < capacity) {
            out[count] = source_info[slot];
            out[count].input_available = last_valid[slot];
            out[count].virtual_live = slot_live[slot];
        }
        ++count;
    }
    source_snapshot_unlock();
    return out ? (count < capacity ? count : capacity) : count;
}

int gc_service_inject_read_source(const char *path, ScePadData *out,
                                 uint8_t *raw, size_t raw_capacity,
                                 size_t *raw_length)
{
    int valid = 0;
    if (out) memset(out, 0, sizeof *out);
    if (raw_length) *raw_length = 0;
    if (!path || !out) return 0;
    source_snapshot_lock();
    for (int slot = 0; slot < HOST_MAX_PADS; ++slot) {
        if (!source_info[slot].connected || want_remove[slot] ||
            strcmp(source_info[slot].path, path)) continue;
        size_t length = source_raw_length[slot];
        if (length > raw_capacity) length = raw_capacity;
        if (!raw) length = 0;
        if (length) memcpy(raw, source_raw[slot], length);
        if (raw_length) *raw_length = length;
        valid = last_valid[slot];
        if (valid) copy_state(last_state[slot], out);
        break;
    }
    source_snapshot_unlock();
    return valid;
}

static int match_equal(const GcControllerMatch *a, const GcControllerMatch *b)
{
    return a->transport == b->transport &&
        !strncmp(a->session_id, b->session_id, sizeof a->session_id) &&
        !strncmp(a->path, b->path, sizeof a->path) &&
        a->connection_generation == b->connection_generation &&
        a->occurrence_generation == b->occurrence_generation &&
        a->vid == b->vid && a->pid == b->pid &&
        !strncmp(a->protocol, b->protocol, sizeof a->protocol) &&
        a->interface_index == b->interface_index && a->interface_number == b->interface_number &&
        a->alternate_setting == b->alternate_setting &&
        a->in_endpoint == b->in_endpoint && a->out_endpoint == b->out_endpoint &&
        a->identity.state == b->identity.state && a->identity.proof == b->identity.proof &&
        !strncmp(a->identity.instance_id, b->identity.instance_id, sizeof a->identity.instance_id);
}

/* Caller holds inject_mu. A path/model alone cannot reject same-model ABA. */
static int checked_source_slot(const GcServiceSource *expected)
{
    if (!expected || !expected->connection_generation || !sources_active) return -1;
    for (int slot = 0; slot < HOST_MAX_PADS; ++slot) {
        const GcServiceSource *current = &source_info[slot];
        if (current->connected && !want_remove[slot] && binding_observed[slot] &&
            current->connection_generation == expected->connection_generation &&
            current->vid == expected->vid && current->pid == expected->pid &&
            !strncmp(current->path, expected->path, sizeof current->path) &&
            !strncmp(current->protocol, expected->protocol, sizeof current->protocol) &&
            match_equal(&current->binding, &expected->binding) &&
            !policy_revoked[slot] && !atomic_load_explicit(&source_fault, memory_order_acquire)) return slot;
    }
    return -1;
}


static void digital_span_from_layout(const GcHidLayout *layout,
                                     unsigned *offset, uint32_t *mask)
{
    const GcHidField *lists[2];
    size_t counts[2];
    size_t l, i;
    unsigned last = 0, w, shift, noise_start = 32;
    int any = 0;
    *offset = 0; *mask = 0;
    if (!layout) return;
    /* Both arrays matter: the parsed list holds the claimed byte-wide fields,
     * the raw list holds everything the descriptor declared, including the
     * non-byte-aligned counter that must not be treated as a control. */
    lists[0] = layout->fields; counts[0] = layout->count;
    lists[1] = layout->raw_fields; counts[1] = layout->raw_count;
    for (l = 0; l < 2; ++l)
        for (i = 0; i < counts[l]; ++i) {
            const GcHidField *f = &lists[l][i];
            if (f->bits > 1 && (f->offset % 8u) != 0) {
                const unsigned byte = f->offset / 8u;
                if (byte < noise_start) noise_start = byte;
            }
        }
    for (l = 0; l < 2; ++l)
        for (i = 0; i < counts[l]; ++i) {
            const GcHidField *f = &lists[l][i];
            unsigned end;
            if (f->bits == 0 || f->bits > 8) continue;
            end = (f->offset + f->bits - 1u) / 8u;
            if (end >= noise_start) continue;
            if (!any) { last = end; any = 1; }
            else if (end > last) last = end;
        }
    if (!any) return;
    /* Buttons sit after the analog bytes: anchor on the last digital byte and
     * keep one byte of headroom in front of it (the 32-bit mask limit). */
    w = last >= 1 ? last - 1 : 0;
    shift = layout->numbered ? 1u : 0u;
    for (l = 0; l < 2; ++l)
        for (i = 0; i < counts[l]; ++i) {
            const GcHidField *f = &lists[l][i];
            unsigned bit;
            if (f->bits == 0 || f->bits > 8) continue;
            if ((f->offset + f->bits - 1u) / 8u >= noise_start) continue;
            for (bit = 0; bit < f->bits; ++bit) {
                const unsigned absolute = f->offset + bit;
                const unsigned byte = absolute / 8u;
                if (byte < w || byte > w + 3) continue;
                *mask |= 1u << ((byte - w) * 8u + (absolute % 8u));
            }
        }
    if (!*mask) return;
    *offset = w + shift;
}

int gc_service_inject_source_digital_span(int slot, const char *path,
                                          unsigned *offset, uint32_t *mask)
{
    GcUsbDevice devices[HOST_MAX_PADS];
    size_t count, i;
    if (!offset || !mask) return -1;
    *offset = 0; *mask = 0;
    if (slot >= 0 && slot < HOST_MAX_PADS) {
        source_snapshot_lock();
        digital_span_from_layout(&source_hid_layout[slot], offset, mask);
        source_snapshot_unlock();
    }
    if (*mask) return 0;
    if (!path) return -1;
    count = gc_usb_devices(devices, HOST_MAX_PADS);
    {
        size_t k; int found = 0;
        for (k = 0; k < count; ++k)
            if (!strcmp(devices[k].path, path)) {
                found = 1;
                log_line("span: slot=%d path=%s inv=%zu fields=%zu raw=%zu kind=%d"
                         " f0=%u/%u f1=%u/%u f2=%u/%u r0=%u/%u r1=%u/%u",
                         slot, path, count, devices[k].layout.count,
                         devices[k].layout.raw_count, (int)devices[k].kind,
                         devices[k].layout.count > 0 ? devices[k].layout.fields[0].offset : 0,
                         devices[k].layout.count > 0 ? devices[k].layout.fields[0].bits : 0,
                         devices[k].layout.count > 1 ? devices[k].layout.fields[1].offset : 0,
                         devices[k].layout.count > 1 ? devices[k].layout.fields[1].bits : 0,
                         devices[k].layout.count > 2 ? devices[k].layout.fields[2].offset : 0,
                         devices[k].layout.count > 2 ? devices[k].layout.fields[2].bits : 0,
                         devices[k].layout.raw_count > 0 ? devices[k].layout.raw_fields[0].offset : 0,
                         devices[k].layout.raw_count > 0 ? devices[k].layout.raw_fields[0].bits : 0,
                         devices[k].layout.raw_count > 1 ? devices[k].layout.raw_fields[1].offset : 0,
                         devices[k].layout.raw_count > 1 ? devices[k].layout.raw_fields[1].bits : 0);
            }
        if (!found)
            log_line("span: slot=%d path=%s not in inventory (count=%zu)", slot, path, count);
    }
    for (i = 0; i < count; ++i) {
        const char *have = devices[i].path;
        const char *want = path;
        if (!strncmp(have, "/dev/", 5)) have += 5;
        if (!strncmp(want, "/dev/", 5)) want += 5;
        if (strcmp(have, want)) continue;
        digital_span_from_layout(&devices[i].layout, offset, mask);
        break;
    }
    return *mask ? 0 : -1;
}

int gc_service_inject_read_source_checked(const GcServiceSource *expected,
    ScePadData *out, uint8_t *raw, size_t raw_capacity, size_t *raw_length)
{
    if (out) memset(out, 0, sizeof *out);
    if (raw && raw_capacity) memset(raw, 0, raw_capacity);
    if (raw_length) *raw_length = 0;
    if (!out) return 0;
    source_snapshot_lock();
    int slot = checked_source_slot(expected);
    if (slot >= 0 && !last_valid[slot]) slot = -1;
    if (slot >= 0) {
        copy_state(last_state[slot], out);
        size_t length = source_raw_length[slot];
        if (length > raw_capacity) length = raw_capacity;
        if (!raw) length = 0;
        if (length) memcpy(raw, source_raw[slot], length);
        if (raw_length) *raw_length = length;
    }
    source_snapshot_unlock();
    return slot >= 0;
}

int gc_service_inject_source_acquire(const GcServiceSource *expected)
{
    if (!source_dispatch_lock()) return -1;
    source_snapshot_lock();
    int slot = checked_source_slot(expected);
    source_snapshot_unlock();
    if (slot < 0) source_dispatch_unlock();
    return slot >= 0 ? 0 : -1;
}

void gc_service_inject_source_release(void)
{
    source_dispatch_unlock();
}

int gc_service_inject_instance_consumer_prepare(GcConfigStore *store)
{
    if (!store || !gc_service_features_instance_revocation_epoch() || !source_dispatch_lock()) return -1;
    int result = -1;
    if (!prepared_store && !sources_active && !atomic_load_explicit(&source_fault, memory_order_acquire)) {
        if (pthread_once(&session_once, initialize_session) == 0 && session_ready) {
            prepared_store = store; result = 0;
        }
    }
    source_dispatch_unlock();
    return result;
}
void gc_service_inject_instance_policy_invalidated(void *context,
    GcInstanceInvalidationReason reason, uint64_t generation)
{
    if (!context || context != prepared_store || !generation ||
        (reason != GC_INSTANCE_INVALIDATE_EXTERNAL_RELOAD_FAILURE &&
         reason != GC_INSTANCE_INVALIDATE_INCOMPLETE_INTERNAL_ROLLBACK)) {
        atomic_store_explicit(&source_fault, 1, memory_order_release); return;
    }
    int acquired = source_depth == 0;
    if (acquired && !source_dispatch_lock()) {
        atomic_store_explicit(&source_fault, 1, memory_order_release);
        gc_service_features_instance_policy_invalidated(reason, generation); return;
    }
    for (int slot = 0; slot < HOST_MAX_PADS; ++slot) {
        retire_samples(slot); policy_revoked[slot] = 1;
    }
    for (int i = 0; i < USB_SLOTS; ++i) {
        memset(&usb_feed[i].decoded,0,sizeof usb_feed[i].decoded);
        usb_feed[i].decoded.leftStick.x = usb_feed[i].decoded.leftStick.y = 128;
        usb_feed[i].decoded.rightStick.x = usb_feed[i].decoded.rightStick.y = 128;
    }
    gc_service_features_instance_policy_invalidated(reason, generation);
    uint64_t epoch = gc_service_features_instance_revocation_epoch();
    if (!epoch || epoch == UINT64_MAX) atomic_store_explicit(&source_fault,1,memory_order_release);
    if (acquired) source_dispatch_unlock();
}
int gc_service_inject_instance_acquire(const GcControllerMatch *expected)
{
    if (!expected || !session_ready || !prepared_store ||
        atomic_load_explicit(&source_fault, memory_order_acquire) ||
        expected->identity.state != GC_INSTANCE_STABLE ||
        expected->identity.proof != GC_INSTANCE_PROOF_CLASSIC_PEER ||
        expected->transport != GC_INSTANCE_TRANSPORT_CLASSIC || !source_dispatch_lock()) return -1;
    int found = 0;
    for (int slot = 0; slot < HOST_MAX_PADS; ++slot)
        if (source_info[slot].connected && !want_remove[slot] && binding_observed[slot] &&
            match_equal(expected, &source_info[slot].binding)) found = 1;
    if (!found) source_dispatch_unlock();
    return found ? 0 : -1;
}
void gc_service_inject_instance_release(void) { source_dispatch_unlock(); }

int gc_service_inject_process_session(char *out, size_t capacity)
{
    if (!out || capacity < sizeof process_session ||
        pthread_once(&session_once, initialize_session) != 0 || !session_ready) return -1;
    memcpy(out, process_session, sizeof process_session);
    return 0;
}
