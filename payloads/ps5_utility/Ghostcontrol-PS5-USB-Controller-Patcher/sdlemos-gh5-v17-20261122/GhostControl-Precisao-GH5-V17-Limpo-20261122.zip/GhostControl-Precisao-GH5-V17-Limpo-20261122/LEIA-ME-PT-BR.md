# GhostControl Experimental — fonte atualizada 10/11/2026

**ESTE PACOTE CONTÉM CÓDIGO-FONTE**, não um ELF pronto. Abra **`COMPILE-PS5-FIRST.md`** para compilar o serviço GhosttoothAPI no seu PC/WSL com SDK PS5. O script `build_elf.sh` gera o hash SHA-256 do ELF após compilar. Nunca execute dois ELFs GhosttoothAPI ao mesmo tempo.

- `INTEGRACAO-ATUALIZADA-PR29-PR32-PR33.md`: todos os commits, comentários, conflitos e diferenças em relação ao upstream.
- `docs/README-Lemos-Ghostcontrol-Testing.md`: o guia do desenvolvedor enviado ao Lemos (testador); origem preservada.
- `docs/GUIA-MESTRE-Lemos-v3.md`: roteiro de coleta anterior como referência.
- `docs/CHANGES-SINCE-OLD.md`: mudanças técnicas efetivamente portadas desde nosso ZIP anterior.
- `SOURCE-TREE-SHA256.txt`: identidade verificável dos fontes deste ZIP.
- `run_host_tests.sh`: regressões host de parser, Bluetooth e integração/diagnóstico.

**Firmware PS5 alvo:** 11.60. Nenhum teste físico feito neste ambiente. `AddDevice 0x803b0006` não confirma erro nem sucesso de bind por si só; coleta de klog/MBus permanece essencial. O EBUSY pode coexistir com relatórios HID válidos; não fazer alterações especulativas do ciclo START/poll/COMPLETE.

**Experimental:** instrumentação extra EBUSY, 040B:0897 e resumo GH5 por segundo, sem alterar transferências.
