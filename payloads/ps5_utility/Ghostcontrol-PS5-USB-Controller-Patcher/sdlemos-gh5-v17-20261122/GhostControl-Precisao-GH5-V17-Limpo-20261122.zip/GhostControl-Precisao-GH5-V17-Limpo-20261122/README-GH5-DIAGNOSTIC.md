# Ghostcontrol GH5 USB/VDA diagnostic build

This is a diagnostic source build for the PS3 Guitar Hero wireless receiver:

- VID:PID `12BA:0100`
- Target service: `GhosttoothAPI`
- Output ELF: `GhosttoothAPI/GhosttoothAPI-GH5-diagnostic.elf`

It is **not** a Guitar Hero controller implementation yet. In the default mode it captures the receiver's raw HID input reports and logs USB/VDA observations without creating a virtual pad. An optional marker enables a neutral-data VDA/MBUS probe after USB reports are received.

## Included changes

1. PR #29 USB handling: skip unqualified interfaces before opening a feed; wait for readiness with `poll()` before `USB_FS_COMPLETE`; classify `ENOTTY` as fatal and safely release an unplugged USB feed.
2. MBus parser commit `a8e1acc05f2e45e34221d3fe74ac850d62bf9cc2`: parse `deviceType` with `strtoul(..., 0)`, accepting decimal `22` and hexadecimal `0x16`, while reading `deviceId` as hexadecimal. Both legacy and newer `DEVICE_ADDED` formats remain supported.
3. PR #32 USB/service changes: endpoint `wMaxPacketSize` transfer sizing, safe cleanup when the device disappears, proper HID `GET_REPORT`, HID descriptor cache, 8 ms service loop, GIP/Xbox path, DS3 path, DS4 lightbar path, and generic-HID fallback after a failed DS3 startup.
4. GH5-specific diagnostics: descriptor bytes and parsed layout, interface/endpoints, driver detach and `SET_IDLE`, `USB_FS_INIT/OPEN/START`, packet size, `poll()` readiness, `USB_FS_COMPLETE`, and up to 256 changed raw reports (bounded).
5. MBus identification-window counters: bytes, lines, MBus event lines and candidate count, to distinguish an empty kernel-log stream from a parser rejection.

The DS3 decoder intentionally does **not** process `12BA:0100`. Guitar Hero/Rock Band receivers have instrument-specific HID reports. This build captures those raw reports instead of incorrectly treating them as a DualShock 3.

## Build on WSL

Install the Prospero SDK and its PS5-target PacBrew dependencies first. This project expects the target libraries/headers under:

`$PS5_PAYLOAD_SDK/target/user/homebrew`

Required dependency families include json-c, curl, minizip, OpenSSL, zlib/zstd, libpsl and the CA bundle (`etc/ca-bundle.crt`). These must be PS5-target builds, not Ubuntu host packages.

```bash
export PS5_PAYLOAD_SDK=/opt/ps5-payload-sdk

make -C GhosttoothAPI clean VARIANT=gh5-diagnostic
make -C GhosttoothAPI VARIANT=gh5-diagnostic
```

Expected output:

`GhosttoothAPI/GhosttoothAPI-GH5-diagnostic.elf`

## Stage 1 — raw USB capture only (default)

1. Stop the currently running GhosttoothAPI/Ghostcontrol service in Toolbox and close Toolbox.
2. Keep the existing `/data/ghostcontrol-app-service` directory and its configuration/logs. Do not rename files.
3. Ensure the marker below does **not** exist:

   `/data/ghostcontrol-app-service/gh5-vpad-probe.enable`

4. Load only `GhosttoothAPI-GH5-diagnostic.elf` through the PS5 ELF loader (port 9021).
5. Connect the Guitar Hero receiver. Press each fret separately, strum up/down, and operate the whammy if present for about 15–20 seconds.
6. Collect both `app-service.log` and `vpad.log` from `/data/ghostcontrol-app-service`.

Default mode logs raw USB reports only for `12BA:0100`; it does not create a virtual pad and does not decode fret/strum buttons yet.

## Stage 2 — optional VDA/MBUS probe

Only after saving Stage 1 logs:

1. Stop/unload the diagnostic service.
2. Create a zero-byte marker file:

   `/data/ghostcontrol-app-service/gh5-vpad-probe.enable`

3. Restart/load the same diagnostic ELF. The marker state is read once per process, so restarting is required.
4. Repeat the short capture and save `app-service.log` and `vpad.log`.
5. Delete the marker and stop the diagnostic ELF after the test.

With the marker present, every received GH5 report causes a neutral `ScePadData` frame to be supplied to the VDA path. This is only a creation/identification/bind probe: **it does not map guitar buttons to DualSense buttons**. Keep a normal controller available for any system user-assignment prompt, and do not test in a game until the diagnostic logs confirm a successful bind.

If Stage 2 ends with `virtual pad not identified` or zero MBus candidates, do not repeatedly relaunch the probe. The service deliberately leaves an unidentifiable VDA object untouched rather than guessing a handle. Remove the marker, stop the payload, reboot the PS5 to clear any pending virtual-device state, and only then repeat a probe. Run no other klog reader on TCP 3232 during this test.

## What the logs should tell us

- No `gh5: USB device`: the device was not enumerated by the scanner.
- Device/interface shown but no `USB_FS_OPEN`: interface admission/opening failed.
- `USB_FS_START` succeeds but `poll not ready` repeats: transfer readiness is the current USB blocker.
- `poll ready` followed by `USB_FS_COMPLETE failed`: the completion ioctl/status is the blocker; errno, revents and endpoint status are logged.
- `gh5: RAW report=... len=27`: input is reaching the service; raw bytes are preserved for the Guitar Hero decoder work.
- Stage 2 `AddDevice` followed by raw `DEVICE_ADDED` and `MBus parsed ...`: virtual-device discovery works.
- `MBus stats ... bytes=0`: no kernel-log bytes reached this process in the identification window.
- MBus event line present but `not matched`: the event arrived but did not satisfy the DualSense identity filter.

## Validation boundary

The source was checked locally with Clang syntax-only builds using mock USB/Prospero interface headers for the changed service/USB/controller units. The MBus parser was executed in a host smoke test for the legacy format, `deviceType=22`, `deviceType=0x16`, and rejection of `deviceType=34`. The PS5 Payload SDK is not installed in the packaging environment, so a full Prospero link and on-console test have **not** been performed here.
