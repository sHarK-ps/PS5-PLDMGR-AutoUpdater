#!/usr/bin/env python3
"""Passive klogsrv TCP:3232 receiver for GH5 diagnostics (Windows/macOS/Linux).

No commands are sent to the PS5, no state is changed on the console.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import select
import socket
import tempfile
import time
from datetime import datetime, timezone
from pathlib import Path

MAX_CAPTURE_BYTES = 8 * 1024 * 1024


def capture(host: str, port: int, seconds: float, output: Path, *,
            expected_text: str | None = None) -> dict:
    if not (0 < seconds <= 300):
        raise ValueError('seconds must be between 0 and 300')
    output = Path(output)
    output.parent.mkdir(parents=True, exist_ok=True)
    samples = bytearray()
    eof = False
    connected = False
    error = None
    began = time.monotonic()
    try:
        with socket.create_connection((host, port), timeout=min(seconds, 5.0)) as sock:
            connected = True
            sock.setblocking(False)
            deadline = time.monotonic() + seconds
            while len(samples) < MAX_CAPTURE_BYTES:
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    break
                ready, _, _ = select.select([sock], [], [], min(0.15, remaining))
                if not ready:
                    continue
                try:
                    data = sock.recv(min(4096, MAX_CAPTURE_BYTES - len(samples)))
                except BlockingIOError:
                    continue
                if not data:
                    eof = True
                    break
                samples.extend(data)
    except (OSError, TimeoutError) as e:
        error = f'{type(e).__name__}: {e}'
    output.write_bytes(samples)
    state = ('BYTES_RECEIVED' if samples else
             'CONNECT_FAILED' if not connected else
             'EOF_NO_BYTES' if eof else
             'TRANSPORT_ERROR' if error else 'CONNECTED_SILENT')
    report = {
        'host': host,
        'port': port,
        'state': state,
        'connected': connected,
        'bytes': len(samples),
        'newlines': samples.count(b'\n'),
        'eof': eof,
        'error': error,
        'elapsed_seconds': round(time.monotonic() - began, 3),
        'sha256': hashlib.sha256(samples).hexdigest() if samples else None,
        'capture_file': str(output),
        'text_preview': bytes(samples[:512]).decode('utf-8', errors='replace'),
        'interpretation': ('TCP received payload: inspect whether lines are real kernel messages.' if samples else
                           'TCP accepted but returned zero bytes: klogsrv health and event emission unconfirmed.' if connected else
                           'No TCP connection: server/port/network unverified.'),
    }
    if expected_text is not None:
        expected = expected_text.encode('utf-8')
        report['expected_text'] = expected_text
        report['expected_text_matches'] = samples.count(expected)
        matching_lines = []
        if report['expected_text_matches']:
            for line in reversed(samples.splitlines()):
                position = line.find(expected)
                if position >= 0:
                    matching_lines.append(line[position:position + 200].decode('utf-8', errors='replace'))
                    if len(matching_lines) == 3:
                        break
        report['expected_text_lines'] = matching_lines[::-1]
    return report


def main():
    p = argparse.ArgumentParser(
        description='GH5 passive klogsrv port 3232 receiver; no writes to PS5',
        epilog='Exit status: 0 received expected data, 2 connection failed, '
               '3 connected without bytes, 4 received bytes without the requested text.',
    )
    p.add_argument('ps5_ip', help='PS5 LAN IP (not 127.0.0.1 when run on PC)')
    p.add_argument('--port', type=int, default=3232)
    p.add_argument('--seconds', type=float, default=20)
    p.add_argument('--output', type=Path, help='Explicit capture file')
    p.add_argument('--summary', type=Path, help='Explicit summary file')
    p.add_argument('--expect-text', help='Look for this UTF-8 text in the capture')
    args = p.parse_args()
    if args.expect_text is not None and (
        not args.expect_text.strip() or len(args.expect_text.encode('utf-8')) > 128
        or '\r' in args.expect_text or '\n' in args.expect_text
    ):
        p.error('--expect-text requires nonblank text on one line (up to 128 UTF-8 bytes)')
    started = datetime.now(timezone.utc)
    if args.output is None and args.summary is None:
        history = Path('klogsrv-captures').resolve()
        history.mkdir(exist_ok=True)
        folder = Path(tempfile.mkdtemp(prefix=started.strftime('%Y%m%dT%H%M%SZ-'), dir=history))
    else:
        folder = Path.cwd()
    output = args.output or folder / 'klogsrv-capture.bin'
    summary = args.summary or folder / 'klogsrv-summary.json'
    if (output.resolve() == summary.resolve()
        or (output.exists() and summary.exists() and output.samefile(summary))):
        p.error('--output and --summary must use different files')
    print(f'Passive capture {args.ps5_ip}:{args.port} for up to {args.seconds}s. While connected, trigger a known kernel-log event if possible.')
    result = capture(args.ps5_ip, args.port, args.seconds, output, expected_text=args.expect_text)
    result['started_at_utc'] = started.isoformat()
    result['summary_file'] = str(summary)
    summary.write_text(json.dumps(result, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
    print(json.dumps(result, indent=2, ensure_ascii=False))
    if result['bytes']:
        return 4 if args.expect_text is not None and not result['expected_text_matches'] else 0
    return 3 if result['connected'] else 2

if __name__ == '__main__':
    raise SystemExit(main())
