#!/usr/bin/env python3
"""Test the log-check program with simulated SDK responses."""
from pathlib import Path
import subprocess
import tempfile

root = Path(__file__).resolve().parents[3]
subject = root / "tools/diagnostics/klog-check.c"
mock = r"""
#include <assert.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

static unsigned writes, pauses;
static char run_id[65];

int klog_puts(const char *line)
{
    const char *prefix = "GH5_KLOG_CHECK ";
    assert(strncmp(line, prefix, strlen(prefix)) == 0);
    const char *id = line + strlen(prefix);
    const char *space = strchr(id, ' ');
    assert(space != NULL && space > id && space - id < (int)sizeof run_id);
    if (!writes)
        memcpy(run_id, id, (size_t)(space - id));
    else
        assert(strlen(run_id) == (size_t)(space - id) && !memcmp(run_id, id, strlen(run_id)));
    ++writes;
    assert(space[1] == '0' + (int)writes && !strcmp(space + 2, "/3"));
    return getenv("GH5_TEST_ALL_FAIL") || writes == 2 ? -1 : 0;
}

unsigned int sleep(unsigned int seconds)
{
    assert(seconds == 1);
    ++pauses;
    return 0;
}

int gc_notify_send(const char *summary)
{
    assert(writes == 3 && pauses == 2);
    assert(strstr(summary, run_id) && !strstr(summary, "GH5_KLOG_CHECK"));
    assert(strstr(summary, getenv("GH5_TEST_ALL_FAIL") ? "-1/-1/-1" : "0/-1/0"));
    return 0;
}
"""

with tempfile.TemporaryDirectory() as directory:
    path = Path(directory)
    header = path / "ps5/klog.h"
    header.parent.mkdir()
    header.write_text("int klog_puts(const char *text);\n")
    (path / "mock.c").write_text(mock)
    subprocess.run(["cc", "-std=c11", "-Wall", "-Wextra", "-Werror",
                    "-I", str(path), "-I", str(root / "core/src"),
                    str(subject), "mock.c", "-o", "check"], cwd=path, check=True)
    executable = str(path / "check")
    result = subprocess.run([executable], capture_output=True, text=True, check=True)
    assert "0/-1/0" in result.stdout and "GH5_KLOG_CHECK" not in result.stdout
    result = subprocess.run([executable], env={"GH5_TEST_ALL_FAIL": "1"},
                            capture_output=True, text=True)
    assert result.returncode == 1 and "-1/-1/-1" in result.stdout
print("PASS: three independent log writes and separate on-screen status")
