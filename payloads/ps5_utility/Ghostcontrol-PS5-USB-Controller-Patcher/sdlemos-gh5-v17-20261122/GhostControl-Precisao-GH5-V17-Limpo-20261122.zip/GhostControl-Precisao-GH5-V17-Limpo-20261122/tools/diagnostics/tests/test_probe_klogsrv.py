import socket, threading, time, tempfile, json, sys
import subprocess
from pathlib import Path
from unittest.mock import MagicMock, patch
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from probe_klogsrv import capture

def serve(payload, hold_sec=0.0):
    listener = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    listener.bind(('127.0.0.1',0));listener.listen(1)
    port=listener.getsockname()[1]
    def run():
        try:
            peer,_=listener.accept()
            with peer:
                if payload: peer.sendall(payload)
                if hold_sec:time.sleep(hold_sec)
        finally: listener.close()
    th=threading.Thread(target=run, daemon=True);th.start()
    return port,th

def run_cli(payload, hold_sec, output, *options):
    port, thread = serve(payload, hold_sec)
    summary = output.with_suffix('.json')
    script = Path(__file__).resolve().parents[1] / 'probe_klogsrv.py'
    result = subprocess.run(
        [sys.executable, str(script), '127.0.0.1', '--port', str(port),
         '--seconds', '0.12', '--output', str(output), '--summary', str(summary), *options],
        capture_output=True, text=True, timeout=5,
    )
    thread.join(timeout=2)
    return result.returncode, json.loads(summary.read_text(encoding='utf-8'))

def run_with_default_paths(payload, directory):
    port, thread = serve(payload)
    script = Path(__file__).resolve().parents[1] / 'probe_klogsrv.py'
    result = subprocess.run(
        [sys.executable, str(script), '127.0.0.1', '--port', str(port), '--seconds', '0.12'],
        cwd=directory, capture_output=True, text=True, timeout=5,
    )
    thread.join(timeout=2)
    assert result.returncode == 0, result.stderr

with tempfile.TemporaryDirectory() as d:
    out=Path(d)/'capture.bin'
    sock = MagicMock()
    def select_at_deadline(readable, writable, failed, timeout):
        assert timeout >= 0, timeout
        return [], [], []

    with (patch('probe_klogsrv.socket.create_connection', return_value=sock),
          patch('probe_klogsrv.time.monotonic', side_effect=[10.0, 10.0, 10.05, 10.11, 10.12]),
          patch('probe_klogsrv.select.select', side_effect=select_at_deadline)):
        result = capture('127.0.0.1', 3232, seconds=0.1, output=out)
        assert result['state'] == 'CONNECTED_SILENT'

    p,t=serve(b'hello kernel\nDEVICE_ADDED test\n',hold_sec=0.25)
    s=capture('127.0.0.1',p,seconds=0.08,output=out)
    assert s['state']=='BYTES_RECEIVED',s
    assert s['bytes']==len(b'hello kernel\nDEVICE_ADDED test\n')
    assert s['newlines']==2
    assert out.read_bytes()==b'hello kernel\nDEVICE_ADDED test\n'
    t.join()

    p,t=serve(b'',hold_sec=0.3)
    s=capture('127.0.0.1',p,seconds=0.07,output=out)
    assert s['state']=='CONNECTED_SILENT',s
    assert s['bytes']==0
    t.join()

    p,t=serve(b'')
    s=capture('127.0.0.1',p,seconds=0.15,output=out)
    assert s['state']=='EOF_NO_BYTES',s
    t.join()

    code, report = run_cli(b'', 0.5, out)
    assert code == 3 and report['state'] == 'CONNECTED_SILENT', (code, report)
    code, report = run_cli(b'', 0, out)
    assert code == 3 and report['state'] == 'EOF_NO_BYTES', (code, report)
    code, report = run_cli(b'kernel data\n', 0, out)
    assert code == 0 and report['state'] == 'BYTES_RECEIVED', (code, report)
    code, report = run_cli(b'unrelated\nGH5_KLOG_CHECK abc 1/3\n', 0, out,
                           '--expect-text', 'GH5_KLOG_CHECK')
    assert code == 0 and report['expected_text_matches'] == 1, (code, report)
    assert report['expected_text_lines'] == ['GH5_KLOG_CHECK abc 1/3'], report
    previous = b'GH5_KLOG_CHECK old 3/3\n'
    current = [f'GH5_KLOG_CHECK current {index}/3' for index in range(1, 4)]
    payload = previous + ('\n'.join(current) + '\n').encode()
    code, report = run_cli(payload, 0, out, '--expect-text', 'GH5_KLOG_CHECK')
    assert code == 0 and report['expected_text_matches'] == 4, (code, report)
    assert report['expected_text_lines'] == current, report
    code, report = run_cli(b'unrelated transport\n', 0, out,
                           '--expect-text', 'GH5_KLOG_CHECK')
    assert code == 4 and report['expected_text_matches'] == 0, (code, report)
    code, report = run_cli(b'', 0.5, out, '--expect-text', 'GH5_KLOG_CHECK')
    assert code == 3 and report['expected_text_matches'] == 0, (code, report)

    script = Path(__file__).resolve().parents[1] / 'probe_klogsrv.py'
    out.write_bytes(b'keep existing capture')
    conflict = subprocess.run(
        [sys.executable, str(script), '127.0.0.1', '--port', '1', '--seconds', '0.1',
         '--output', str(out), '--summary', str(out)],
        capture_output=True, text=True, timeout=5,
    )
    assert conflict.returncode == 2 and 'different files' in conflict.stderr, conflict
    assert out.read_bytes() == b'keep existing capture'

    run_with_default_paths(b'first capture\n', d)
    run_with_default_paths(b'second capture\n', d)
    summaries = list((Path(d) / 'klogsrv-captures').glob('*/klogsrv-summary.json'))
    assert len(summaries) == 2, summaries
    captures = {summary.with_name('klogsrv-capture.bin').read_bytes()
                for summary in summaries}
    assert captures == {b'first capture\n', b'second capture\n'}, captures
    for summary in summaries:
        report = json.loads(summary.read_text(encoding='utf-8'))
        assert Path(report['capture_file']) == summary.with_name('klogsrv-capture.bin')

print('PASS probe_klogsrv: data, silent, EOF, exit status and capture history')
