# Diagnóstico da porta 3232

O teste é **somente leitura**: abre TCP 3232 do PS5, recebe bytes e grava evidências no computador; não envia comandos ao console e não tenta criar/destruir controle virtual.

Com o serviço de logs ativo e o GhostControl encerrado, abra o PowerShell na pasta do projeto. Inicie a captura no PC:

```powershell
python tools/diagnostics/probe_klogsrv.py IP_DO_PS5 --seconds 30 --expect-text GH5_KLOG_CHECK
```

No Linux e macOS, use `python3` no mesmo comando. Substitua `IP_DO_PS5` pelo endereço LAN do console.

Enquanto o PC estiver capturando, execute `GhosttoothAPI/GhostControl-Klog-Check.elf` no gerenciador do PS5. O teste chama a API de log três vezes e mostra `GH5 log check`, o identificador da execução e os três retornos `SDK rc` na tela. A captura gravará o binário e o JSON em uma pasta nova dentro de `klogsrv-captures`. Compare o identificador da notificação com as três linhas correspondentes mais recentes em `expected_text_lines`.

- `expected_text_matches` maior que zero e identificador igual ao da notificação confirmam que o log chegou ao PC. Encerre a captura antes de repetir um teste de VDA com o ELF principal.
- `CONNECTED_SILENT` e três retornos `0` na notificação registram uma chamada aceita pela API e um fluxo silencioso durante o teste. Guarde os dois resultados.
- `BYTES_RECEIVED` com zero ocorrências indica tráfego sem a mensagem esperada. Compare o momento da captura com a notificação. O código de saída é 4 quando `--expect-text` está ativo.
- `EOF_NO_BYTES` indica que a conexão fechou sem tráfego. `CONNECT_FAILED` indica falha ao abrir a conexão.

Com o SDK Prospero configurado, o alvo `make -C GhosttoothAPI klog-check` recompila somente esse ELF.
