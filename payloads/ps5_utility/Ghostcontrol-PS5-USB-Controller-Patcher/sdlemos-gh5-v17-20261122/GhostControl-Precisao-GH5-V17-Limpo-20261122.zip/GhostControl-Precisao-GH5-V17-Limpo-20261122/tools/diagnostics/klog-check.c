/* SPDX-License-Identifier: GPL-3.0-or-later */
#include <ps5/klog.h>
#include <stdio.h>
#include <time.h>
#include <unistd.h>

#include "gc_notify.h"

int main(void)
{
    char run_id[64], message[128], summary[180];
    int result[3];

    snprintf(run_id, sizeof run_id, "%lx-%ld", (unsigned long)time(NULL), (long)getpid());
    for (unsigned index = 0; index < 3; ++index) {
        snprintf(message, sizeof message, "GH5_KLOG_CHECK %s %u/3", run_id, index + 1);
        result[index] = klog_puts(message);
        if (index < 2) sleep(1);
    }
    /* Keep the notification distinct from kernel-log test messages. */
    snprintf(summary, sizeof summary, "GH5 log check %s | SDK rc %d/%d/%d",
             run_id, result[0], result[1], result[2]);
    puts(summary);
    gc_notify_send(summary);
    return result[0] && result[1] && result[2] ? 1 : 0;
}
