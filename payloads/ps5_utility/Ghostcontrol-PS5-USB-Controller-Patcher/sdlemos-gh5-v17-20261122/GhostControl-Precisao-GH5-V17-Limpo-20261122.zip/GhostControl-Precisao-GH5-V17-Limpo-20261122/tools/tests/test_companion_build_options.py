#!/usr/bin/env python3
"""Exercise GhosttoothAPI Makefile option parsing without the console SDK."""
import os
from pathlib import Path
import subprocess
import tempfile
import unittest


ROOT = Path(__file__).resolve().parents[2]


class CompanionBuildOptions(unittest.TestCase):
    def setUp(self):
        sdk = tempfile.TemporaryDirectory()
        self.addCleanup(sdk.cleanup)
        self.environment = {
            key: value for key, value in os.environ.items()
            if key not in {"PS5_PAYLOAD_SDK", "VARIANT", "RUMBLE_READBACK",
                           "MAKEFLAGS", "MFLAGS", "MAKEOVERRIDES"}
        }
        toolchain = Path(sdk.name) / "toolchain"
        toolchain.mkdir()
        (toolchain / "prospero.mk").touch()
        self.sdk = sdk.name

    def make(self, *args):
        return subprocess.run(
            ["make", "--no-print-directory", "-n", "-C",
             str(ROOT / "GhosttoothAPI"), *args],
            capture_output=True, env=self.environment, text=True,
        )

    def test_rejects_invalid_selector_values(self):
        bad_options = (
            ("VARIANT=", "VARIANT must be"),
            ("VARIANT=resident typo", "VARIANT must be"),
            ("VARIANT=resident diagnostic", "VARIANT must be"),
            ("VARIANT=%", "VARIANT must be"),
            ("RUMBLE_READBACK=", "RUMBLE_READBACK must be"),
            ("RUMBLE_READBACK=0 1", "RUMBLE_READBACK must be"),
            ("RUMBLE_READBACK=2", "RUMBLE_READBACK must be"),
        )
        for value, message in bad_options:
            with self.subTest(value=value):
                result = self.make(f"PS5_PAYLOAD_SDK={self.sdk}", value, "clean")
                self.assertNotEqual(result.returncode, 0, result.stdout)
                self.assertIn(message, result.stderr)

    def test_accepts_build_selector_values(self):
        result = self.make(f"PS5_PAYLOAD_SDK={self.sdk}", "VARIANT=gh5-precision",
                           "RUMBLE_READBACK=1", "clean")
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertIn("GhosttoothAPI-GH5-precision.elf", result.stdout)

    def test_host_routing_needs_no_sdk(self):
        result = self.make("host-routing-test")
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertIn("bash ../run_host_tests.sh", result.stdout)


if __name__ == "__main__":
    unittest.main()
