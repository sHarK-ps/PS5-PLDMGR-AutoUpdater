#!/usr/bin/env python3
"""Host regression checks for PR #29/#32/#33 integration."""
from pathlib import Path
import re, shutil, subprocess, tempfile, unittest
ROOT = Path(__file__).resolve().parents[2]
SRC = ROOT / "core/src"

def extract_function(source: str, name: str) -> str:
    pattern = r"(?:static\s+)?(?:uint64_t|int)\s+" + re.escape(name) + r"\s*\([^;]*?\)\s*\{"
    match = re.search(pattern, source, re.S)
    if not match: raise AssertionError(f"function {name} not found")
    start = source.find("{", match.start()); depth = 0
    for pos in range(start, len(source)):
        if source[pos] == "{": depth += 1
        elif source[pos] == "}":
            depth -= 1
            if depth == 0: return source[match.start():pos+1]
    raise AssertionError(f"unterminated function {name}")

class TestPR29RumbleAndCrossPR(unittest.TestCase):
    def test_rumble_and_remoteplay_transport_gate(self):
        game=(SRC/"gc_ds4_game.c").read_text(); stub=(SRC/"gc_ds4_game_stub.c").read_text()
        source=(SRC/"gc_ds4_source.c").read_text(); bridge=(SRC/"gc_ds4_bridge.c").read_text()
        header=(SRC/"gc_ds4_game.h").read_text()
        self.assertIn("GC_DS4_GAME_LIBPAD_SYMBOLS 7u",header)
        self.assertIn('"scePadSetVibration"',game)
        self.assertIn("gc_ds4_game_set_vibration_stub",stub)
        self.assertIn("gc_ds4_source_set_vibration",source)
        self.assertIn('"scePadSetVibrationMode"',source)
        self.assertIn("forward_game_rumble",bridge)
        self.assertIn("remove_game_bridge",bridge)
        self.assertIn("gc_ds4_source_set_vibration(&source, route, 0, 0)",bridge)
        self.assertRegex(source,r"connection_type\s*==\s*2")
        self.assertIn("info[10] == 2", source)
        self.assertIn("fp_controller_info", source)
        self.assertIn("retry_after[route]", bridge)
        self.assertIn("100000000", bridge)
        self.assertIn("game.rumble_sequences[route] = sequence;", bridge)

class TestPR32USBControllerFixes(unittest.TestCase):
    def test_pr32_mechanisms_present(self):
        inject=(SRC/"gc_service_inject.c").read_text(); ds3=(SRC/"controller_ds3.c").read_text()
        xbox=(SRC/"controller_xbox.c").read_text(); service=(SRC/"gc_main.c").read_text()
        ds4=(SRC/"controller_ds4.c").read_text(); update=(SRC/"gc_update.c").read_text()
        self.assertIn("max_packet_length",inject)
        self.assertIn("HID_BMRT_DEV_TO_HOST_IFACE  0xA1u",ds3)
        self.assertIn("HID_GET_REPORT              0x01u",ds3)
        self.assertIn("reply_nonzero",inject)
        self.assertIn("GIP_HANDSHAKE_TOTAL_MS",xbox)
        self.assertIn("controller_ds3",service)
        self.assertTrue("lightbar" in ds4.lower() or "lightbar" in inject.lower())
        self.assertIn("GC_UPDATE_API",update)

class TestPR33PersistenceAndInquiry(unittest.TestCase):
    def test_forget_result_is_propagated(self):
        host=(SRC/"bt/host.c").read_text(); header=(SRC/"bt/host_int.h").read_text()
        self.assertRegex(header,r"int\s+db_forget\(")
        body=extract_function(host,"db_forget")
        self.assertIn("if (!db_save(h))",body); self.assertIn("return 0;",body); self.assertIn("return 1;",body)
        self.assertIn("if (!db_forget(h, addr))",host)
        self.assertIn("persistent forget failed",host)
        self.assertIn("replacement aborted; old bond could not be durably forgotten",host)
    def test_inquiry_backoff_bounds_and_success_reset(self):
        host=(SRC/"bt/host.c").read_text(); header=(SRC/"bt/host_int.h").read_text()
        self.assertIn("#define T_INQUIRY_RETRY     500",header)
        self.assertIn("#define T_INQUIRY_RETRY_MAX 8000",header)
        self.assertIn("bs->inquiry_backoff = bs->inquiry_backoff ? bs->inquiry_backoff * 2 : T_INQUIRY_RETRY",host)
        self.assertIn("if (ev[2] == 0) ((host_storage *)h)->inquiry_backoff = 0;",host)

if __name__ == "__main__": unittest.main(verbosity=2)
