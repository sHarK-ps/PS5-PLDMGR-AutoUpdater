#!/usr/bin/env python3
"""Ensure native companion notices cannot replace packaged artifact files."""
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest


ROOT = Path(__file__).resolve().parents[2]
TOOL = ROOT / "tools/companion-manifest.py"
ARTIFACT = "GhosttoothAPI.elf"
MANIFEST = "GhosttoothAPI.manifest.json"


class ManifestNoticeNames(unittest.TestCase):
    def setUp(self):
        directory = tempfile.TemporaryDirectory()
        self.addCleanup(directory.cleanup)
        self.root = Path(directory.name)
        self.output = self.root / "output"
        self.output.mkdir()
        self.elf = self.output / ARTIFACT
        elf_header = bytearray(120)
        elf_header[:6] = b"\x7fELF\x02\x01"
        elf_header[18:20] = (62).to_bytes(2, "little")
        elf_header[32:40] = (64).to_bytes(8, "little")
        elf_header[54:56] = (56).to_bytes(2, "little")
        elf_header[56:58] = (1).to_bytes(2, "little")
        self.payload = bytes(elf_header)
        self.elf.write_bytes(self.payload)

    def notice(self, directory, name):
        document = self.root / directory / name
        document.parent.mkdir(exist_ok=True)
        document.write_text("Test notice", encoding="utf-8")
        return document

    def generate(self, *notices):
        args = [sys.executable, "-B", str(TOOL), "generate",
                "--elf", str(self.elf), "--source-root", str(ROOT)]
        for notice in notices:
            args.extend(("--notice", str(notice)))
        return subprocess.run(args, capture_output=True, text=True)

    def test_refuses_reserved_names_before_copying(self):
        valid = self.notice("valid", "NOTICE.txt")
        for name in (ARTIFACT, MANIFEST, ARTIFACT.upper(), MANIFEST.upper()):
            with self.subTest(name=name):
                old_manifest = self.output / MANIFEST
                old_manifest.write_text("previous manifest", encoding="utf-8")
                self.elf.write_bytes(self.payload)
                result = self.generate(valid, self.notice("collision", name))
                self.assertNotEqual(result.returncode, 0, result.stdout)
                self.assertIn("reserved notice name", result.stderr)
                self.assertEqual(self.elf.read_bytes(), self.payload)
                self.assertEqual(old_manifest.read_text(encoding="utf-8"), "previous manifest")
                self.assertFalse((self.output / valid.name).exists())

    def test_refuses_duplicate_destination_before_copying(self):
        first = self.notice("first", "NOTICE.txt")
        second = self.notice("second", "notice.txt")
        result = self.generate(first, second)
        self.assertNotEqual(result.returncode, 0, result.stdout)
        self.assertIn("duplicate notice name", result.stderr)
        self.assertFalse((self.output / first.name).exists())

    def test_writes_a_valid_manifest_and_notice(self):
        valid = self.notice("valid", "NOTICE.txt")
        result = self.generate(valid)
        self.assertEqual(result.returncode, 0, result.stderr)
        manifest = json.loads((self.output / MANIFEST).read_text(encoding="utf-8"))
        self.assertEqual(manifest["notices"], [valid.name])
        self.assertEqual((self.output / valid.name).read_bytes(), valid.read_bytes())
        self.assertEqual(self.elf.read_bytes(), self.payload)

    def test_verify_refuses_artifact_as_a_notice(self):
        self.assertEqual(self.generate().returncode, 0)
        manifest_path = self.output / MANIFEST
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        manifest["notices"] = [ARTIFACT]
        manifest_path.write_text(json.dumps(manifest), encoding="utf-8")
        result = subprocess.run(
            [sys.executable, "-B", str(TOOL), "verify", "--dir", str(self.output)],
            capture_output=True, text=True,
        )
        self.assertNotEqual(result.returncode, 0, result.stdout)
        self.assertIn("reserved notice name", result.stderr)


if __name__ == "__main__":
    unittest.main()
