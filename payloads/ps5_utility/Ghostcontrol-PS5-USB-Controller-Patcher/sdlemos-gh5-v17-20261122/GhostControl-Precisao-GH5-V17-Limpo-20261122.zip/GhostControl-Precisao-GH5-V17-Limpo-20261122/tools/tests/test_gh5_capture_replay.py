#!/usr/bin/env python3
"""Replay 130 distinct 27-byte GH5 HID reports with production decoder.
Fixture derived from user-supplied 14 Nov 2026 test.zip; no action labels.
"""
from pathlib import Path
import json,subprocess,tempfile
root=Path(__file__).resolve().parents[2]
f=root/'tools/tests/fixtures'
capture=json.loads((f/'gh5-hid-20261114.json').read_text())
reference=json.loads((f/'gh5-hid.json').read_text())
reports=[bytes.fromhex(r['hex']) for c in capture['captures'] for r in c['reports']]
assert len(reports)==130 and [len(c['reports']) for c in capture['captures']]==[49,81]
assert all(len(r)==27 for r in reports)
bytes_c=lambda bs: '{'+','.join(str(x) for x in bs)+'}'
header='static const uint8_t descriptor[] = '+bytes_c(bytes.fromhex(reference['descriptor']))+';\n'
header+='static const uint8_t baseline[][27] = {\n'+',\n'.join(map(bytes_c,reports))+'};\n'
code=r'''
#include <assert.h>
#include <stdint.h>
#include <string.h>
#include "gc_hid.h"
ARRAYS
int main(void) {
    GcHidLayout l;
    assert(!gc_hid_parse_descriptor(descriptor,sizeof descriptor,&l));
    assert(l.count==18 && l.raw_count==16 && !l.numbered);
    gc_hid_set_device(&l,0x12ba,0x0100);
    assert(l.ps3_gh_guitar);
    const uint32_t masks[]={SCE_PAD_BUTTON_SQUARE,SCE_PAD_BUTTON_CROSS,
        SCE_PAD_BUTTON_CIRCLE,SCE_PAD_BUTTON_TRIANGLE,SCE_PAD_BUTTON_L1,SCE_PAD_BUTTON_R1};
    const uint32_t fret_mask=SCE_PAD_BUTTON_SQUARE|SCE_PAD_BUTTON_CROSS|
        SCE_PAD_BUTTON_CIRCLE|SCE_PAD_BUTTON_TRIANGLE|SCE_PAD_BUTTON_L1|SCE_PAD_BUTTON_R1;
    ScePadData pad={0};
    for(unsigned i=0;i<sizeof baseline/sizeof baseline[0];++i) {
        assert(gc_hid_input(&l,baseline[i],sizeof baseline[i],&pad));
        uint32_t expected=0;
        for(unsigned bit=0;bit<6;++bit)
            if(baseline[i][0] & (1u<<bit)) expected |= masks[bit];
        assert((pad.buttons & fret_mask)==expected);
        ScePadData saved=pad;
        assert(!gc_hid_input(&l,baseline[i],3,&pad));
        assert(!memcmp(&saved,&pad,sizeof pad));
        uint8_t released[27];memcpy(released,baseline[i],27);
        released[0]=0;released[1]=0;released[2]=0x0f;
        assert(gc_hid_input(&l,released,sizeof released,&pad));
        assert(!(pad.buttons&fret_mask));
    }
    uint8_t pkt[27]={0};pkt[2]=0x0f;
    for(unsigned bit=0;bit<6;++bit) {
        pkt[0]=1u<<bit;
        assert(gc_hid_input(&l,pkt,27,&pad) && (pad.buttons&fret_mask)==masks[bit]);
        pkt[0]=0;assert(gc_hid_input(&l,pkt,27,&pad)&& !(pad.buttons&fret_mask));
    }
    /* HID usages remain intact and unrelated devices retain ordinary mapping. */
    assert(l.fields[0].usage==1);
    gc_hid_set_device(&l,0x12ba,0x0200);
    assert(!l.ps3_gh_guitar);
    pkt[0]=1;assert(gc_hid_input(&l,pkt,27,&pad));
    assert((pad.buttons&fret_mask)==SCE_PAD_BUTTON_CROSS);
    return 0;
}
'''.replace('ARRAYS',header)
with tempfile.TemporaryDirectory(prefix='ghostcontrol-gh5-replay-r5-') as t:
    path=Path(t);(path/'test.c').write_text(code)
    subprocess.run(['cc','-std=c11','-Wall','-Wextra','-Werror','-ffunction-sections','-fdata-sections',
        '-I'+str(root/'core/src'),str(path/'test.c'),str(root/'core/src/gc_hid.c'),
        str(root/'core/src/gc_profile.c'),'-Wl,--gc-sections','-lm','-o',str(path/'test')],check=True)
    subprocess.run([str(path/'test')],check=True)
print('PASS: production HID parser 130 GH5 captured reports; default fret mapping, release and truncation; no physical action claim')
