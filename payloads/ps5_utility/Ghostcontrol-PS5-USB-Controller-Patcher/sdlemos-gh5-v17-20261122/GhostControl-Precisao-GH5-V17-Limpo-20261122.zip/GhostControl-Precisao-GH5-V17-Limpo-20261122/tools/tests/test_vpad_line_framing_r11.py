#!/usr/bin/env python3
"""R11 regression: extract and execute actual GH5 vpad production code on a host.
Not a console/PS5 test. The test must fail against R10 sources.
"""
import pathlib,subprocess,tempfile,sys
src=pathlib.Path(__file__).resolve().parents[2]/'core'/'src'/'bt'/'ps5_vpad.c'
s=src.read_text(encoding='utf-8')

start=s.index('static int vpad_id_field_end(')
end=s.index('/* ---- users and privileges')
block=s[start:end]
c=r"""
#define _DEFAULT_SOURCE 1
#include <sys/socket.h>
#include <sys/types.h>
#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>
#include <errno.h>
#include <ctype.h>
#include <string.h>
#include <fcntl.h>
#include <stdarg.h>
#include <unistd.h>
#include <assert.h>
#define LINE_MAX_LEN 1024
static int g_log_fd=-1,g_log_is_dev=0,g_pending=0,g_matches=0;
static uint64_t g_log_bytes=0,g_log_lines=0,g_log_device_added=0,g_log_mbus_events=0;
static uint64_t g_match_dev=0;
static long g_t_match=0,g_log_first_byte_ms=-1,g_log_last_byte_ms=-1;
static int g_log_eof=0,g_log_read_errno=0;
static char g_line[LINE_MAX_LEN];
static size_t g_line_len=0;
static int g_line_overflow=0;
static uint64_t g_line_dropped=0;
static long now_ms(void){return 1000;}
static void log_line(const char *fmt,...){(void)fmt;}
SUBJECT
static void setup(int fd){
 g_log_fd=fd;
 int flags=fcntl(fd,F_GETFL);assert(flags>=0);
 assert(fcntl(fd,F_SETFL,flags|O_NONBLOCK)==0);
 g_pending=0;g_matches=0;g_log_bytes=0;g_log_lines=0;g_log_device_added=0;
 g_log_mbus_events=0;g_log_eof=0;g_log_read_errno=0;g_log_first_byte_ms=-1;
 g_line_len=0;g_line_overflow=0;g_line_dropped=0;g_match_dev=0;
}
static void check_short(void){
 int p[2];assert(socketpair(AF_UNIX,SOCK_STREAM,0,p)==0);setup(p[1]);
 const char *a="DEVICE_ADDED deviceId=0x1234 deviceType=22 userId=0";
 assert(write(p[0],a,strlen(a))==(ssize_t)strlen(a));
 assert(log_source_read()==1);
 assert(g_matches==0 && g_log_lines==0);
 assert(write(p[0],"\n",1)==1);
 assert(log_source_read()==1);
 assert(g_matches==1 && g_log_lines==1);
 close(p[0]);close(p[1]);
}
static void check_overlong(void){
 int p[2];assert(socketpair(AF_UNIX,SOCK_STREAM,0,p)==0);setup(p[1]);
 char large[1400];const char *prefix="DEVICE_ADDED deviceId=0x2345 deviceType=22 ";
 memset(large,'X',sizeof large);memcpy(large,prefix,strlen(prefix));
 assert(write(p[0],large,sizeof large)==(ssize_t)sizeof large);
 assert(log_source_read()==1);
 /* Not a physical line before newline. */
 assert(g_matches==0 && g_log_lines==0);
 assert(write(p[0],"\n",1)==1);
 assert(log_source_read()==1);
 /* Oversized line must be discarded entirely, never accepted as candidate. */
 assert(g_matches==0 && g_log_lines==0 && g_line_dropped==1);
 close(p[0]);close(p[1]);
}
static void check_binary_line(void) {
 int p[2];assert(socketpair(AF_UNIX,SOCK_STREAM,0,p)==0);setup(p[1]);
 const char input[]="DEVICE_ADDED deviceId=0x1234 deviceType=22\0discard\n"
                    "DEVICE_ADDED deviceId=0x2345 deviceType=22\n";
 assert(write(p[0],input,sizeof input-1)==sizeof input-1);
 assert(log_source_read()==1);
 assert(g_matches==1 && g_match_dev==0x2345 && g_log_lines==1);
 close(p[0]);close(p[1]);
}
int main(void){check_short();check_overlong();check_binary_line();puts("MBus framing regressions PASS");return 0;}
""".replace('SUBJECT',block)
with tempfile.TemporaryDirectory() as d:
 f=pathlib.Path(d)/'test.c';f.write_text(c)
 exe=pathlib.Path(d)/'test'
 a=subprocess.run(['cc','-std=c11','-D_DEFAULT_SOURCE','-Wall','-Wextra','-Wshadow','-Werror',str(f),'-o',str(exe)],capture_output=True,text=True)
 if a.returncode: print(a.stderr);sys.exit(a.returncode)
 b=subprocess.run([str(exe)],capture_output=True,text=True)
 print(b.stdout,b.stderr,sep='')
 sys.exit(b.returncode)
