#!/usr/bin/env python3
"""Regression against extracted production Precision RAW sampler, not a mock algorithm.
Ensures a frame missed under a 24/sec logging budget can be reported later when
it remains stable. Does not imply lost USB traffic.
"""
from pathlib import Path
import subprocess,tempfile
root=Path(__file__).resolve().parents[2]
source=(root/'core/src/gc_service_inject.c').read_text()
start=source.index('static void gh5_trace_report(UsbFeed')
end=source.index('\n#endif',start)
function=source[start:end]
harness=r'''
#include <assert.h>
#include <stdint.h>
#include <stddef.h>
#include <stdarg.h>
#include <string.h>
#include <stdio.h>
#define USB_REPORT 64
typedef struct {int kind,interface_index,interface_number;} GcUsbDevice;
typedef struct {
    uint64_t trace_generation;
    uint8_t trace_raw_prev[2][USB_REPORT];
    size_t trace_raw_prev_len[2];
    uint64_t trace_raw_seen[2],trace_raw_logged[2],trace_raw_dropped[2],trace_raw_drop_total[2];
    uint64_t trace_raw_bucket_sec[2];
    unsigned trace_raw_bucket_count[2];
    int slot; char path[40]; unsigned in_ep;
} UsbFeed;
static uint64_t fake_time;
static int real_rows;
static uint64_t gc_fallback_now_ms(void) { return fake_time; }
static void log_line(const char *fmt,...) {
    if(strstr(fmt,"gh5: RAW source="))++real_rows;
}
FUNCTION
int main(void){
    UsbFeed f={0}; GcUsbDevice d={0};uint8_t buf[27]={0};
    f.trace_generation=1;f.in_ep=0x81; f.slot=0;
    fake_time=20000;
    for(int i=0;i<24;i++) {buf[0]=(uint8_t)i;gh5_trace_report(&f,&d,buf,27,0);}
    assert(real_rows==24 && f.trace_raw_logged[0]==24);
    buf[0]=123;gh5_trace_report(&f,&d,buf,27,0);
    assert(real_rows==24 && f.trace_raw_drop_total[0]==1);
    /* No USB state change, only one second later: MUST now log held 123. */
    fake_time=21000;gh5_trace_report(&f,&d,buf,27,0);
    assert(real_rows==25 && f.trace_raw_prev[0][0]==123);
    gh5_trace_report(&f,&d,buf,27,0);assert(real_rows==25);
    /* Independent control stream with its own 3/sec limit. */
    for(int i=0;i<3;i++){buf[0]=(uint8_t)(i+1);gh5_trace_report(&f,&d,buf,27,1);}
    assert(f.trace_raw_logged[1]==3);
    return 0;
}
'''.replace('FUNCTION',function)
with tempfile.TemporaryDirectory(prefix='gh5-precision-sampler-') as t:
    p=Path(t);(p/'test.c').write_text(harness)
    subprocess.run(['cc','-std=c11','-Wall','-Wextra','-Werror',str(p/'test.c'),'-o',str(p/'test')],check=True)
    subprocess.run([str(p/'test')],check=True)
print('PASS: production precision sampler preserves dropped-but-stable transitions across rate-limit buckets')
