#!/usr/bin/env python3
"""Run product-source GH5 mapping/progress/cancel tests with host stubs.
No console SDK, no ELF build, no PS5 runtime validation.
"""
from pathlib import Path
import os, subprocess, shlex, tempfile
ROOT=Path(__file__).resolve().parents[2]
CC=shlex.split(os.environ.get('CC','cc'))

hid_harness=r'''
#include "gc_hid.h"
#include "gc_types.h"
#include <assert.h>
#include <string.h>
uint32_t gc_button_mask(GcButton button) {
    switch (button) {
    case GC_BUTTON_CROSS: return SCE_PAD_BUTTON_CROSS;
    case GC_BUTTON_CIRCLE: return SCE_PAD_BUTTON_CIRCLE;
    case GC_BUTTON_SQUARE: return SCE_PAD_BUTTON_SQUARE;
    case GC_BUTTON_TRIANGLE: return SCE_PAD_BUTTON_TRIANGLE;
    default: return 0;
    }
}
static void configure(GcHidLayout *l,int raw) {
    memset(l,0,sizeof *l);
    l->count=raw?0:3;
    l->raw_count=raw?3:0;
    for (unsigned i=0;i<3;++i) {
        GcHidField *f=raw?&l->raw_fields[i]:&l->fields[i];
        f->offset=i;f->bits=1;f->minimum=0;f->maximum=1;
        f->page=9;f->usage=i+1;
    }
}
int main(void){
    for (int raw=0;raw<=1;++raw){
        GcHidLayout l; ScePadData pad={0};
        uint8_t packet[]={0x01};
        configure(&l,raw);gc_hid_set_device(&l,0x12ba,0x0100);
        assert(l.ps3_gh_guitar);
        assert(gc_hid_input(&l,packet,1,&pad)); assert(pad.buttons==SCE_PAD_BUTTON_SQUARE);
        packet[0]=0x02; assert(gc_hid_input(&l,packet,1,&pad));assert(pad.buttons==SCE_PAD_BUTTON_CROSS);
        packet[0]=0x04; assert(gc_hid_input(&l,packet,1,&pad));assert(pad.buttons==SCE_PAD_BUTTON_CIRCLE);
        packet[0]=0x07; assert(gc_hid_input(&l,packet,1,&pad));
        assert(pad.buttons==(SCE_PAD_BUTTON_SQUARE|SCE_PAD_BUTTON_CROSS|SCE_PAD_BUTTON_CIRCLE));
        packet[0]=0; assert(gc_hid_input(&l,packet,1,&pad)); assert(pad.buttons==0);
        memset(&pad,0,sizeof pad); gc_hid_set_device(&l,0x054c,0x0268);
        assert(!l.ps3_gh_guitar);packet[0]=1;
        assert(gc_hid_input(&l,packet,1,&pad)); assert(pad.buttons==SCE_PAD_BUTTON_CROSS);
    }
    return 0;
}
'''
progress_harness=r'''
#include "gc_usb_progress.h"
#include <assert.h>
#include <string.h>
int main(void){
    GcUsbProgress p={0};p.generation=2;p.opened_ms=100;
    assert(gc_usb_progress_due(&p,100));assert(!gc_usb_progress_due(&p,1099));
    assert(gc_usb_progress_due(&p,1100));
    gc_usb_progress_start(&p,1100);assert(!gc_usb_progress_suspect(&p,1500));
    assert(gc_usb_progress_suspect(&p,2100));
    gc_usb_progress_complete(&p,2118);gc_usb_progress_input(&p,2118);
    assert(!gc_usb_progress_suspect(&p,2118));
    assert(p.starts==1&&p.completions==1&&p.inputs==1&& !p.outstanding);
    assert(gc_usb_progress_age(50,100)==0); /* clock-backward guard */
    memset(&p,0,sizeof p);p.generation=3;p.opened_ms=5000;
    assert(p.starts==0&&!p.have_completion&&!p.have_input);
    return 0;
}
'''


def extract_function(text,signature,start_pos=0):
    begin=text.index(signature,start_pos)
    brace=text.index('{',begin)
    depth=0
    for i in range(brace,len(text)):
        depth += (text[i]=='{')-(text[i]=='}')
        if not depth: return text[begin:i+1]
    raise RuntimeError('unterminated '+signature)

host_src=(ROOT/'core/src/bt/host.c').read_text()
a=host_src.index('typedef struct {');b=host_src.index('} host_storage;',a)+len('} host_storage;')
layout=host_src[a:b]
# Get the function definition, not the forward prototype.
fn=extract_function(host_src,'static void cancel_inquiry(host_t *h)\n{')
cancel_harness=r'''
#include "host_int.h"
#include "util.h"
#include <assert.h>
LAYOUT
static long test_time;
static unsigned test_sends;
long now_ms(void){return test_time;}
int send_cmd(host_t *h,unsigned op,const void *data,int size){
    (void)h;(void)op;(void)data;(void)size;++test_sends;return 0;
}
FUNCTION
int main(void){
    host_storage store={0};host_t *h=&store.host;
    test_time=1000;h->inquiring=1;cancel_inquiry(h);assert(test_sends==1);
    for(test_time=1001;test_time<1500;test_time+=10)cancel_inquiry(h);
    assert(test_sends==1);
    test_time=1500;cancel_inquiry(h);assert(test_sends==2);
    test_time=1501;cancel_inquiry(h);assert(test_sends==2);
    assert(h->inquiring);
    return 0;
}
'''.replace('LAYOUT',layout).replace('FUNCTION',fn)

with tempfile.TemporaryDirectory(prefix='gh5-review-tests-') as t:
    t=Path(t)
    for n,code,sources,include in [
        ('hid',hid_harness,[ROOT/'core/src/gc_hid.c'],ROOT/'core/src'),
        ('progress',progress_harness,[],ROOT/'core/src'),
        ('inquiry-cancel',cancel_harness,[],ROOT/'core/src/bt')]:
        (t/f'{n}.c').write_text(code)
        cmd=CC+['-std=c11','-D_DEFAULT_SOURCE','-Wall','-Wextra','-Werror',f'-I{include}',str(t/f'{n}.c')]+[str(p) for p in sources]+['-o',str(t/n)]
        subprocess.run(cmd,check=True)
        subprocess.run([str(t/n)],check=True)
        print(f'PASS {n}: production-source behavioral host regression')
