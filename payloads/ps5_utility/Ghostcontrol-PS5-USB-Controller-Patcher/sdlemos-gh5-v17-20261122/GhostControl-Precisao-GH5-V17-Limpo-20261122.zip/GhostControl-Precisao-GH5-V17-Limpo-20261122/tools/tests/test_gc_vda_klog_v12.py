#!/usr/bin/env python3
"""V12: compile the ACTUAL native gc_vda_klog.c against malformed and valid MBus lines."""
from pathlib import Path
import subprocess, tempfile
root=Path(__file__).resolve().parents[2]
code=r'''
#include <assert.h>
#include <stdint.h>
#include "gc_vda_klog.h"
int main(void){
    GcVdaKlogEvent ev;
    assert(gc_vda_klog_parse("DEVICE_ADDED DeviceId:0x1234 type:1 subType:22 capabilityBattery:0",&ev)==1);
    assert(ev.type==GC_VDA_KLOG_ADDED && ev.device_id==0x1234);
    assert(gc_vda_klog_parse("event=DEVICE_ADDED deviceId=0x1f030d deviceType=22 userId=0x0(0)",&ev)==1);
    assert(ev.type==GC_VDA_KLOG_ADDED && ev.device_id==0x1f030d);
    assert(gc_vda_klog_parse("DEVICE_ADDED DeviceId:0x1234junk type:1 subType:22 capabilityBattery:0",&ev)==0);
    assert(gc_vda_klog_parse("DEVICE_ADDED DeviceId:0x1234 type:1 subType:220 capabilityBattery:0",&ev)==0);
    assert(gc_vda_klog_parse("DEVICE_ADDED DeviceId:0x1234 type:1 subType:22 capabilityBattery:0bad",&ev)==0);
    assert(gc_vda_klog_parse("DEVICE_ADDED deviceId=0x1234junk deviceType=22",&ev)==0);
    assert(gc_vda_klog_parse("DEVICE_ADDED deviceId=0x1234 deviceType=22junk",&ev)==0);
    assert(gc_vda_klog_parse("DEVICE_ADDED deviceId=0x12345678912345678 deviceType=22",&ev)==0);
    assert(gc_vda_klog_parse("DEVICE_REMOVED deviceId=0x1234 deviceType=22",&ev)==0);
    assert(gc_vda_klog_parse("NOT_DEVICE_ADDED deviceId=0x1234 deviceType=22",&ev)==0);
    assert(gc_vda_klog_parse("DEVICE_ADDED_EXTRA deviceId=0x1234 deviceType=22",&ev)==0);
    assert(gc_vda_klog_parse("DEVICE_OWNER_CHANGED DeviceId:0x1234 UserId:0x2",&ev)==1);
    assert(ev.type==GC_VDA_KLOG_OWNER_CHANGED && ev.user_id==2);
    assert(gc_vda_klog_parse("DEVICE_OWNER_CHANGED DeviceId:0x1234 UserId:0x100000002",&ev)==0);
    assert(ev.type==GC_VDA_KLOG_NONE && ev.device_id==0);
    assert(gc_vda_klog_parse("DEVICE_OWNER_CHANGED DeviceId:0x1234 UserId:0xffffffff",&ev)==1);
    assert(ev.type==GC_VDA_KLOG_OWNER_CHANGED && ev.user_id==-1);
    return 0;
}
'''
with tempfile.TemporaryDirectory() as d:
    f=Path(d)/'test.c';f.write_text(code)
    exe=Path(d)/'test'
    subprocess.run(['cc','-std=c11','-D_DEFAULT_SOURCE','-Wall','-Wextra','-Wshadow','-Werror',
      '-I',str(root/'core/src'),str(root/'core/src/gc_vda_klog.c'),str(f),'-o',str(exe)],check=True)
    subprocess.run([str(exe)],check=True)
print('PASS: native gc_vda_klog.c legacy/new MBus and invalid tokens')
