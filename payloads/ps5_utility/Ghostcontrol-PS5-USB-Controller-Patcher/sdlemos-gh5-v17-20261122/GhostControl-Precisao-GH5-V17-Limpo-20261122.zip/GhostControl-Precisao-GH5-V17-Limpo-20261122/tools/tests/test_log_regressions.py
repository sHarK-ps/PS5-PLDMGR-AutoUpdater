#!/usr/bin/env python3
"""Run production bond-store, forget and inquiry routines without PS5 hardware."""
from pathlib import Path
import os
import shlex
import subprocess
import tempfile

root = Path(__file__).resolve().parents[2]
source = (root / 'core/src/bt/host.c').read_text()

def extract_function(text: str, signature: str) -> str:
    start = text.index(signature)
    brace = text.index('{', start)
    depth = 0
    for pos in range(brace, len(text)):
        if text[pos] == '{':
            depth += 1
        elif text[pos] == '}':
            depth -= 1
            if depth == 0:
                return text[start:pos + 1]
    raise RuntimeError(f'unterminated function: {signature}')

# Preserve the real private layout because start_inquiry() casts host_t to it.
layout_start = source.index('typedef struct {')
layout_end = source.index('} host_storage;', layout_start) + len('} host_storage;')
layout = source[layout_start:layout_end]
find = extract_function(source, 'db_rec *db_find(')
forget = extract_function(source, 'int db_forget(')
store = source[source.index('static int db_make_parent('):source.index('static void db_load(')]
start = extract_function(source, 'static void start_inquiry(')
status = source.split('if (len >= 6 && le16(ev + 4) == OP_INQUIRY) {', 1)[1].split(
    '\n        /* A refused Inquiry Cancel', 1)[0]

harness = r'''
#include "host_int.h"
#include "util.h"
#include <assert.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>
void log_line(const char *fmt, ...) { (void)fmt; }
const char *addr_str(const unsigned char *a) { (void)a; return "test-pad"; }
static long clock_ms;
long now_ms(void) { return clock_ms; }
LAYOUT
static int fake_send_ok = 1;
int send_cmd(host_t *h, unsigned op, const void *data, int size) {
    (void)h; (void)op; (void)data; (void)size; return fake_send_ok;
}
FIND
STORE
FORGET
START
static void inquiry_status(host_t *h, unsigned char code) {
    unsigned char ev[6] = {0}; ev[2] = code;
    ev[4] = (unsigned char)(OP_INQUIRY & 0xff);
    ev[5] = (unsigned char)((OP_INQUIRY >> 8) & 0xff);
    int len = (int)sizeof ev;
    if (len >= 6 && le16(ev + 4) == OP_INQUIRY) {
    STATUS
}
int main(void) {
    char work[] = "/tmp/ghostcontrol-store-XXXXXX";
    assert(mkdtemp(work));
    host_t h = {0};
    snprintf(h.db_path, sizeof h.db_path, "%s/service/bt/controllers.db", work);
    h.ndb = 2;
    h.db[0].addr[0] = 0x42; h.db[0].key[0] = 0xab;
    h.db[1].addr[0] = 0x43; h.db[1].key[0] = 0xcd;
    assert(db_save(&h)); /* Missing parents are created. */
    assert(db_find(&h, h.db[0].addr) != NULL);
    unsigned char forget_addr[6] = {0x42};
    assert(db_forget(&h, forget_addr));
    assert(h.ndb == 1 && h.db[0].addr[0] == 0x43);
    FILE *f = fopen(h.db_path, "rb"); assert(f);
    unsigned char bytes[8 + DB_REC];
    assert(fread(bytes, 1, sizeof bytes, f) == sizeof bytes);
    assert(fgetc(f) == EOF); assert(fclose(f) == 0);
    assert(!memcmp(bytes, DB_MAGIC, 8));
    assert(bytes[8] == 0x43 && bytes[14] == 0xcd);
    unsigned char absent[6] = {0xee};
    assert(db_forget(&h, absent)); /* Forgetting an absent address is idempotent. */

    /* A failed write must leave the in-memory database consistent with the
       still-existing persistent record; it must not report a successful forget. */
    strcpy(h.db_path, "/dev/null/controllers.db");
    unsigned char keep_addr[6] = {0x43};
    assert(db_forget(&h, keep_addr) == 0);
    assert(h.ndb == 1 && h.db[0].addr[0] == 0x43);

    host_storage state = {0};
    for (int i = 0; i < 8; ++i) {
        start_inquiry(&state.host);
        inquiry_status(&state.host, 0x0c);
        int expected = T_INQUIRY_RETRY << (i < 4 ? i : 4);
        assert(state.inquiry_backoff == expected);
        assert(!state.host.inquiring);
        assert(state.inquiry_at == clock_ms + expected);
        clock_ms = state.inquiry_at;
    }
    start_inquiry(&state.host);
    inquiry_status(&state.host, 0);
    assert(state.inquiry_backoff == 0 && state.host.inquiring);

    /* #33 8c008a8: failed *send* has no HCI Command Status, so its own
       failure branch must schedule and cap the retry. */
    state.host.inquiring = 0;
    fake_send_ok = 0;
    for (int i = 0; i < 8; ++i) {
        start_inquiry(&state.host);
        int expected = T_INQUIRY_RETRY << (i < 4 ? i : 4);
        assert(state.inquiry_backoff == expected);
        assert(state.inquiry_at == clock_ms + expected);
        clock_ms = state.inquiry_at;
    }
    fake_send_ok = 1;
    start_inquiry(&state.host);
    inquiry_status(&state.host, 0);
    assert(state.inquiry_backoff == 0);

    char file[300], folder[300];
    snprintf(file, sizeof file, "%s/service/bt/controllers.db", work);
    assert(unlink(file) == 0);
    snprintf(folder, sizeof folder, "%s/service/bt", work); assert(rmdir(folder) == 0);
    snprintf(folder, sizeof folder, "%s/service", work); assert(rmdir(folder) == 0);
    assert(rmdir(work) == 0);
    return 0;
}
'''.replace('LAYOUT', layout).replace('FIND', find).replace('STORE', store).replace('FORGET', forget).replace('START', start).replace('STATUS', status)

with tempfile.TemporaryDirectory(prefix='ghostcontrol-tests-') as directory:
    work = Path(directory)
    (work / 'test.c').write_text(harness)
    compiler = shlex.split(os.environ.get('CC', 'cc'))
    subprocess.run(compiler + [
        '-D_DEFAULT_SOURCE', '-std=c11', '-Wall', '-Wextra', '-Werror',
        '-I' + str(root / 'core/src/bt'), str(work / 'test.c'), '-o', str(work / 'test')], check=True)
    subprocess.run([str(work / 'test')], check=True)
print('PASS: bond-store mkdir/write, db_forget success/failure rollback, inquiry reject/failed-send backoff and success reset')
