#!/usr/bin/env python3
"""R11 regression: extract and execute actual GH5 vpad production code on a host.
Not a console/PS5 test. The test must fail against R10 sources.
"""
import pathlib,subprocess,tempfile,sys
src=pathlib.Path(__file__).resolve().parents[2]/'core'/'src'/'bt'/'ps5_vpad.c'
s=src.read_text(encoding='utf-8')

needle='int vpad_retryable(int slot)'
if needle not in s:sys.exit('R11 missing vpad_retryable API (expected RED on R10)')
start=s.index(needle)
a=start+len(needle)
while s[a]!='{':a+=1
n=0
for end in range(a,len(s)):
 if s[end]=='{':n+=1
 elif s[end]=='}':
  n-=1
  if n==0:break
body=s[start:end+1]
c=r"""
#include <assert.h>
#include <stdio.h>
#define HOST_MAX_PADS 2
#define VP_FAILED 5
#define VP_UNCERTAIN 6
#define VP_PREFLIGHT 2
#define VP_PENDING 3
#define VP_READY 4
typedef struct{int st;int add_attempted;} vslot;
static vslot g_slot[HOST_MAX_PADS];
static int g_log_fd=-1,g_log_close_uncertain=0;
SUBJECT
int main(void){
 assert(!vpad_retryable(-1));assert(!vpad_retryable(2));
 g_slot[0].st=VP_FAILED;g_slot[0].add_attempted=0;
 assert(vpad_retryable(0));
 g_slot[0].add_attempted=1;assert(!vpad_retryable(0));
 g_slot[0].st=VP_UNCERTAIN;g_slot[0].add_attempted=0;
 assert(!vpad_retryable(0));
 g_slot[0].st=VP_PENDING;assert(!vpad_retryable(0));
 g_slot[0].st=VP_FAILED;g_log_close_uncertain=1;assert(!vpad_retryable(0));
 g_log_close_uncertain=0;g_log_fd=7;assert(!vpad_retryable(0));
 puts("R11 retry safety PASS");return 0;
}
""".replace('SUBJECT',body)
with tempfile.TemporaryDirectory() as d:
 f=pathlib.Path(d)/'test.c';f.write_text(c)
 exe=pathlib.Path(d)/'test'
 a=subprocess.run(['cc','-std=c11','-Wall','-Wextra','-Werror',str(f),'-o',str(exe)],capture_output=True,text=True)
 if a.returncode:print(a.stderr);sys.exit(a.returncode)
 b=subprocess.run([str(exe)],capture_output=True,text=True)
 print(b.stdout,b.stderr,sep='')
 sys.exit(b.returncode)
