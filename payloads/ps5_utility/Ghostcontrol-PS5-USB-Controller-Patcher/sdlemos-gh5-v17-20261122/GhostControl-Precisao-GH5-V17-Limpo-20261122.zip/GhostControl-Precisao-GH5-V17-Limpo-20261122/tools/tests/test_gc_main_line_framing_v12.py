#!/usr/bin/env python3
"""V12: run the actual native gc_main.c line framing loop on host socket input.
A long line must never be parsed before its physical newline.
"""
from pathlib import Path
import subprocess,tempfile
root=Path(__file__).resolve().parents[2]
s=(root/'core/src/gc_main.c').read_text()
start=s.index('            for (ssize_t index = 0; index < length; ++index) {',s.index('static void *vda_klog_thread('))
end=s.index('\n        }\n        atomic_store',start)
loop=s[start:end]
code=r'''
#define _DEFAULT_SOURCE
#include <sys/types.h>
#include <stdint.h>
#include <assert.h>
#include <stdio.h>
#include <string.h>
#include "gc_vda_klog.h"
static char line[1024];
static size_t line_length=0;
static int line_overlong=0;
static unsigned records=0;
static void vda_record_event(const GcVdaKlogEvent *event){assert(event->type==GC_VDA_KLOG_ADDED);records++;}
static void process(const char *buffer, ssize_t length){
LOOP
}
int main(void){
 (void)line_overlong;
 char longline[1450];const char *prefix="DEVICE_ADDED DeviceId:0x1234 type:1 subType:22 capabilityBattery:0 ";
 memset(longline,'x',sizeof longline);memcpy(longline,prefix,strlen(prefix));
 process(longline,sizeof longline);
 assert(records==0);
 process("\n",1);
 assert(records==0);
 const char *valid="DEVICE_ADDED DeviceId:0x4567 type:1 subType:22 capabilityBattery:0\n";
 process(valid,strlen(valid));
 assert(records==1);
 const char *fragment="DEVICE_ADDED DeviceId:0x8888 type:1 subType:22 capabilityBattery:0";
 process(fragment,strlen(fragment));assert(records==1);
 process("\n",1);assert(records==2);
 return 0;
}
'''.replace('LOOP',loop)
with tempfile.TemporaryDirectory() as d:
 f=Path(d)/'h.c';f.write_text(code)
 exe=Path(d)/'h'
 subprocess.run(['cc','-std=c11','-Wall','-Wextra','-Wshadow','-Werror',
     '-I',str(root/'core/src'),str(root/'core/src/gc_vda_klog.c'),str(f),'-o',str(exe)],check=True)
 subprocess.run([str(exe)],check=True)
print('PASS: native gc_main line framing, including overlong and fragmented lines')
