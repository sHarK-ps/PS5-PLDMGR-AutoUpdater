#!/usr/bin/env python3
"""Exercise production USB completion and progress diagnostics on the host."""
from pathlib import Path
import subprocess
import tempfile

root = Path(__file__).resolve().parents[2]
source = (root / 'core/src/gc_service_inject.c').read_text()
log_start = source.index('static void usb_progress_log(')
log_end = source.index('\n}', log_start) + 2
complete_start = source.index('/* Nonzero transfer indices')
complete_end = source.index('        source_snapshot_lock();', complete_start)

harness = r'''
#include <assert.h>
#include <stdarg.h>
#include <stdio.h>
#include <string.h>
#include "gc_usb_progress.h"
#include "gc_usb_fallback.h"
#define GC_GH5_PRECISION_DIAGNOSTIC 0

typedef struct {
    GcUsbProgress progress;
    GcUsbFallback fallback;
    unsigned vid, pid, lenp, in_xfer_len, in_ep;
    int fd, interface_number, busy;
    const char *path;
    uint8_t report[64];
    struct { unsigned aFrames, status; } ep[1];
} UsbFeed;

static uint64_t now;
static unsigned faults;
static char progress_line[2048];
static uint64_t gc_fallback_now_ms(void) { return now; }
static int usb_note_io(UsbFeed *feed, int err, int status, int invalid)
{
    (void)feed; (void)err;
    assert(status || invalid);
    ++faults;
    return 0;
}
static void log_line(const char *format, ...)
{
    va_list args;
    va_start(args, format);
    if (strncmp(format, "usb progress:", 13) == 0)
        vsnprintf(progress_line, sizeof progress_line, format, args);
    va_end(args);
}
PROGRESS_LOG
static void complete(UsbFeed *feed, int ep_index, unsigned status,
                     unsigned frames, unsigned length)
{
    struct { int ep_index; } done = { ep_index };
    feed->ep[0].status = status;
    feed->ep[0].aFrames = frames;
    feed->lenp = length;
    do {
        COMPLETE_BRANCH
    } while (0);
}
int main(int argc, char **argv)
{
    assert(argc == 2);
    UsbFeed feed = { .vid=0x12ba, .pid=0x0100, .busy=1, .path="fixture" };
    now = 10;
    gc_usb_progress_start(&feed.progress, now);
    now = 1010;
    usb_progress_log(&feed);
    assert(strstr(progress_line, "phase=possible-stall"));
    ++now;
    complete(&feed, 1, 0, 1, 27); /* unrelated OUT completion */
    assert(feed.busy && feed.progress.completions == 0);
    complete(&feed, 0, 7, 0, 0); /* ioctl completed, endpoint failed */
    assert(!feed.busy && faults == 1 && feed.progress.completions == 1);
    ++now;
    complete(&feed, 0, 0, 2, 27); /* invalid frame count */
    assert(faults == 2 && feed.progress.completions == 2 && !feed.progress.inputs);
    now = 2010;
    usb_progress_log(&feed);
    if (strcmp(argv[1], "counts") == 0) {
        assert(strstr(progress_line, "complete_errors=0"));
        assert(strstr(progress_line, "endpoint_errors=1"));
        assert(strstr(progress_line, "frame_rejections=1"));
        return 0;
    }
    assert(strstr(progress_line, "phase=awaiting-input"));
    now = 2011;
    complete(&feed, 0, 0, 1, 27);
    assert(feed.progress.completions == 3 && feed.progress.inputs == 1);
    assert(feed.fallback.interrupt_in_received == 1);
    now = 3010;
    usb_progress_log(&feed);
    assert(strstr(progress_line, "phase=progress-resumed"));
    now = 4010;
    usb_progress_log(&feed);
    assert(strstr(progress_line, "phase=observe"));
    return 0;
}
'''.replace('PROGRESS_LOG', source[log_start:log_end]).replace(
    'COMPLETE_BRANCH', source[complete_start:complete_end])

with tempfile.TemporaryDirectory(prefix='ghostcontrol-usb-telemetry-') as directory:
    work = Path(directory)
    (work / 'test.c').write_text(harness)
    subprocess.run(['cc', '-std=c11', '-Wall', '-Wextra', '-Werror',
                    '-I', str(root / 'core/src'), 'test.c', '-o', 'test'], cwd=work, check=True)
    failed = [scenario for scenario in ('counts', 'phase')
              if subprocess.run([str(work / 'test'), scenario], cwd=work).returncode]
    assert not failed, f'USB completion telemetry regression(s): {failed}'

print('PASS: USB endpoint and frame errors are distinct; only valid input marks recovery')
