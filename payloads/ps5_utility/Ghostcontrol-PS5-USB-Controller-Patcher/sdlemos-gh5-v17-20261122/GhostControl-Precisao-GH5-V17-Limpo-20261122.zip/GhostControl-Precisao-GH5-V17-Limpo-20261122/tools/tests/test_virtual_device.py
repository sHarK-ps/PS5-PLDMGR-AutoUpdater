#!/usr/bin/env python3
"""Compile the real vpad log parser on a host, without the PS5 runtime."""
from pathlib import Path
import os
import shlex
import subprocess
import tempfile

root = Path(__file__).resolve().parents[2]
source = (root / 'core/src/bt/ps5_vpad.c').read_text()
# Extract adjacent pure helpers from production code so the test cannot silently
# exercise a separate implementation of MBus device discovery.
parser = source.split('static int vpad_id_field_end(', 1)[1]
parser = 'static int vpad_id_field_end(' + parser.split('static int log_source_read(', 1)[0]
harness = r'''
#include <assert.h>
#include <ctype.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
PARSER
int main(void) {
    assert(virtual_device_in("event=DEVICE_ADDED deviceId=0x1f030d deviceType=22 userId=0x0(0)") == 0x1f030d);
    assert(virtual_device_in("DEVICE_ADDED DeviceId:0x1234 type:1 subType:22 capabilityBattery:0") == 0x1234);
    assert(virtual_device_in("DEVICE_ADDED DeviceId:0x1234 type:1 subType:22 capabilityBattery:1") == 0);
    assert(virtual_device_in("DEVICE_ADDED deviceId=0x1234 deviceType=0x16") == 0x1234);
    assert(virtual_device_in("DEVICE_ADDED deviceId=0x1234 deviceType=022") == 0x1234);
    assert(virtual_device_in("DEVICE_ADDED deviceId=0x1234 deviceType=34") == 0);
    assert(virtual_device_in("DEVICE_ADDED deviceId=0x1234 deviceType=0x22") == 0);
    assert(virtual_device_in("DEVICE_ADDED deviceId=0x1234 deviceType=220") == 0);
    assert(virtual_device_in("DEVICE_ADDED deviceId=0x1234 deviceType=22junk") == 0);
    assert(virtual_device_in("DEVICE_ADDED deviceId=0x1234 deviceType=") == 0);
    assert(virtual_device_in("DEVICE_ADDED deviceType=22") == 0);
    assert(virtual_device_in("DEVICE_REMOVED deviceId=0x1234 deviceType=22") == 0);
    assert(virtual_device_in("NOT_DEVICE_ADDED deviceId=0x1234 deviceType=22") == 0);
    assert(virtual_device_in("DEVICE_ADDED_EXTRA deviceId=0x1234 deviceType=22") == 0);
    assert(virtual_device_in("DEVICE_ADDED deviceId=0x1234 otherdeviceType=22") == 0);
    assert(virtual_device_in("DEVICE_ADDED DeviceId:0x1234 type:10 subType:22") == 0);
    assert(virtual_device_in("DEVICE_ADDED DeviceId:0x1234 type:1 subType:220") == 0);
    assert(virtual_device_in("DEVICE_ADDED DeviceId:0x1234 xtype:1 subType:22") == 0);
    assert(virtual_device_in("DEVICE_ADDED: deviceId=0x1234 deviceType=22") == 0x1234);
    /* V12 safety regression: never derive a handle from a malformed MBus deviceId. */
    assert(virtual_device_in("DEVICE_ADDED deviceId=0x1234junk deviceType=22") == 0);
    assert(virtual_device_in("DEVICE_ADDED deviceId=0x12g deviceType=22") == 0);
    assert(virtual_device_in("DEVICE_ADDED deviceId=0x12345678901234567 deviceType=22") == 0);
    assert(virtual_device_in("DEVICE_ADDED otherdeviceId=0x1234 deviceType=22") == 0);
    assert(virtual_device_in("DEVICE_ADDED deviceId=0x1234 deviceType=22 capabilityBattery:") == 0);
    assert(virtual_device_in("DEVICE_ADDED deviceId=0x1234 deviceType=22 capabilityBattery:0bad") == 0);
    assert(virtual_device_in("DEVICE_ADDED DeviceId:0x1234junk type:1 subType:22 capabilityBattery:0") == 0);
    assert(virtual_device_in("") == 0);
    return 0;
}
'''.replace('PARSER', parser)
with tempfile.TemporaryDirectory(prefix='ghostcontrol-vpad-') as directory:
    work = Path(directory)
    (work / 'test.c').write_text(harness)
    compiler = shlex.split(os.environ.get('CC', 'cc'))
    subprocess.run(compiler + [
        '-std=c11', '-Wall', '-Wextra', '-Werror', str(work / 'test.c'),
        '-o', str(work / 'test')], check=True)
    subprocess.run([str(work / 'test')], check=True)
print('PASS: virtual_device_in: current and legacy logs, numeric bases, invalid types and missing fields')
