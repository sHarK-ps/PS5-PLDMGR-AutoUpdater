#!/usr/bin/env python3
"""Compile exact dispatcher R11 branch with real vpad_retryable() function.
Host seam, not the entire application service or physical PS5.
"""
from pathlib import Path
import tempfile,subprocess,sys
root=Path(__file__).resolve().parents[2]
s=(root/'core/src/gc_service_inject.c').read_text()
v=(root/'core/src/bt/ps5_vpad.c').read_text()
start=s.index('    if (inject_ready) vpad_poll(now);')
end=s.index('    refresh_policy();',start)
block=s[start:end]
func_start=v.index('int vpad_retryable(int slot)')
a=v.index('{',func_start);depth=0
for k in range(a,len(v)):
 if v[k]=='{':depth+=1
 elif v[k]=='}':
  depth-=1
  if depth==0:break
helper=v[func_start:k+1]
c=r"""
#define _DEFAULT_SOURCE
#include <assert.h>
#include <stdio.h>
#include <stdarg.h>
#define HOST_MAX_PADS 2
#define VP_FAILED 5
#define VP_UNCERTAIN 6
#define VP_PENDING 3
#define VP_READY 4
typedef struct{int st;int add_attempted;} vslot;
static vslot g_slot[HOST_MAX_PADS];
static int g_log_fd=-1,g_log_close_uncertain=0;
static int inject_ready=1,usb_owned[HOST_MAX_PADS],want_remove[HOST_MAX_PADS],backend_added[HOST_MAX_PADS];
static long add_retry_at[HOST_MAX_PADS];
static int polls=0,lock_count=0,log_count=0;
static void vpad_poll(long now){(void)now;polls++;}
static void source_snapshot_lock(void){lock_count++;}
static void source_snapshot_unlock(void){lock_count--;}
static void log_line(const char *fmt,...){(void)fmt;log_count++;}
HELPER
static void dispatch(long now){
BLOCK
}
static void reset(void){
 for(int i=0;i<HOST_MAX_PADS;i++){
  g_slot[i].st=0;g_slot[i].add_attempted=0;
  usb_owned[i]=0;want_remove[i]=0;backend_added[i]=0;add_retry_at[i]=0;
 }
 inject_ready=1;polls=0;lock_count=0;log_count=0;g_log_fd=-1;g_log_close_uncertain=0;
}
int main(void){
 reset();usb_owned[0]=1;backend_added[0]=1;g_slot[0].st=VP_FAILED;
 dispatch(12000);
 assert(!backend_added[0] && add_retry_at[0]==13000 && lock_count==0 && log_count==1);
 reset();usb_owned[0]=1;backend_added[0]=1;g_slot[0].st=VP_FAILED;g_slot[0].add_attempted=1;
 dispatch(12000);assert(backend_added[0] && log_count==0 && lock_count==0);
 reset();usb_owned[0]=1;backend_added[0]=1;g_slot[0].st=VP_UNCERTAIN;
 dispatch(12000);assert(backend_added[0] && log_count==0);
 reset();backend_added[0]=1;g_slot[0].st=VP_FAILED;
 dispatch(12000);assert(backend_added[0] && log_count==0);
 reset();usb_owned[0]=1;backend_added[0]=1;g_slot[0].st=VP_FAILED;want_remove[0]=1;
 dispatch(12000);assert(backend_added[0] && log_count==0);
 reset();usb_owned[0]=1;backend_added[0]=1;g_slot[0].st=VP_FAILED;inject_ready=0;
 dispatch(12000);assert(backend_added[0] && log_count==0 && polls==0);
 puts("R11 backend retry fencing PASS");return 0;
}
""".replace('HELPER',helper).replace('BLOCK',block)
with tempfile.TemporaryDirectory() as d:
 f=Path(d)/'test.c';f.write_text(c)
 e=Path(d)/'test'
 for flags in (['-DGC_GH5_USB_DIAGNOSTIC=1'],
               ['-DGC_GH5_USB_DIAGNOSTIC=0', '-DGC_GH5_TCP_PREFLIGHT_MS=750']):
  subprocess.run(['cc','-std=c11','-Wall','-Wextra','-Werror',*flags,str(f),'-o',str(e)],check=True)
  subprocess.run([str(e)],check=True)
