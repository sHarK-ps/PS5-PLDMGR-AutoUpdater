#!/usr/bin/env python3
from pathlib import Path
import unittest
ROOT = Path(__file__).resolve().parents[2]
class TestExperimentalDiagnostics(unittest.TestCase):
    def test_ebusy_context_is_logged(self):
        src=(ROOT/"core/src/gc_service_inject.c").read_text()
        for token in ("USB_FS_COMPLETE pending-snapshot", "poll_revents", "pending_aFrames", "requested", "pending_ep_status"):
            self.assertIn(token,src)
    def test_precision_progress_telemetry_and_build_variant(self):
        src=(ROOT/"core/src/gc_service_inject.c").read_text()
        mk=(ROOT/"GhosttoothAPI/Makefile").read_text()
        for token in ("GC_GH5_PRECISION_DIAGNOSTIC", "gh5: progress generation=",
                      "START_ok=%llu", "COMPLETE_ok=%llu", "EBUSY=%llu",
                      "decode_success=%llu", "probe_disabled_skips=%llu", "since_complete_ms=%lld",
                      "since_input_ms=%lld", "outstanding_ms=%lld", "last_completed_transfer_index=%d",
                      "gh5_progress_summary(&usb_feed[n], 0)"):
            self.assertIn(token,src)
        self.assertIn("VARIANT),gh5-precision",mk)
        self.assertIn("GhosttoothAPI-GH5-precision.elf",mk)
    def test_unrelated_device_log_is_rate_limited_not_disabled(self):
        src=(ROOT/"core/src/gc_service_inject.c").read_text()
        self.assertIn("040b:0897 open failed",src)
        self.assertIn("log rate-limited; retries unchanged",src)
        self.assertIn("attempt % 256u",src)
if __name__ == "__main__": unittest.main(verbosity=2)
