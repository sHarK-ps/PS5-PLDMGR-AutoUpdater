#!/usr/bin/env python3
"""Compile and execute actual production parameter construction for both modes."""
from pathlib import Path
import subprocess
import tempfile
root=Path(__file__).resolve().parents[2]
code=r"""
#include <assert.h>
#include <stdint.h>
#include "bt/vpad_add_param_r9.h"
#include "bt/vpad_trace_gate_r9.h"
int main(void) {
    int32_t p[8];
    for(int mode=0; mode<=1; ++mode) {
        gc_vpad_prepare_add_param_r9(p, mode);
        assert(p[0] == 32 && p[1] == 1);
        for(int i=2;i<8;i++) assert((uint32_t)p[i] == (mode ? 0u : 0xDEADBEEFu));
    }
    long last = 0;
    assert(gc_vpad_quarantine_notice_due_r9(1000, &last));
    assert(last == 1000);
    assert(!gc_vpad_quarantine_notice_due_r9(1001, &last));
    assert(!gc_vpad_quarantine_notice_due_r9(5999, &last));
    assert(gc_vpad_quarantine_notice_due_r9(6000, &last));
    assert(gc_vpad_quarantine_notice_due_r9(20, &last));
    assert(!gc_vpad_quarantine_notice_due_r9(21, &last));
    assert(!gc_vpad_quarantine_notice_due_r9(1, (long*)0));
    return 0;
}
"""
with tempfile.TemporaryDirectory(prefix='gh5-r9-param-') as d:
    a=Path(d); (a/'test.c').write_text(code)
    subprocess.run(['cc','-std=c11','-Wall','-Wextra','-Werror','-I',str(root/'core/src'),str(a/'test.c'),'-o',str(a/'test')],check=True)
    subprocess.run([str(a/'test')],check=True)
source=(root/'core/src/bt/ps5_vpad.c').read_text()
assert 'gc_vpad_prepare_add_param_r9(param, GC_GH5_VDA_ZERO_RESERVED)' in source
assert 'GH5_VDA_R9 AddDevice param_layout=' in source
assert 'GH5_KLOG_R9 TCP_CONNECTED_BUT_SILENT' in source
assert 'LOCKED_BY_ANOTHER_READER' in source
assert 'gc_vpad_quarantine_notice_due_r9(current, last)' in source
make=(root/'GhosttoothAPI/Makefile').read_text()
assert 'GH5-PROBE-V17-20261122' in make
assert ('-DGC_GH5_VDA_ZERO_RESERVED=1' in make) == True
print('PASS: R9 production AddDevice layout, log classification, quarantine notice rate, bundle banner')
