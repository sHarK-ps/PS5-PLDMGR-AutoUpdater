#!/usr/bin/env python3
"""Source-level regression tests for the PR #32 review follow-up."""
from pathlib import Path
import re
import unittest

ROOT = Path(__file__).resolve().parents[2]
SRC = ROOT / "core/src"


def body(source: str, signature: str) -> str:
    start = source.index(signature)
    brace = source.index("{", start)
    depth = 0
    for pos in range(brace, len(source)):
        if source[pos] == "{":
            depth += 1
        elif source[pos] == "}":
            depth -= 1
            if depth == 0:
                return source[start:pos + 1]
    raise AssertionError(f"unterminated function: {signature}")


class TestPR32ReviewFollowup(unittest.TestCase):
    def test_hid_cache_invalidated_on_retirement_and_missing_node(self):
        usb = (SRC / "gc_usb.c").read_text()
        header = (SRC / "gc_usb.h").read_text()
        inject = (SRC / "gc_service_inject.c").read_text()
        close_feed = body(inject, "static void usb_close_feed(")
        self.assertIn("void gc_usb_forget_path(const char *path)", usb)
        self.assertIn("gc_usb_forget_path", header)
        self.assertIn("void gc_usb_hid_layout_forget(const char *path)", usb)
        self.assertIn("hid_layout_cache_mark_seen", usb)
        self.assertIn("hid_layout_cache_drop_unseen(seen)", usb)
        self.assertIn("pthread_mutex_lock(&hid_layout_cache_lock)", usb)
        self.assertIn("pthread_mutex_lock(&hid_layout_scan_lock)", usb)
        self.assertIn("bcd_device", usb)
        self.assertIn("gc_usb_hid_layout_forget(feed->path)", close_feed)

    def test_first_gip_input_is_queued_then_decoded(self):
        xbox_h = (SRC / "controller_xbox.h").read_text()
        xbox_c = (SRC / "controller_xbox.c").read_text()
        inject = (SRC / "gc_service_inject.c").read_text()
        self.assertIn("uint8_t pending_input[64]", xbox_h)
        self.assertIn("state->pending_input_valid = 1", xbox_c)
        self.assertIn("feed->xbox.pending_input_valid", inject)
        self.assertIn("xbox_take_initial_report(&feed->xbox", inject)
        self.assertIn("uint32_t xbox_take_initial_report(", xbox_c)
        self.assertLess(inject.index("if (feed->gip && !feed->gip_ready)"), inject.index("if (feed->slot < 0) {\n            int slot = free_slot();"))
        self.assertRegex(inject, r"usb_decode\(feed, &devices\[i\], &state\)\)\s*remember")

    def test_handshake_is_async_and_cancelled_before_close(self):
        inject = (SRC / "gc_service_inject.c").read_text()
        open_feed = body(inject, "static int usb_open_feed(")
        close_feed = body(inject, "static void usb_close_feed(")
        worker = body(inject, "static void *gip_handshake_worker(")
        self.assertNotIn("xbox_gip_handshake(", open_feed)
        self.assertIn("pthread_create", open_feed)
        self.assertIn("xbox_gip_handshake(", worker)
        self.assertIn("gip_worker_keep_running", worker)
        self.assertIn("gip_worker_join(feed, 1, NULL)", close_feed)
        self.assertIn("if (worker_state == 1) continue;", inject)
        self.assertIn("gip_worker_join(feed, 0, &handshake)", inject)
        self.assertIn("source_dispatch_lock()) { usb_tick(); source_dispatch_unlock(); }", inject)
        self.assertIn("handshake started asynchronously", inject)


if __name__ == "__main__":
    unittest.main(verbosity=2)
