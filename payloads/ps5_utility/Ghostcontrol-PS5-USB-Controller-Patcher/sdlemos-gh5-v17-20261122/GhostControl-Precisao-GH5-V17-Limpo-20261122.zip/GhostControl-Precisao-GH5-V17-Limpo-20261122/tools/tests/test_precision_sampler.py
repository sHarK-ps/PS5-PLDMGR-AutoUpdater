#!/usr/bin/env python3
"""Behavioral host test of the actual GH5 RAW sampler with fake clock/log sink."""
from pathlib import Path
import os, shlex, subprocess, tempfile
root=Path(__file__).resolve().parents[2]
src=(root/'core/src/gc_service_inject.c').read_text()
a=src.index('/* Per-generation, per-source bounded change capture.')
b=src.index('\n#endif',a)
fn=src[a:b]
harness=r'''
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <stdarg.h>
#include <assert.h>
#define USB_REPORT 64
#define GC_GH5_PRECISION_DIAGNOSTIC 1
typedef struct {int kind,interface_index,interface_number;} GcUsbDevice;
typedef struct {
  unsigned long long trace_generation;
  unsigned long long trace_raw_seen[2], trace_raw_logged[2], trace_raw_dropped[2];
  unsigned long long trace_raw_drop_total[2];
  uint8_t trace_raw_prev[2][USB_REPORT];
  size_t trace_raw_prev_len[2];
  uint64_t trace_raw_bucket_sec[2];
  unsigned trace_raw_bucket_count[2];
  int slot; char path[32]; uint8_t in_ep;
} UsbFeed;
static uint64_t fake_ms;
static unsigned raw_in, raw_ctrl, loss_notifications;
static uint64_t gc_fallback_now_ms(void) {return fake_ms;}
static void log_line(const char *fmt, ...) {
  char buffer[1024]; va_list ap;va_start(ap,fmt);
  vsnprintf(buffer,sizeof buffer,fmt,ap);va_end(ap);
  if (strstr(buffer,"gh5: RAW source=INTERRUPT_IN")) ++raw_in;
  if (strstr(buffer,"gh5: RAW source=CONTROL_GET_REPORT")) ++raw_ctrl;
  if (strstr(buffer,"gh5: RAW dropped")) ++loss_notifications;
}
BLOCK
int main(void) {
  UsbFeed feed={0}; GcUsbDevice dev={0}; uint8_t input[27]={0},control[3]={0};
  feed.trace_generation=1;feed.slot=0;strcpy(feed.path,"/dev/ugen2.2");
  fake_ms=1200;
  for(unsigned i=0;i<32;i++){input[0]=(uint8_t)(i+1);gh5_trace_report(&feed,&dev,input,27,0);}
  assert(raw_in==24 && feed.trace_raw_dropped[0]==8 && feed.trace_raw_drop_total[0]==8);
  for(unsigned i=0;i<12;i++){control[0]=(uint8_t)(i+1);gh5_trace_report(&feed,&dev,control,3,1);}
  assert(raw_ctrl==3 && feed.trace_raw_dropped[1]==9 && feed.trace_raw_drop_total[1]==9);
  fake_ms=2200;input[0]=0xaa;gh5_trace_report(&feed,&dev,input,27,0);
  control[0]=0xbb;gh5_trace_report(&feed,&dev,control,3,1);
  assert(raw_in==25 && raw_ctrl==4 && loss_notifications==2);
  memset(&feed,0,sizeof feed);feed.trace_generation=2;
  fake_ms=2300;input[0]=0xcc;gh5_trace_report(&feed,&dev,input,27,0);
  assert(raw_in==26 && feed.trace_raw_logged[0]==1);
  return 0;
}
'''.replace('BLOCK',fn)
with tempfile.TemporaryDirectory(prefix='gh5-sampler-') as tmp:
    p=Path(tmp);(p/'test.c').write_text(harness)
    subprocess.run(shlex.split(os.environ.get('CC','cc'))+[
        '-std=c11','-Wall','-Wextra','-Werror',str(p/'test.c'),'-o',str(p/'test')],check=True)
    subprocess.run([str(p/'test')],check=True)
print('PASS: per-source per-second RAW sampling, drops and per-connection reset')
