#!/usr/bin/env python3
"""Compile and exercise the *exact production* gh5_vpad_probe_enabled wrapper."""
from pathlib import Path
import os, shlex, subprocess, tempfile
root = Path(__file__).resolve().parents[2]
src = (root/'core/src/gc_service_inject.c').read_text()
start = src.index('static int gh5_vpad_probe_enabled(void)')
end = src.index('\n}\n',start)+2
function=src[start:end]
assert function.count('pthread_mutex_lock(&probe_mu)') == 1
assert function.count('pthread_mutex_unlock(&probe_mu)') == 1
code=r'''
#define _DEFAULT_SOURCE 1
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>
#include <stdint.h>
#include "gc_gh5_probe.h"
#define GH5_VPAD_PROBE_MARKER marker_path
static char marker_path[1024];
static uint64_t clock_now;
static unsigned emitted;
static char last[2048];
static uint64_t gc_fallback_now_ms(void) { return clock_now; }
static void log_line(const char *fmt, ...)
{
 va_list args;va_start(args,fmt);
 vsnprintf(last,sizeof last,fmt,args);va_end(args);++emitted;
}
WRAPPER
int main(int argc,char **argv)
{
 assert(argc==2);
 assert(snprintf(marker_path,sizeof marker_path,"%s/gh5-vpad-probe.enable",argv[1])>0);
 clock_now=1000;
 assert(!gh5_vpad_probe_enabled());
 assert(emitted>=2);
 FILE *f=fopen(marker_path,"wb");assert(f);fclose(f);
 clock_now=1500;assert(!gh5_vpad_probe_enabled());
 clock_now=2000;assert(gh5_vpad_probe_enabled());
 unsigned previous=emitted;
 assert(gh5_vpad_probe_enabled());assert(emitted==previous);
 assert(unlink(marker_path)==0);
 clock_now=50000;assert(gh5_vpad_probe_enabled());
 return 0;
}
'''.replace('WRAPPER',function)
for trace in (0,1):
    with tempfile.TemporaryDirectory(prefix='gh5-r7-wrapper-') as td:
        path=Path(td)
        c=path/'wrapper.c';c.write_text(code)
        exe=path/'wrapper'
        subprocess.run(shlex.split(os.environ.get('CC','cc')) + [
            '-std=c11','-Wall','-Wextra','-Wshadow','-Werror',
            '-DGC_GH5_PROBE_PATH_TRACE='+str(trace),
            '-I'+str(root/'core/src'),str(c),'-pthread','-o',str(exe)],check=True)
        subprocess.run([str(exe),str(path)],check=True)
print('PASS: exact R7 production wrapper, both path-trace variants, pthread, late marker')
