#!/usr/bin/env python3
"""Review gates for PR #29 follow-ups: source checks, not hardware emulation."""
from pathlib import Path
import unittest
ROOT = Path(__file__).resolve().parents[2] / "core/src"
class Review29(unittest.TestCase):
    def test_remoteplay_transport_exclusive_in_both_discovery_paths(self):
        s=(ROOT/"gc_ds4_source.c").read_text()
        self.assertIn("info[10] == 2",s)
        self.assertIn("connection_type == 2",s)
        self.assertIn("args.fp_controller_info = symbols.controller_info",s)
        self.assertIn("args.fp_controller_info != symbols.controller_info",s)
        self.assertIn("if (handle > 0 && controller_info",s)
    def test_rumble_failed_delivery_is_not_acknowledged(self):
        s=(ROOT/"gc_ds4_bridge.c").read_text()
        self.assertIn("retry_after[route] = now + UINT64_C(100000000)",s)
        self.assertIn("game.rumble_sequences[route] = sequence",s)
        self.assertLess(s.index("continue;\n        }\n        retry_after[route] = 0;"),
                        s.index("game.rumble_sequences[route] = sequence"))
        self.assertIn("stop_source_rumble();",s)
    def test_klog_source_checked_and_classified(self):
        s=(ROOT/"bt/ps5_vpad.c").read_text()
        for marker in ["F_SETFL, flags | O_NONBLOCK", "g_log_read_errno = errno",
                       "g_log_eof = 1", "g_log_device_added", "add_rc=%#x",
                       "kernel log supplied no bytes"]: self.assertIn(marker,s)
    def test_no_neutral_publication_after_known_handshake(self):
        s=(ROOT/"gc_service_inject.c").read_text()
        self.assertIn("allow_raw_learning = !from_control",s)
        self.assertIn("if (!allow_raw_learning) return 0;",s)
        self.assertIn("if (handled <= 0) return 0;",s)
if __name__ == '__main__': unittest.main(verbosity=2)
