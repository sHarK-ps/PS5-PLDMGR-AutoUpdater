#!/usr/bin/env python3
# Host-test production R10 TCP evidence and extracted lifecycle
# Compiles exact production functions, with only PS5 calls mocked
from pathlib import Path
import subprocess
import tempfile
root = Path(__file__).resolve().parents[2]
s = (root/'core/src/bt/ps5_vpad.c').read_text()
m = (root/'GhosttoothAPI/Makefile').read_text()
assert 'GH5-PROBE-V17-20261122' in m
assert '-DGC_GH5_TCP_ONLY=1' in m
assert '-DGC_GH5_KLOG_DEV_OPTIN=1' not in m
assert 'GH5_TCP_R10 TCP_ONLY:' in s
assert 'GH5_TCP_R10 health=' in s
assert 'g_log_bytes == 0' in s
assert 'case VP_PREFLIGHT:' in s and 'preflight_cancelled slot=' in s
if 'GH5_PRECISION_DIAGNOSTIC' in m:
    preflight_ms, zero = 750, 1
else:
    preflight_ms, zero = 0, 0
assert f'-DGC_GH5_TCP_PREFLIGHT_MS={preflight_ms}' in m

functions = s[s.index('static void start_adddevice_after_drain(int slot)'):s.index('static void finish_identification(')]
code = r'''
#define _DEFAULT_SOURCE 1
#include <stdint.h>
#include <stdlib.h>
#include <stdarg.h>
#include <stdio.h>
#include <assert.h>
#include <string.h>
#include "bt/vpad_add_param_r9.h"
#include "bt/vpad_tcp_health_r10.h"
#define GC_VPAD_TEST_TRACE 0
#define GC_VPAD_RAISE_CREDS 0
#define VIRTUAL_DEVICE_DUALSENSE 3
#define HOST_MAX_PADS 4
#define VP_FREE 0
#define VP_QUEUED 1
#define VP_PREFLIGHT 2
#define VP_PENDING 3
#define VP_READY 4
#define VP_FAILED 5
#define VP_UNCERTAIN 6
#define VP_DELETE_FAILED 7
#define T_IDENTIFY 3000
#define T_TCP_PREFLIGHT_DEADLINE 2500
struct vslot {int st;int add_attempted;};
static struct vslot g_slot[HOST_MAX_PADS];
static int32_t g_user=42, g_add_result;
static int g_log_fd=-1, g_log_is_dev=0, g_log_eof=0, g_log_read_errno=0;
static uint64_t g_log_bytes=0, g_log_lines=0, g_log_mbus_events=0, g_log_device_added=0;
static uint64_t g_pre_bytes=0, g_pre_lines=0, g_pre_mbus=0, g_pre_added=0;
static int g_preflight_slot=-1, g_pending=-1, g_matches=0;
static long g_preflight_since_ms=0, g_preflight_elapsed_ms=0, g_t_add=0;
static uint64_t g_match_dev=0;
static long g_log_first_byte_ms=-1, g_log_last_byte_ms=-1;
static char g_line[1024];
static size_t g_line_len=0;
static int g_line_overflow=0;
static long mock_now=100;
static int mock_read_ok=1, mock_add_calls=0, mock_closes=0;
static int32_t mock_add_param[8];
long now_ms(void) {return mock_now;}
int32_t main_user(void) {return 42;}
void log_line(const char *fmt, ...) {(void)fmt;}
int log_source_open(void) {g_log_fd=31;g_log_is_dev=0;return 31;}
int log_source_read(void) {return mock_read_ok;}
void log_source_close(void) {mock_closes++; g_log_fd=-1;g_line_len=0;}
int32_t scePadVirtualDeviceAddDevice(void *param, int typ) {
    assert(typ==3);mock_add_calls++;memcpy(mock_add_param,param,sizeof mock_add_param);
    return (int32_t)0x803b0006u;
}
SUBJECT
static void reset(void) {
    memset(g_slot, 0, sizeof g_slot);
    g_slot[0].st=VP_QUEUED;
    g_user=42;g_log_fd=-1;g_pending=-1;g_preflight_slot=-1;
    g_log_bytes=g_log_lines=g_log_mbus_events=g_log_device_added=0;
    g_line_len=0;mock_now=100;mock_add_calls=0;mock_closes=0;mock_read_ok=1;
}
int main(void) {
    assert(gc_vpad_tcp_health_r10(0,0,0,0)==GC_VPAD_TCP_R10_NO_BYTES);
    assert(gc_vpad_tcp_health_r10(5,0,0,0)==GC_VPAD_TCP_R10_PRE_ONLY);
    assert(gc_vpad_tcp_health_r10(0,5,0,0)==GC_VPAD_TCP_R10_LIVE_ONLY);
    assert(gc_vpad_tcp_health_r10(5,5,0,0)==GC_VPAD_TCP_R10_PRE_AND_LIVE);
    assert(gc_vpad_tcp_health_r10(5,5,1,0)==GC_VPAD_TCP_R10_EOF);
    assert(gc_vpad_tcp_health_r10(5,5,0,16)==GC_VPAD_TCP_R10_READ_ERROR);
    assert(!strcmp(gc_vpad_tcp_health_name_r10(GC_VPAD_TCP_R10_NO_BYTES), "TCP_CONNECTED_NO_BYTES"));
    if (0) poll_preflight(0); /* the production poll dispatch references it in both variants */
    reset();start_identification(0);
#if GC_GH5_TCP_PREFLIGHT_MS > 0
    assert(g_slot[0].st==VP_PREFLIGHT && g_preflight_slot==0 && mock_add_calls==0);
    mock_now=849;poll_preflight(mock_now);
    assert(mock_add_calls==0 && g_slot[0].st==VP_PREFLIGHT);
    mock_now=850;poll_preflight(mock_now);
#else
    assert(g_slot[0].st==VP_PENDING);
#endif
    assert(mock_add_calls==1 && g_pending==0 && g_slot[0].st==VP_PENDING);
    assert(mock_add_param[0]==32 && mock_add_param[1]==1);
    for(int k=2;k<8;k++) assert((uint32_t)mock_add_param[k] ==
        (GC_GH5_VDA_ZERO_RESERVED ? 0u:0xdeadbeefu));
#if GC_GH5_TCP_PREFLIGHT_MS > 0
    reset();mock_read_ok=0;start_identification(0);
    assert(g_slot[0].st==VP_PREFLIGHT && mock_closes==0);
    mock_now=850;poll_preflight(mock_now);
    assert(mock_add_calls==0 && g_slot[0].st==VP_PREFLIGHT && mock_closes==0);
    mock_read_ok=1;mock_now=900;poll_preflight(mock_now);
    assert(mock_add_calls==1 && g_slot[0].st==VP_PENDING && mock_closes==0);

    reset();g_line_len=41;start_identification(0);mock_now=850;
    poll_preflight(mock_now);
    assert(mock_add_calls==0 && g_slot[0].st==VP_PREFLIGHT && mock_closes==0);
    g_line_len=0;mock_now=900;poll_preflight(mock_now);
    assert(mock_add_calls==1 && g_slot[0].st==VP_PENDING);

    reset();start_identification(0);
    mock_read_ok=0;g_log_eof=1;mock_now=200;poll_preflight(mock_now);
    assert(mock_add_calls==0 && g_preflight_slot==-1 && g_slot[0].st==VP_FAILED);
    assert(mock_closes==1);

    reset();start_identification(0);mock_read_ok=0;
    mock_now=100+T_TCP_PREFLIGHT_DEADLINE;poll_preflight(mock_now);
    assert(mock_add_calls==0 && g_slot[0].st==VP_FAILED && mock_closes==1);

    reset();start_identification(0);g_line_len=41;
    mock_now=100+T_TCP_PREFLIGHT_DEADLINE;poll_preflight(mock_now);
    assert(mock_add_calls==0 && g_slot[0].st==VP_FAILED && mock_closes==1);
#endif
    return 0;
}
'''.replace('SUBJECT',functions)
with tempfile.TemporaryDirectory(prefix='gh5-r10-') as d:
    c=Path(d)/'test.c';c.write_text(code)
    o=Path(d)/'test'
    subprocess.run(['cc','-std=c11','-D_DEFAULT_SOURCE=1','-Wall','-Wextra','-Werror',
       f'-DGC_GH5_TCP_PREFLIGHT_MS={preflight_ms}',f'-DGC_GH5_VDA_ZERO_RESERVED={zero}',
       '-I',str(root/'core/src'),str(c),'-o',str(o)],check=True)
    subprocess.run([str(o)],check=True)
print(f'PASS: production preflight lifecycle; mode={preflight_ms}ms zero_reserved={zero}; TCP evidence classifier')
