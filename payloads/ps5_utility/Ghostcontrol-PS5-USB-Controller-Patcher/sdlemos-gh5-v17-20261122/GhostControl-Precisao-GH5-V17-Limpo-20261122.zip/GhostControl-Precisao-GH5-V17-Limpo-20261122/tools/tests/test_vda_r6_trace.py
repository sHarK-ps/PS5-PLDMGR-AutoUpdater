#!/usr/bin/env python3
"""R6 host validation of production state names, guard, marker and Makefile."""
from pathlib import Path
import subprocess, tempfile, os, shlex
root=Path(__file__).resolve().parents[2]
v=(root/'core/src/bt/ps5_vpad.c').read_text()
m=(root/'GhosttoothAPI/Makefile').read_text()
s=(root/'core/src/gc_service_inject.c').read_text()
assert m.count('ELF := GhosttoothAPI-GH5-precision.elf')<=1
assert m.count('-DGC_GH5_PRECISION_DIAGNOSTIC=1')<=1
assert 'GC_VPAD_TEST_TRACE=1' in m
assert 'GH5-PROBE-V17-20261122' in m
assert 'gh5-vpad-probe.enable' in s and 'gh5_vpad_probe_enabled()' in s
assert 'GH5_VDA_R6 QUARANTINED' in v
assert 'GH5_VDA_R6 shutdown blocked' in v
assert 'v->st = VP_UNCERTAIN;' in v
assert 'vpad_release_blocker()' in v
assert 'gc_vpad_trace_snapshot(now);' in v
start=v.index('enum { VP_FREE, VP_QUEUED')
end=v.index('#endif',v.index('static const char *gc_vpad_state_name',start))+len('#endif')
helper=v[start:end]
code=r"""
#include <assert.h>
#include <string.h>
#define GC_VPAD_TEST_TRACE 1
HELPER
int main(void) {
 assert(!strcmp(gc_vpad_state_name(VP_FREE),"FREE"));
 assert(!strcmp(gc_vpad_state_name(VP_QUEUED),"QUEUED"));
 assert(!strcmp(gc_vpad_state_name(VP_PENDING),"PENDING"));
 assert(!strcmp(gc_vpad_state_name(VP_READY),"READY"));
 assert(!strcmp(gc_vpad_state_name(VP_FAILED),"FAILED"));
 assert(!strcmp(gc_vpad_state_name(VP_UNCERTAIN),"UNCERTAIN"));
 assert(!strcmp(gc_vpad_state_name(VP_DELETE_FAILED),"DELETE_FAILED"));
 return 0;
}
""".replace('HELPER',helper)
with tempfile.TemporaryDirectory(prefix='gh5-vda-r6-') as p:
 c=Path(p)/'v.c';c.write_text(code)
 exe=Path(p)/'test'
 subprocess.run(shlex.split(os.environ.get('CC','cc'))+['-std=c11','-Wall','-Wextra','-Werror',str(c),'-o',str(exe)],check=True)
 subprocess.run([str(exe)],check=True)
print('PASS: R6 production state taxonomy, quarantine, probe marker, build-tag and Makefile dedup')
