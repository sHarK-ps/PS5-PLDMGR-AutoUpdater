#!/usr/bin/env python3
"""Extract EXACT production log_source_open() and host-test route decisions."""
from pathlib import Path
import subprocess, tempfile
root=Path(__file__).resolve().parents[2]
src=(root/'core/src/bt/ps5_vpad.c').read_text()
start=src.index('/* Experimental variant: a regular file opts in')
end=src.index('static void log_source_close',start)
subject=src[start:end]
assert 'GH5_KLOG_R8 direct /dev/klog' in subject
body=r'''
#define _DEFAULT_SOURCE 1
#include <assert.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <stdint.h>
#include <sys/stat.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <fcntl.h>
#include <unistd.h>
#include <errno.h>
static int g_log_close_uncertain, g_log_fd=-1, g_log_is_dev;
static int marker_kind=0, open_rc=71, fail_connect;
static int sockets, direct_opens, closes;
void log_line(const char *fmt, ...) {(void)fmt;}
int fake_socket(int family,int type,int proto) {(void)family;(void)type;(void)proto; ++sockets;return 31;}
int fake_connect(int fd,const struct sockaddr *addr,socklen_t len) {(void)fd;(void)addr;(void)len; if (fail_connect) { errno=ECONNREFUSED; return -1; } return 0;}
int fake_fcntl(int fd,int cmd,...) {(void)fd;(void)cmd;return 0;}
int fake_close(int fd) {(void)fd; ++closes;return 0;}
int fake_open(const char *path,int flags) {(void)flags; assert(!strcmp(path,"/dev/klog"));++direct_opens; if(open_rc < 0) errno=EBUSY;return open_rc;}
int fake_lstat(const char *path,struct stat *st) {
 assert(strstr(path,"gh5-klog-device.enable"));
 if (!marker_kind) {errno=ENOENT;return -1;}
 if (marker_kind==3){errno=EACCES;return -1;}
 memset(st,0,sizeof(*st));st->st_mode=(marker_kind==1?S_IFREG:S_IFDIR)|0600;return 0;
}
#define socket fake_socket
#define connect fake_connect
#define fcntl fake_fcntl
#define close fake_close
#define open fake_open
#define lstat fake_lstat
SUBJECT
#undef socket
#undef connect
#undef fcntl
#undef close
#undef open
#undef lstat
int main(void) {
    int fd;
    marker_kind=0;sockets=direct_opens=closes=0; fd=log_source_open();
    assert(fd==31 && sockets==1 && direct_opens==0 && !g_log_is_dev);
    g_log_fd=-1;
#if GC_GH5_TCP_ONLY
    fail_connect=1;marker_kind=0;direct_opens=sockets=closes=0;
    fd=log_source_open();
    assert(fd==-1 && sockets==1 && direct_opens==0 && closes==1);
    fail_connect=0;
#endif
#if GC_GH5_KLOG_DEV_OPTIN
    marker_kind=1;sockets=direct_opens=closes=0;
    fd=log_source_open();assert(fd==71 && sockets==0 && direct_opens==1 && g_log_is_dev);
    g_log_fd=-1;g_log_is_dev=0;
    marker_kind=2;sockets=direct_opens=0;
    fd=log_source_open();assert(fd==-1 && sockets==0 && direct_opens==0);
    marker_kind=3;sockets=direct_opens=0;
    fd=log_source_open();assert(fd==-1 && sockets==0 && direct_opens==0);
    marker_kind=1;open_rc=-1;sockets=direct_opens=0;
    fd=log_source_open();assert(fd==-1 && sockets==0 && direct_opens==1);
#endif
    return 0;
}
'''.replace('SUBJECT',subject)
with tempfile.TemporaryDirectory(prefix='vpad-r8-source-') as td:
    p=Path(td);(p/'t.c').write_text(body)
    for mode in (0,1):
        exe=p/f'test{mode}'
        subprocess.run(['cc','-std=c11','-D_DEFAULT_SOURCE=1','-Wall','-Wextra','-Werror','-DGC_GH5_KLOG_DEV_OPTIN='+str(mode),'-DGC_GH5_TCP_ONLY=1',str(p/'t.c'),'-o',str(exe)],check=True)
        subprocess.run([str(exe)],check=True)
print('PASS: extracted production TCP-only fallback, opt-in compatibility, bad marker, denied marker and direct open failure')
