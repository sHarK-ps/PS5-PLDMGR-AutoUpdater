#!/usr/bin/env python3
"""Exercise deploy validation and configured addresses without opening sockets."""
from contextlib import redirect_stdout
from io import StringIO
import json
import os
from pathlib import Path
import runpy
import tempfile
import unittest
from unittest.mock import patch

tools = Path(__file__).resolve().parents[1]
app = runpy.run_path(str(tools / 'deploy-app.py'))
core = runpy.run_path(str(tools / 'deploy-core.py'))


class DeploymentValidation(unittest.TestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        self.root = Path(temporary.name)
        self.dist = self.root / 'PPSA12345'
        self.param = self.dist / 'sce_sys' / 'param.json'
        self.param.parent.mkdir(parents=True)
        self.identity = {'titleId': self.dist.name, 'conceptId': '12345',
                         'contentId': 'CONTENT-PPSA12345'}
        self.param.write_text(json.dumps(self.identity), encoding='utf-8')
        self.eboot = self.dist / 'eboot.bin'
        self.app_args = ['--host', 'console.example', '--dist', str(self.dist), '--dry-run']

    def test_missing_and_empty_eboot_rejected_in_dry_run(self):
        with patch.object(app['ftplib'], 'FTP') as ftp, redirect_stdout(StringIO()):
            with self.assertRaisesRegex(SystemExit, 'eboot.bin'):
                app['main'](self.app_args)
            self.eboot.touch()
            with self.assertRaisesRegex(SystemExit, 'eboot.bin'):
                app['main'](self.app_args)
            ftp.assert_not_called()

    def test_param_json_shape_and_fields(self):
        self.eboot.write_bytes(b'artifact')
        cases = [(None, 'object'), ({**self.identity, 'titleId': 12345}, 'titleId'),
                 ({**self.identity, 'conceptId': 12345}, 'conceptId'),
                 ({**self.identity, 'contentId': ['PPSA12345']}, 'contentId')]
        with patch.object(app['ftplib'], 'FTP') as ftp, redirect_stdout(StringIO()):
            for value, message in cases:
                with self.subTest(value=value), self.assertRaisesRegex(SystemExit, message):
                    self.param.write_text(json.dumps(value), encoding='utf-8')
                    app['main'](self.app_args)
            ftp.assert_not_called()

    def test_app_uses_environment_host_for_dry_run(self):
        self.eboot.write_bytes(b'artifact')
        output = StringIO()
        with patch.dict(os.environ, {'PS5_HOST': 'console.example'}, clear=True), \
             patch.object(app['ftplib'], 'FTP') as ftp, redirect_stdout(output):
            self.assertEqual(app['main'](['--dist', str(self.dist), '--dry-run']), 0)
            ftp.assert_not_called()
        self.assertIn('ftp://console.example:', output.getvalue())

    def test_core_rejects_empty_input_before_socket(self):
        artifact = self.root / 'empty.elf'
        artifact.touch()
        with patch.object(core['socket'], 'socket') as factory, redirect_stdout(StringIO()):
            with self.assertRaisesRegex(SystemExit, 'empty'):
                core['main'](['--host', 'console.example', '--file', str(artifact)])
            factory.assert_not_called()

    def test_core_host_and_opt_in_bind(self):
        artifact = self.root / 'sample.elf'
        artifact.write_bytes(b'artifact')
        output = StringIO()
        with patch.dict(os.environ, {'PS5_HOST': 'console.example'}, clear=True), \
             patch.object(core['socket'], 'socket') as factory, redirect_stdout(output):
            sock = factory.return_value
            sock.recv.return_value = b''
            self.assertEqual(core['main'](['--file', str(artifact)]), 0)
            sock.bind.assert_not_called()
            sock.connect.assert_called_once_with(('console.example', 9021))
            sock.reset_mock()
            self.assertEqual(core['main'](['--file', str(artifact), '--host',
                                          'explicit.example', '--bind', '192.0.2.1']), 0)
            sock.bind.assert_called_once_with(('192.0.2.1', 0))
            sock.connect.assert_called_once_with(('explicit.example', 9021))


if __name__ == '__main__':
    unittest.main()
