#!/usr/bin/env python3
"""Run the actual identification decision with a simulated log reader."""
from pathlib import Path
import subprocess
import tempfile

root = Path(__file__).resolve().parents[2]
source = (root / "core/src/bt/ps5_vpad.c").read_text()
start = source.index("static void finish_identification(")
subject = source[start:source.index("void vpad_poll(", start)]
call = "finish_identification(now, drained)" if "int drained" in subject else "finish_identification(now)"

harness = r"""
#include <assert.h>
#include <errno.h>
#include <stdint.h>
#include <string.h>
#include "vpad_klog_evidence_r8.h"
#include "vpad_tcp_health_r10.h"

#define T_IDENTIFY 3000
#define T_AMBIGUITY 300
#define GC_VPAD_TEST_TRACE 0
enum { VP_PENDING, VP_UNCERTAIN, VP_DELETE_FAILED, VP_READY };
typedef struct {
    int st, remove_when_found;
    uint64_t dev;
    int32_t handle;
} vslot;

static vslot g_slot[1];
static int g_pending, g_matches, g_log_is_dev, g_log_eof, g_log_read_errno;
static int g_line_overflow;
static size_t g_line_len;
static uint64_t g_match_dev, g_log_bytes, g_log_lines, g_log_device_added, g_log_mbus_events, g_pre_bytes;
static long g_t_add, g_t_match, g_log_first_byte_ms, g_log_last_byte_ms, g_preflight_elapsed_ms;
static int32_t g_add_result, g_user;
static unsigned binds, deletes;
static void log_line(const char *format, ...) { (void)format; }
static void log_source_close(void) { g_line_len = 0; g_line_overflow = 0; }
static int32_t g_bind(uint64_t device, int32_t user)
{
    (void)device; (void)user; ++binds; return 0;
}
static int32_t scePadVirtualDeviceDeleteDevice(int32_t handle)
{
    (void)handle; ++deletes; return 0;
}

SUBJECT

static void reset(void)
{
    g_pending = 0;
    g_matches = 1;
    g_match_dev = 0x111;
    g_t_add = 1000;
    g_t_match = 1100;
    g_log_eof = g_log_read_errno = g_line_overflow = 0;
    g_line_len = 0;
    g_slot[0].st = VP_PENDING;
    binds = deletes = 0;
}
static void poll_decision(long now, int drained)
{
    (void)drained;
    CALL;
}
static void assert_untouched(void)
{
    assert(g_slot[0].st == VP_UNCERTAIN && binds == 0 && deletes == 0);
}
int main(void)
{
    reset();
    poll_decision(1400, 1);
    assert(g_slot[0].st == VP_READY && binds == 1);

    reset();
    g_log_eof = 1;
    poll_decision(4000, 0);
    assert_untouched();

    reset();
    g_log_read_errno = EIO;
    poll_decision(4000, 0);
    assert_untouched();

    reset();
    poll_decision(1400, 0);
    assert(g_slot[0].st == VP_PENDING && binds == 0);
    poll_decision(1500, 1);
    assert(g_slot[0].st == VP_READY && binds == 1);

    reset();
    g_line_len = 8;
    poll_decision(4000, 1);
    assert_untouched();

    reset();
    poll_decision(4000, 0);
    assert_untouched();
    return 0;
}
"""

with tempfile.TemporaryDirectory() as directory:
    path = Path(directory)
    (path / "test.c").write_text(harness.replace("SUBJECT", subject).replace("CALL", call))
    subprocess.run(["cc", "-std=c11", "-Wall", "-Wextra", "-Werror",
                    "-I", str(root / "core/src/bt"), "test.c", "-o", "test"],
                   cwd=path, check=True)
    subprocess.run([str(path / "test")], cwd=path, check=True)
print("PASS: incomplete log input cannot confirm a virtual-device identity")
