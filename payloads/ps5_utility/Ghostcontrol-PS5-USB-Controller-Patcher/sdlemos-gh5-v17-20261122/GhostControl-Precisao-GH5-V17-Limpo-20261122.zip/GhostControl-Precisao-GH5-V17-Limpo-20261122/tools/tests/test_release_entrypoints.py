#!/usr/bin/env python3
"""Check exported GH5 build/test routing without compiling or deploying."""
import os
from pathlib import Path
import subprocess
import unittest


ROOT = Path(__file__).resolve().parents[2]


class ReleaseEntrypoints(unittest.TestCase):
    def make(self, *args, directory=ROOT):
        environment = os.environ.copy()
        for name in ("MAKEFLAGS", "MFLAGS", "MAKEOVERRIDES"):
            environment.pop(name, None)
        return subprocess.run(
            ["make", "--no-print-directory", *args], cwd=directory,
            capture_output=True, env=environment, text=True,
        )

    def test_core_uses_gh5_build(self):
        result = self.make("-n", "core")
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertIn("bash ../build_elf.sh", result.stdout)

    def test_test_runs_local_suite(self):
        result = self.make("-n", "test")
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertIn("bash ../run_host_tests.sh", result.stdout)
        self.assertNotIn("-C ui test", result.stdout)

    def test_core_declines_unsupported_native_deploy(self):
        result = self.make("deploy", directory=ROOT / "core")
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("unavailable in the GH5 bundle", result.stderr)


if __name__ == "__main__":
    unittest.main()
