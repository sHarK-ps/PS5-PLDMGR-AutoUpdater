#!/usr/bin/env python3
"""R8: production classification header and opt-in switch contracts (host)."""
from pathlib import Path
import subprocess, tempfile
root = Path(__file__).resolve().parents[2]
source = (root/'core/src/bt/ps5_vpad.c').read_text()
make = (root/'GhosttoothAPI/Makefile').read_text()
assert 'GH5_KLOG_R8 evidence=' in source
assert 'first_byte_delay_ms=' in source and 'last_byte_age_ms=' in source
assert 'gc_vpad_klog_evidence(' in source
assert 'GH5_KLOG_R8 direct marker' in source
assert 'no TCP fallback, no AddDevice' in source
assert 'gh5-klog-device.enable' in source
assert 'GC_GH5_KLOG_R8=1' in make
if 'GH5_PRECISION_DIAGNOSTIC' in make and 'GH5_KLOG_DEV_OPTIN=1' in make:
    assert 'VARIANT_CFLAGS := -DGC_GH5_USB_DIAGNOSTIC=1 -DGC_GH5_PRECISION_DIAGNOSTIC=1 -DGC_GH5_KLOG_DEV_OPTIN=1' in make
else:
    assert '-DGC_GH5_KLOG_DEV_OPTIN=1' not in make
body = r"""
#include <assert.h>
#include <string.h>
#include "bt/vpad_klog_evidence_r8.h"
int main(void) {
  assert(gc_vpad_klog_evidence(0,0,0,0,0,0) == GC_VPAD_KLOG_SILENT);
  assert(gc_vpad_klog_evidence(1,0,0,0,0,0) == GC_VPAD_KLOG_PARTIAL_LINE);
  assert(gc_vpad_klog_evidence(4,1,0,0,0,0) == GC_VPAD_KLOG_TRAFFIC_NO_DEVICE_EVENT);
  assert(gc_vpad_klog_evidence(4,1,1,0,0,0) == GC_VPAD_KLOG_EVENT_UNMATCHED);
  assert(gc_vpad_klog_evidence(4,1,1,2,0,0) == GC_VPAD_KLOG_EVENT_AMBIGUOUS);
  assert(gc_vpad_klog_evidence(4,1,1,1,0,0) == GC_VPAD_KLOG_ONE_CANDIDATE);
  assert(gc_vpad_klog_evidence(0,0,0,0,1,0) == GC_VPAD_KLOG_EOF);
  assert(gc_vpad_klog_evidence(0,0,0,0,0,5) == GC_VPAD_KLOG_READ_ERROR);
  assert(strcmp(gc_vpad_klog_evidence_name(GC_VPAD_KLOG_SILENT),"SILENT")==0);
  return 0;
}
"""
with tempfile.TemporaryDirectory(prefix='gh5-r8-') as td:
    c=Path(td)/'t.c';c.write_text(body)
    exe=Path(td)/'test'
    subprocess.run(['cc','-std=c11','-Wall','-Wextra','-Werror','-I',str(root/'core/src'),str(c),'-o',str(exe)],check=True)
    subprocess.run([str(exe)],check=True)
print('PASS: real production R8 klog classification and variant gates')
