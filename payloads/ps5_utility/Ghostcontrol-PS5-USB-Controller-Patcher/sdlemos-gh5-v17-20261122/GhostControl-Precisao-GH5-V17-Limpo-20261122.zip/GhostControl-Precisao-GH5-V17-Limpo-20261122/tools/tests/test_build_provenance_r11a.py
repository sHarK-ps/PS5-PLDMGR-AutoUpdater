from pathlib import Path
import sys
root = Path(__file__).resolve().parents[2]
variant = 'conservador' if 'Conservador' in str(root) else 'precisao'
mk=(root/'GhosttoothAPI/Makefile').read_text()
assert 'GH5-PROBE-V17-20261122' in mk
assert f'GH5-V17-{variant}-source-bundle' in mk
print('PASS V17 build provenance',variant)
