#!/usr/bin/env python3
'''Compile/run the integrated production GET_REPORT block with a fake clock/USB.
This is a focused host regression, NOT a PS5 SDK or console validation.
'''
from pathlib import Path
import os, shlex, subprocess, tempfile
root = Path(__file__).resolve().parents[2]
source = (root / 'core/src/gc_service_inject.c').read_text()
start = source.index('        /* PR #29 bbf6e42:')
end = source.index('        if (!feed->busy)', start)
block = source[start:end]
harness = r'''
#include <assert.h>
#include <stdint.h>
#include <stddef.h>
#include <string.h>
#include <errno.h>
#include <stdarg.h>
#include "gc_usb_fallback.h"
#include "gc_gh5_mode.h"
#define USB_SLOTS 2
#define USB_REPORT 64
#define GC_USB_INTERFACE_HID 1
#define USB_SHORT_XFER_OK 1
#define USB_DO_REQUEST 1
#define USETW(field, value) ((field) = (value))
typedef struct { unsigned report; } Field;
typedef struct { int numbered; unsigned count; Field fields[1]; } Layout;
typedef struct { int kind, interface_number; uint16_t vid, pid; Layout layout; char path[32]; } Device;
typedef struct { int buttons; } pad_state;
typedef struct { int fd, slot, busy; uint32_t lenp; char path[32];
                 uint8_t report[64]; GcUsbFallback fallback; } Feed;
static int calls, decode_ok, zero_reply, request_ok = 1, cached_reports;
static uint64_t clock_ms;
struct usb_ctl_request { void *ucr_data; int ucr_flags, ucr_actlen;
    struct { unsigned bmRequestType, bRequest, wValue, wIndex, wLength; } ucr_request; };
uint64_t gc_fallback_now_ms(void) { return clock_ms; }
static void source_snapshot_lock(void) {}
static void source_snapshot_unlock(void) {}
static void log_line(const char *fmt, ...) {
    va_list args;
    va_start(args, fmt);
    (void)va_arg(args, const char *);
    (void)va_arg(args, unsigned);
    const int result = va_arg(args, int);
    (void)va_arg(args, int);
    const int reported_errno = va_arg(args, int);
    va_end(args);
    assert(reported_errno == (result ? EIO : 0));
}
static void raw_sample(int slot, const void *data, unsigned length)
    { (void)slot; (void)data; (void)length; ++cached_reports; }
static int usb_decode_report(Feed *feed, const Device *device, pad_state *state,
    const uint8_t *data, uint32_t length, int from_control) {
    (void)feed; (void)device; (void)state; (void)from_control;
    assert(length == 3 && data[2] == 0x6f); return decode_ok;
}
static void remember(int slot, pad_state *state, unsigned vid, unsigned pid)
    { (void)slot; (void)state; (void)vid; (void)pid; }
static int ioctl(int fd, unsigned long command, struct usb_ctl_request *request) {
    (void)fd; (void)command; ++calls;
    assert(request->ucr_request.bmRequestType == 0xa1 && request->ucr_request.bRequest == 1);
    if (!request_ok) { errno = EIO; return -1; }
    errno = ENOENT; /* successful ioctl need not clear a previous error */
    request->ucr_actlen = 3;
    memcpy(request->ucr_data, zero_reply ? "\0\0\0" : "\0\0o", 3); return 0;
}
static void tick(Feed *feed) {
    const Device devices[1] = {{.kind=GC_USB_INTERFACE_HID}};
    unsigned i = 0; pad_state state = {0};
    do {
BLOCK
    } while (0);
}
int main(void) {
    Feed feed = {0}; feed.slot = 0;
    request_ok = decode_ok = 1;
    for (unsigned i=0; i<6; ++i) tick(&feed);
    assert(calls == 1 && cached_reports == 1);
    memset(&feed, 0, sizeof feed); calls = 0;
    for (unsigned i=0; i<30; ++i) {
        clock_ms = i*10; gc_usb_fallback_interrupt(&feed.fallback, clock_ms); tick(&feed);
    }
    assert(calls == 0); /* healthy interrupt traffic, RAW-only, no publication */
    memset(&feed, 0, sizeof feed); calls = 0; request_ok = 0;
    for (unsigned i=0; i<100; ++i) { clock_ms = i*10; tick(&feed); }
    assert(calls > 0 && calls <= 4);
    assert(feed.fallback.get_report_attempts == (unsigned)calls);
    assert(feed.fallback.get_report_failures == (unsigned)calls);
    memset(&feed, 0, sizeof feed); calls = 0; request_ok = decode_ok = 1;
    for (unsigned i=0; i<20; ++i) { clock_ms = 2000+i*10; tick(&feed); }
    assert(calls == 1 && feed.fallback.control_decoded);
    assert(feed.fallback.get_report_successes == 1);
    memset(&feed, 0, sizeof feed); calls = 0;
    for (unsigned i=0; i<6; ++i) { clock_ms = 3000+i*10; tick(&feed); }
    assert(calls == 1); /* the new connection cannot inherit prior success */
    memset(&feed, 0, sizeof feed); decode_ok = 0; calls = 0;
    cached_reports = 0;
    feed.busy = 1; feed.lenp = 64; memset(feed.report, 0xa5, sizeof feed.report);
    for (unsigned i=0; i<6; ++i) { clock_ms = 4000+i; tick(&feed); }
    assert(calls == 1 && feed.busy && feed.lenp == 64);
    assert(cached_reports == 0);
    for (unsigned i=0; i<sizeof feed.report; ++i) assert(feed.report[i] == 0xa5);
    memset(&feed, 0, sizeof feed); zero_reply = decode_ok = 1;
    for (unsigned i=0; i<6; ++i) { clock_ms = 5000+i; tick(&feed); }
    assert(feed.fallback.get_report_successes == 1 && !feed.fallback.control_decoded);
    zero_reply = 0;
    memset(&feed, 0, sizeof feed); decode_ok = 0; calls = 0;
    gc_usb_fallback_interrupt(&feed.fallback, 0);
    for (unsigned i=0; i<6; ++i) { clock_ms = 999; tick(&feed); }
    assert(calls == 0);
    for (unsigned i=0; i<6; ++i) { clock_ms = 1000+i; tick(&feed); }
    assert(calls == 1);
    return 0;
}
'''.replace('BLOCK', block)
with tempfile.TemporaryDirectory(prefix='ghostcontrol-fallback-') as directory:
    work = Path(directory)
    (work / 'test.c').write_text(harness)
    subprocess.run(shlex.split(os.environ.get('CC','cc')) + [
        '-std=c11','-Wall','-Wextra','-Werror','-I',str(root/'core/src'),
        str(work/'test.c'),'-o',str(work/'test')], check=True)
    subprocess.run([str(work/'test')], check=True)
print('PASS: host fallback gating, retry spacing, connection reset and interrupt buffer integrity')
