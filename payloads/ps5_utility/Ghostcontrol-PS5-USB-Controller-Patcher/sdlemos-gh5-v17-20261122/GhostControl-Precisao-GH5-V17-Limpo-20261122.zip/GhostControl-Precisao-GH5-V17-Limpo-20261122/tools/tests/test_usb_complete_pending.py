#!/usr/bin/env python3
"""Exercise the production COMPLETE error branch with simulated USB results."""
from pathlib import Path
import os
import subprocess
import tempfile

root = Path(__file__).resolve().parents[2]
source = (root / "core/src/gc_service_inject.c").read_text()
start = source.index("if (ioctl(feed->fd, USB_FS_COMPLETE, &done) != 0) {")
end = source.index("/* Nonzero transfer indices", start)
branch = source[start:end]

harness = r"""
#include <assert.h>
#include <errno.h>
#include <string.h>

#define USB_FS_COMPLETE 1
#define GC_GH5_PRECISION_DIAGNOSTIC 1

typedef struct {
    int fd, vid, pid, interface_number, in_ep, busy;
    unsigned lenp, in_xfer_len, trace_ebusy;
    const char *path;
    struct { unsigned nFrames, aFrames, status; } ep[1];
    struct { unsigned busy_returns, other_errors; } progress;
} UsbFeed;

static int fault_calls, failure_logs, pending_logs;
static int ioctl(int fd, int request, int *done)
{
    (void)fd; (void)request; (void)done;
    return -1;
}
static int usb_note_io(UsbFeed *feed, int err, int status, int invalid)
{
    (void)feed; (void)err; (void)status; (void)invalid;
    ++fault_calls;
    return 0;
}
static void log_line(const char *format, ...)
{
    if (strstr(format, "pending-snapshot")) ++pending_logs;
    if (strstr(format, "FS_COMPLETE failed")) ++failure_logs;
}
static void complete(UsbFeed *feed, int result)
{
    int done = 0, gh5_poll_revents = 0x41;
    errno = result;
    for (int cycle = 0; cycle < 1; ++cycle) {
        COMPLETE_BRANCH
    }
}
int main(void)
{
    UsbFeed feed = { .busy = 1, .vid = 0x12ba, .pid = 0x0100 };
    complete(&feed, EBUSY);
    assert(feed.busy == 1 && feed.progress.busy_returns == 1);
    assert(feed.trace_ebusy == 1 && feed.progress.other_errors == 0);
    assert(pending_logs == 1 && failure_logs == 0 && fault_calls == 0);

    complete(&feed, ENODEV);
    assert(feed.progress.other_errors == 1 && feed.progress.busy_returns == 1);
    assert(pending_logs == 1 && failure_logs == 1 && fault_calls == 1);
    return 0;
}
"""

with tempfile.TemporaryDirectory() as directory:
    work = Path(directory)
    (work / "test.c").write_text(harness.replace("COMPLETE_BRANCH", branch))
    subprocess.run([os.environ.get("CC", "cc"), "-std=c11", "-Wall", "-Wextra",
                    "-Werror", "test.c", "-o", "test"], cwd=work, check=True)
    subprocess.run([str(work / "test")], cwd=work, check=True)

print("PASS: USB COMPLETE EBUSY remains pending and real errors are reported")
