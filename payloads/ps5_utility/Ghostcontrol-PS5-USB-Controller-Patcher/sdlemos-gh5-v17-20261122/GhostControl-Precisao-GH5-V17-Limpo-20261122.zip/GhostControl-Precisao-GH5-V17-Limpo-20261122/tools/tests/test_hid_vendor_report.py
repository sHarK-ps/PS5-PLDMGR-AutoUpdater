#!/usr/bin/env python3
from pathlib import Path
import subprocess
import tempfile

root = Path(__file__).resolve().parents[2]
source = root / 'core' / 'src'
harness = r'''
#include "gc_hid.h"
#include <assert.h>
#include <string.h>

int main(int argc, char **argv)
{
    const uint8_t descriptor[] = {
        0x06, 0x00, 0xff, 0x09, 1, 0xa1, 1,
        0x85, 1, 0x15, 0, 0x25, 1, 0x75, 1, 0x95, 1, 0x09, 1, 0x81, 2,
        0x75, 7, 0x81, 3,
        0x25, 7, 0x75, 4, 0x09, 2, 0x81, 0x42,
        0x85, 2, 0x25, 0xff, 0x75, 8, 0x09, 3, 0x81, 2, 0xc0,
    };
    GcHidLayout layout;
    assert(gc_hid_parse_descriptor(descriptor, sizeof descriptor, &layout) == 0);
    assert(layout.numbered && layout.count == 0 && layout.raw_count == 3);
    ScePadData pad;
    memset(&pad, 0, sizeof pad);
    pad.buttons = SCE_PAD_BUTTON_CIRCLE;
    assert(argc == 2);
    if (strcmp(argv[1], "truncated") == 0) {
        const uint8_t truncated[] = {1, 1};
        assert(gc_hid_input(&layout, truncated, sizeof truncated, &pad) == 0);
        assert(pad.buttons == SCE_PAD_BUTTON_CIRCLE);
        return 0;
    }
    const uint8_t up[] = {1, 1, 0};
    const uint8_t right[] = {1, 1, 2};
    const uint8_t center[] = {1, 1, 15};
    const uint8_t axis[] = {2, 99};
    const uint32_t other_buttons = SCE_PAD_BUTTON_CROSS | SCE_PAD_BUTTON_CIRCLE;
    assert(gc_hid_input(&layout, up, sizeof up, &pad));
    assert(pad.buttons == (other_buttons | SCE_PAD_BUTTON_UP));
    assert(gc_hid_input(&layout, right, sizeof right, &pad));
    assert(pad.buttons == (other_buttons | SCE_PAD_BUTTON_RIGHT));
    assert(gc_hid_input(&layout, axis, sizeof axis, &pad));
    assert(pad.leftStick.x == 99);
    assert(pad.buttons == (other_buttons | SCE_PAD_BUTTON_RIGHT));
    assert(gc_hid_input(&layout, center, sizeof center, &pad));
    assert(pad.buttons == other_buttons);
    return 0;
}
'''

with tempfile.TemporaryDirectory(prefix='gc-hid-vendor-') as directory:
    work = Path(directory)
    test = work / 'vendor_report.c'
    binary = work / 'vendor_report'
    test.write_text(harness)
    subprocess.run(['cc', '-std=c11', '-Wall', '-Wextra', '-Werror',
                    '-ffunction-sections', '-fdata-sections', '-I', str(source),
                    str(test), str(source / 'gc_hid.c'), str(source / 'gc_profile.c'),
                    '-Wl,--gc-sections', '-lm', '-o', str(binary)], check=True)
    failed = [scenario for scenario in ('truncated', 'hat')
              if subprocess.run([str(binary), scenario], cwd=work).returncode]
    assert not failed, f'Vendor HID regression(s): {failed}'

print('PASS: vendor HID reports preserve cache on truncation and replace D-pad directions')
