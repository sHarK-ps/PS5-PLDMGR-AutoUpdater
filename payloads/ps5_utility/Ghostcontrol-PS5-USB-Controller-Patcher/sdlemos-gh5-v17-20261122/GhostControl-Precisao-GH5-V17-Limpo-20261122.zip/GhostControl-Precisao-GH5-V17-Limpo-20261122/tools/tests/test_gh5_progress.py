#!/usr/bin/env python3
"""Host compiler regression for pure production GH5 progress accounting helper;
source-structure checks verify both transport call sites use it.
This is not a PS5 or production integration run.
"""
from pathlib import Path
import subprocess
import tempfile

root=Path(__file__).resolve().parents[2]
header=root/'core/src/gc_usb_progress.h'
source=(root/'core/src/gc_service_inject.c').read_text()
assert source.count('gc_usb_progress_account(&feed->progress, gh5_diagnostic_input, decoded_ok);')==1
assert 'raw_only_skipped=%llu neutral_probe_frames=%llu' in source
assert 'gh5_diagnostic_input = feed->vid == 0x12ba && feed->pid == 0x0100;' in source
harness=r'''
#include <stdint.h>
#include <assert.h>
#include "gc_usb_progress.h"
int main(void){
    GcUsbProgress p={0};
    for(int i=0;i<30;i++) gc_usb_progress_account(&p,1,0);
    assert(p.raw_only_skipped==30 && p.rejected==0 && p.decoded==0);
    for(int i=0;i<4;i++) gc_usb_progress_account(&p,1,1);
    assert(p.neutral_probe_frames==4 && p.decoded==0);
    gc_usb_progress_account(&p,0,0);
    gc_usb_progress_account(&p,0,1);
    assert(p.rejected==1 && p.decoded==1);
    assert(p.raw_only_skipped==30 && p.neutral_probe_frames==4);
    return 0;
}
'''
with tempfile.TemporaryDirectory(prefix='gh5-progress-') as t:
 p=Path(t); (p/'t.c').write_text(harness)
 subprocess.run(['cc','-std=c11','-Wall','-Wextra','-Werror',f'-I{header.parent}',str(p/'t.c'),'-o',str(p/'test')],check=True)
 subprocess.run([str(p/'test')],check=True)
print('PASS: production GH5 progress accounting helper, RAW/neutral/decoded/rejected isolation')
