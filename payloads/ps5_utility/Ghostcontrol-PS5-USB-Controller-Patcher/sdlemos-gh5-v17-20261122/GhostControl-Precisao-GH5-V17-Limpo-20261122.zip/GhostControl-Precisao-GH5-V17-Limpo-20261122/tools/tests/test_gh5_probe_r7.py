#!/usr/bin/env python3
'R7: compile/exercise the real marker-probe header against filesystem changes.'
from pathlib import Path
import os, shlex, subprocess, tempfile
root = Path(__file__).resolve().parents[2]
service = (root/'core/src/gc_service_inject.c').read_text()
make = (root/'GhosttoothAPI/Makefile').read_text()
assert '#include "gc_gh5_probe.h"' in service
assert 'gc_gh5_probe_step(' in service
assert 'GC_GH5_PROBE_PATH_TRACE=' in make
assert 'gh5: R7 marker check' in service
assert 'GH5-PROBE-V17-20261122' in make
assert 'gh5_vpad_probe_enabled()' in service
harness = r'''
#include <assert.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/stat.h>
#include "gc_gh5_probe.h"
int main(int argc, char **argv) {
 assert(argc==2);
 char path[1024];
 assert(snprintf(path,sizeof path,"%s/gh5-vpad-probe.enable",argv[1]) > 0);
 GcGh5ProbeState s={0};
 GcGh5ProbeObservation x=gc_gh5_probe_step(&s,path,10000);
 assert(x.checked&&x.report && !s.enabled && x.status==GC_GH5_MARKER_MISSING && x.error==ENOENT);
 x=gc_gh5_probe_step(&s,path,10500);
 assert(!x.checked&&!s.enabled);
 /* Directory with the marker name must not enable the test. */
 assert(mkdir(path,0700)==0);
 x=gc_gh5_probe_step(&s,path,11000);
 assert(x.checked && x.report && x.status==GC_GH5_MARKER_NOT_FILE && !s.enabled);
 assert(rmdir(path)==0);
 /* A 0-byte file enables VDA (it is a filesystem marker). */
 FILE *f=fopen(path,"wb"); assert(f); assert(fclose(f)==0);
 x=gc_gh5_probe_step(&s,path,12000);
 assert(x.checked && x.report && x.status==GC_GH5_MARKER_ENABLED && s.enabled && x.file_size==0);
 assert(unlink(path)==0);
 x=gc_gh5_probe_step(&s,path,60000);
 assert(!x.checked && s.enabled && x.status==GC_GH5_MARKER_ENABLED); /* sticky */
 /* A text-content marker is equally valid in a new process. */
 GcGh5ProbeState new_s={0};
 f=fopen(path,"wb");assert(f);assert(fputs("probe enabled\n",f)>0);assert(fclose(f)==0);
 x=gc_gh5_probe_step(&new_s,path,0);
 assert(x.checked&&x.report&&new_s.enabled&&x.file_size>0);
 assert(unlink(path)==0);
 /* Silent misses should report once/15 seconds (not once per packet). */
 GcGh5ProbeState missing={0};
 x=gc_gh5_probe_step(&missing,path,1000);assert(x.report);
 x=gc_gh5_probe_step(&missing,path,2000);assert(x.checked&&!x.report);
 x=gc_gh5_probe_step(&missing,path,16000);assert(x.checked&&x.report);
 return 0;
}
'''
with tempfile.TemporaryDirectory(prefix='gh5-r7-probe-') as td:
    p=Path(td)
    source=p/'probe.c';source.write_text(harness)
    exe=p/'probe'
    subprocess.run(shlex.split(os.environ.get('CC','cc'))+[
       '-std=c11','-D_DEFAULT_SOURCE','-Wall','-Wextra','-Werror',
       '-I'+str(root/'core/src'),str(source),'-o',str(exe)],check=True)
    subprocess.run([str(exe),str(p)],check=True)
print('PASS: R7 marker missing/recheck/non-regular/empty/text/sticky/rate-limited')
