#!/usr/bin/env python3
"""Check that the production USB and BT dispatch predicates respect quarantine."""
from pathlib import Path
import re
import subprocess
import tempfile

root = Path(__file__).resolve().parents[2]
source = (root / "core/src/gc_service_inject.c").read_text()
predicates = {
    transport: re.search(
        rf"\badd = (inject_ready && {transport}_owned\[slot\][^;]+);", source
    ).group(1)
    for transport in ("usb", "bt")
}

harness = r"""
#include <assert.h>

static int inject_ready = 1;
static int usb_owned[] = {1, 1};
static int bt_owned[] = {1, 1};
static int output_allowed[] = {1, 1};
static int last_valid[] = {1, 1};
static int backend_added[] = {0, 0};
static int want_add[] = {1, 1};
static long add_retry_at[] = {100, 100};
static int quarantined[] = {1, 0};

static int __attribute__((unused)) vpad_add_is_quarantined(int slot)
{
    return quarantined[slot];
}

static int usb_can_add(int slot, long now) { return USB_PREDICATE; }
static int bt_can_add(int slot, long now) { return BT_PREDICATE; }

int main(void)
{
    assert(!usb_can_add(0, 100) && !bt_can_add(0, 100));
    assert(usb_can_add(1, 100) && bt_can_add(1, 100));
    assert(!usb_can_add(1, 99) && !bt_can_add(1, 99));
    quarantined[0] = 0;
    assert(usb_can_add(0, 101) && bt_can_add(0, 101));
    output_allowed[0] = 0;
    assert(!usb_can_add(0, 101) && !bt_can_add(0, 101));
    return 0;
}
"""

for transport, predicate in predicates.items():
    harness = harness.replace(f"{transport.upper()}_PREDICATE", predicate)
with tempfile.TemporaryDirectory() as directory:
    work = Path(directory)
    (work / "test.c").write_text(harness)
    subprocess.run(["cc", "-std=c11", "-Wall", "-Wextra", "-Werror",
                    "test.c", "-o", "test"], cwd=work, check=True)
    subprocess.run([str(work / "test")], cwd=work, check=True)

print("PASS: quarantined USB/BT slots stay out of the virtual-pad add queue")
