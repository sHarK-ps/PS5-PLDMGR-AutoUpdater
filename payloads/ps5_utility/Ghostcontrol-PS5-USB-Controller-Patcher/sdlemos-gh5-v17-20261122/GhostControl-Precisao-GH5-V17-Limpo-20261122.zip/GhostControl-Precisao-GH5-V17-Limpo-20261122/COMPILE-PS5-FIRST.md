# Compilação — GhostControl GH5 V17 Limpa

```bash
export PS5_PAYLOAD_SDK=/caminho/do/ps5-payload-sdk
bash build_elf.sh
sha256sum -c ELF-SHA256.txt
```

`build_elf.sh` roda os testes locais e compila o serviço GH5 Mapeado, o serviço GH5 Precisão e o verificador `GhostControl-Klog-Check.elf`. O teste dos controles mapeados é feito no PS5.

Consulte `LEIA-PRIMEIRO-V17.md` para o resultado da análise e o teste com a guitarra.
