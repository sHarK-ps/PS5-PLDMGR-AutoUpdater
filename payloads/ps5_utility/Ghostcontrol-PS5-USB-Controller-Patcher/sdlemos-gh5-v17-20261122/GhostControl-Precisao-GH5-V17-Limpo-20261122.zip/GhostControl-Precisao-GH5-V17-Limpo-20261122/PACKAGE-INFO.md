# GhostControl GH5 — Precisao — PACKAGE-INFO R4

- Emissão local: 2026-11-14; tipo: fontes, não ELF.
- Árvore upstream main: `9b7023b44427bab7aaebeb8d0f1b3909cc19c420`.
- PR #29: `cd5807073ba6d6741bad232fbb33f618855a3632` 16 commits, OPEN; integração antiga preservada, auditoria do mantenedor pendente.
- PR #32: `d530b1b40509392589b6569de313bd80af4b94a4` 14 commits, OPEN; quatro novos commits adaptados, deduplicação do worker local.
- PR #33: `55bc1ae949953ffa7c65fe854e93a67e5109e138` 9 commits, OPEN; rollback local de falha db_forget preservado, recuperação inquiry pendente.
- PR #34: `4fcb1fb77d8fc001685b15878cfef37198f99f37` 3 commits, OPEN; parser de rumble novo incluído como OFF por padrão, sem prova de BT/ABI PS5 11.60.
- PR #35: `181426f33f7f7ffec9d932c5fb29caf9a6a531f4` 1 commit, OPEN; GC_UPDATE_API já incluído antes; não reaplicado.
- Natureza: integração local modificada, não merge de upstream; código em C + docs, teste host não é teste de console.
- Variante padrão: `gh5-precision`. Veja `README-ATUALIZACAO-20261114-R4.md`, `docs/PR29-PR32-PR33-PR34-PR35-AUDITORIA-R4.md`.
