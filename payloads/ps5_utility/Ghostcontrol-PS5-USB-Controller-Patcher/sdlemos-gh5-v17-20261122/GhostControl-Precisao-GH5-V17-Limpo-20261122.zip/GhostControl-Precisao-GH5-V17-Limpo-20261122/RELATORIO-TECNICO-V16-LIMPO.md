# Auditoria completa: GhostControl GH5 V12 → V16 original → V16 limpa

**Revisão:** 22 de novembro de 2026  
**Escopo:** código-fonte Precisão para a guitarra Guitar Hero 5 PS3 e PS5 FW 11.60  
**Bases:** ZIP Precisão V12 anterior ao Codex, ZIP Precisão V16 recebido e logs V16 enviados pelo proprietário  
**Método:** comparação byte a byte de 546 arquivos, revisão de diffs C/Python/Makefile e testes host. Sem acesso ao console nem ao histórico privado de conversas do Codex.

## 1. Resultado da comparação

| Verificação | Resultado |
| --- | ---: |
| Arquivos V12 | 522 |
| Arquivos V16 | 546 |
| Idênticos entre V12/V16 | 493 |
| Modificados | 29 |
| Adicionados | 24 |
| Excluídos | 0 |
| Histórico/ELFs/capturas separados da fonte limpa | 83 |
| Arquivos da V16 preservados na fonte limpa (antes dos novos docs) | 463 |

**Integridade:**
- V12 ZIP: `6a6070a6e0f13f7225c25cc4f4cee31b1e74b98a3da7a72e4cf3f4507598f5a1`.
- V16 ZIP: `fa231db225dc2100e64f97823ec66f85c1986dd05a8d623f85a179f7d9f8a0bc`.
- Os 321 arquivos com extensões de fonte/script identificados na V16 foram mantidos no pacote limpo.
- Os dois ELFs V16 originais **não** foram recompilados nem substituídos. Foram mantidos intactos no ZIP histórico, separados dos fontes para não sugerir uma compilação desta edição.
- Os comentários reescritos não alteram os tokens C executáveis. O teste do parser alterou apenas o marcador de extração, antes acoplado a um comentário.

## 2. O que mudou, por arquivo (29 modificados)

| Arquivo | Alteração identificada e finalidade |
| --- | --- |
| `COMPILE-PS5-FIRST.md` | Atualiza o procedimento de compilação e explicita os dois ELFs previstos. |
| `GhosttoothAPI/Makefile` | Valida variantes, atualiza a tag V16, expõe testes host e compila o ELF de teste de klog. |
| `Makefile` | Direciona os alvos principais para a árvore core e seus testes locais. |
| `SOURCE-TREE-SHA256.txt` | Inventário renovado para os arquivos do pacote original V16. |
| `build_elf.sh` | Testa a árvore e compila o ELF diagnóstico mais o verificador de klog. |
| `core/Makefile` | Redireciona alvos para build GH5; torna indisponíveis fluxos nativos anteriores. |
| `core/src/bt/ps5_vpad.c` | Endurece tokens MBus e enquadramento de linhas; adiciona quarentena e checagem de leitura drenada. |
| `core/src/bt/ps5_vpad.h` | Expõe consulta de quarentena para o despachante. |
| `core/src/gc_hid.c` | Valida campos de relatórios incompletos e corrige a atualização de direções no fallback HID. |
| `core/src/gc_service_inject.c` | Refina métricas USB, EBUSY, aceitação de control replies e bloqueio de filas de slots quarantined. |
| `core/src/gc_usb_progress.h` | Adiciona contadores de erro de endpoint, quadro rejeitado e amostras entre janelas. |
| `core/src/gc_vda_klog.c` | Exige nomes de eventos completos e IDs de usuário dentro de 32 bits no parser nativo. |
| `run_host_tests.sh` | Executa todos os scripts de teste e suítes host em sequência. |
| `tools/companion-manifest.py` | Restringe nomes reservados e colisões de avisos/artefatos antes de gravar manifesto. |
| `tools/deploy-app.py` | Valida a pasta de distribuição, identidade de título e eboot; aceita host por variável. |
| `tools/deploy-core.py` | Valida ELF não vazio e aceita endereço/bind por variável de ambiente. |
| `tools/diagnostics/LEIA-PRIMEIRO.md` | Documenta a coleta TCP e o teste do emissor. |
| `tools/diagnostics/probe_klogsrv.py` | Adiciona capturas por execução, busca de mensagem esperada, timeout robusto e códigos de saída. |
| `tools/diagnostics/tests/test_probe_klogsrv.py` | Amplia casos de transporte, silêncio, EOF, linhas e arquivos de captura. |
| `tools/tests/test_build_provenance_r11a.py` | Atualiza asserções de provenance para V16. |
| `tools/tests/test_gc_vda_klog_v12.py` | Acrescenta eventos malformados e IDs de usuário nos limites. |
| `tools/tests/test_gh5_modes.py` | Executa dry-run de build com rebuild forçado para conferir os flags. |
| `tools/tests/test_gh5_probe_r7.py` | Atualiza tag esperada da build. |
| `tools/tests/test_usb_fallback.py` | Acrescenta verificação de errno e do efeito do GET_REPORT no diagnóstico. |
| `tools/tests/test_vda_r6_trace.py` | Atualiza tag esperada da build. |
| `tools/tests/test_virtual_device.py` | Amplia casos de tokens MBus falsos ou com prefixos ilegais. |
| `tools/tests/test_vpad_add_param_r9.py` | Atualiza a revisão esperada na matriz de parâmetros. |
| `tools/tests/test_vpad_line_framing_r11.py` | Acrescenta regressão com NUL e linha válida subsequente. |
| `tools/tests/test_vpad_tcp_health_r10.py` | Atualiza tag e delimitação do recorte de função após mudança de assinatura. |

## 3. O que foi adicionado na V16 (24 arquivos)

| Arquivo | Finalidade |
| --- | --- |
| `ELF-SHA256.txt` | Hashes dos dois ELFs compilados no pacote original. |
| `GhosttoothAPI/GhostControl-Klog-Check.elf` | Verificador de escrita no kernel log, compilado na entrega original. |
| `GhosttoothAPI/GhosttoothAPI-GH5-precision.elf` | Compilação original V16 do serviço Precisão. |
| `LEIA-PRIMEIRO-V13.md` | Histórico técnico e testes de transição V12→V13. |
| `LEIA-PRIMEIRO-V14.md` | Histórico técnico e testes de transição V13→V14. |
| `LEIA-PRIMEIRO-V15.md` | Histórico técnico e testes de transição V14→V15. |
| `LEIA-PRIMEIRO-V16.md` | Histórico técnico e testes da V16 com o emissor klog. |
| `klogsrv-captures/20261122T190816Z-2ixp7593/klogsrv-capture.bin` | Captura TCP sem bytes. |
| `klogsrv-captures/20261122T190816Z-2ixp7593/klogsrv-summary.json` | Metadados da captura TCP silenciosa. |
| `klogsrv-captures/20261122T191647Z-7ttc8dm4/klogsrv-capture.bin` | Captura TCP sem bytes. |
| `klogsrv-captures/20261122T191647Z-7ttc8dm4/klogsrv-summary.json` | Metadados da segunda captura silenciosa. |
| `klogsrv-captures/20261122T194446Z-u21nl_6j/klogsrv-capture.bin` | Captura real com 24.314 bytes do kernel log. |
| `klogsrv-captures/20261122T194446Z-u21nl_6j/klogsrv-summary.json` | Estatísticas e hash da captura com dados. |
| `tools/diagnostics/klog-check.c` | Fonte do ELF de teste, que emite três mensagens GH5_KLOG_CHECK. |
| `tools/diagnostics/tests/test_klog_check.py` | Valida mensagens e separação da notificação do verificador. |
| `tools/tests/test_companion_build_options.py` | Testa rejeição de variantes e flags inválidos. |
| `tools/tests/test_deploy_validation.py` | Testa validações de deploy sem rede real. |
| `tools/tests/test_hid_vendor_report.py` | Testa relatório HID curto e atualização do D-pad. |
| `tools/tests/test_manifest_notice_names.py` | Testa nomes reservados no empacotamento. |
| `tools/tests/test_release_entrypoints.py` | Testa os novos alvos de Makefile. |
| `tools/tests/test_usb_complete_pending.py` | Regressão de USB_FS_COMPLETE com EBUSY. |
| `tools/tests/test_usb_complete_telemetry.py` | Regressão de contadores USB de endpoint e quadros. |
| `tools/tests/test_vpad_identification_input.py` | Simula conclusão da identificação com fontes incompletas. |
| `tools/tests/test_vpad_quarantine_dispatch.py` | Bloqueia tentativas de enfileirar slots em quarentena. |

Os 493 arquivos restantes não tiveram mudança de conteúdo entre os dois ZIPs. O inventário completo, com hashes de **todos os 546 caminhos**, acompanha a entrega em JSON; essa tabela inclui apenas diferenças.

## 4. O que a limpeza fez — sem alterar a lógica V16

- Encurtou comentários narrativos/históricos em `ps5_vpad.c`, `gc_service_inject.c`, `gc_hid.c`, `gc_vda_klog.c`, `ps5_vpad.h`, `klog-check.c` e `GhosttoothAPI/Makefile`.
- Conservou notas técnicas sobre quarentena, interface USB, truncamento de relatórios, log TCP e parâmetros VDA. Não retirou cabeçalhos de licença nem atribuiu autoria artificial a alguém.
- Substituiu o guia V16 e as instruções de compilação por textos objetivos e sem referências ao endereço IP privado do usuário.
- Corrigiu o teste `tools/tests/test_virtual_device.py` para delimitar seu recorte pelo início da próxima função C, e não pelo texto de um comentário. A lógica testada não mudou.
- Separou 83 arquivos históricos, capturas, hashes antigos e ELFs compilados em um ZIP próprio. Nenhum desses bytes foi apagado da entrega original; o histórico foi preservado sem alterações.
- Manteve fontes, testes, workflows CI, ativos de UI, licenças, headers e integrações anteriores. O pacote limpo segue sendo a variante Precisão V16, não uma nova build V17.

**Importante sobre autoria:** remover prosa desnecessária não reescreve o histórico de contribuição. Os créditos de terceiros, licenças GPL e commits existentes são preservados; o relatório descreve o trabalho verificável, sem inventar um autor.

## 5. Problemas e riscos encontrados

### P1 — Bloqueio confirmado do fluxo TCP na V16 — alto impacto
Em `core/src/bt/ps5_vpad.c`, `start_identification()` chama `log_source_read()` uma vez e considera um fragmento sem `\n` uma razão para fechar o socket e abortar **antes** de `AddDevice`. Nos logs V16 foram observadas **47 tentativas**, cada uma com **10 bytes e nenhuma linha completa**, produzindo 47 retries antes de `AddDevice`. O preflight de 750 ms nunca foi iniciado. **Causa imediata reproduzida; a correção funcional não faz parte deste pacote editorial.**

**Próxima correção proposta:** manter a conexão aberta e observar fragmentos entre ciclos do poll durante uma janela limitada; descartar eventos antigos/linhas binárias sem tomar fragmentação TCP por falha, e só autorizar `AddDevice` depois de um estado de sincronização comprovado. Exigir teste host RED→GREEN e dois ZIPs de correção separados.

### P2 — Evento legado MBus não reconhecido — médio
O parser exige `DEVICE_ADDED` no limite de palavra. `SCE_MBUS_EVENT_DEVICE_ADDED` contém sublinhado antes de `DEVICE_ADDED`, e portanto é descartado pelo filtro. A captura real do PC contém essa grafia legada e a moderna `event=DEVICE_ADDED` para o mesmo ID `0x7030d`. A moderna foi reconhecida no replay host. **Não usar esse ID no bind:** na V16 não houve `AddDevice` e não há origem correlacionada ao serviço.

### P3 — Proveniência incompleta no log local — médio
Os dez bytes iniciais lidos em cada conexão não foram registrados em hexadecimal. A captura independente do computador começa com a palavra ASCII `Successful` (dez bytes), mas isso é só correspondência plausível — não é prova de que o socket local recebeu aqueles mesmos bytes. A próxima instrumentação deve registrar um hash ou amostra curta do prefixo, com controle de privacidade.

### P4 — Discontinuidade de alvos de build — risco de integração
`core/Makefile` da V16 desabilita `app-service`, `deploy`, `release` e alguns alvos nativos, e redireciona `all` para o script GH5. Isso é aceitável para um pacote especializado, mas **não é compatível** com todo o fluxo de build/deploy da V12 original. A V16 limpa preserva esse comportamento; não deve ser mesclada às cegas ao upstream.

### P5 — Registro binário dentro da captura TCP — tratamento conservador
A captura útil contém NULs misturados aos registros. O parser V16 descarta linhas com bytes NUL ou tamanho excessivo; o replay anterior contabilizou 21 linhas descartadas e um fragmento final com overflow. Isso evita falso positivo, mas exige política explícita de resincronização antes de aceitar identidade virtual.

### P6 — Identidade do controle e retorno VDA ainda não confirmados — bloqueante
A captura PC de 19:44 UTC contém **24.314 bytes e 270 LF**, inclusive um único ID `0x7030d` apresentado em dois registros. Isso comprova transporte do kernel log em uma janela, **não** que a guitarra criou o dispositivo virtual. Os logs V16 não registraram `scePadVirtualDeviceAddDevice`, `bind` nem `InsertData`; a identidade permanece desconhecida. O valor `0x803B0006` é histórico de versões anteriores, não retorno desta sessão V16.

### P7 — Causa ambiental de klogsrv não isolada — hipótese
Remover outros homebrews antecedeu a captura bem-sucedida, mas não identifica qual processo causava a disputa/ausência de eventos. O teste de `GhostControl-Klog-Check.elf` com token correlacionável e captura simultânea continua necessário. Não inferir causalidade apenas da melhora temporal.

### P8 — Compilação e integridade de artefatos — limitação de validação
Os ELFs originais presentes no ZIP V16 têm SHA-256 `cf1630900510fc3a42f6ff2dc69207182655dccb2e7ba053f5295b4f26ceb96b` (serviço) e `f1945504819cbe7e9af85593094efcd1e75af598dcb61ea79b17063c2b7828cd` (klog check). Ambos ficam exclusivamente no ZIP histórico. **Não compilei nem executei novos ELFs** nesta edição. A limpeza editorial não comprova execução no PS5.

## 6. Comparação histórica: V12 → V13 → V14 → V15 → V16

| Marco | Mudança observada nos artefatos e notas fornecidos |
| --- | --- |
| V12 | Corrigiu validação dos tokens MBus e do leitor nativo, com TCP silencioso nos ensaios relatados. |
| V13 | Diferenciou `EBUSY` pendente de falha USB e separou estado neutro preparado de publicação VDA. |
| V14 | Bloqueou novos pedidos para slots em quarentena e melhorou o histórico de capturas. |
| V15 | Validou relatório HID completo, tokens MBus, NUL e controle de `errno`/`GET_REPORT`. |
| V16 | Telemetria USB, ferramentas de compilação/deploy, ELF de teste de klog e proteções de manifestos; deixou a falha pré-AddDevice com leitura parcial como bloqueio atual. |

A sequência V13–V15 foi reconstruída dos arquivos `LEIA-PRIMEIRO-V13/14/15.md` presentes no ZIP V16, não de commits publicados ou de um histórico privado do Codex. Esses documentos originais estão preservados no ZIP histórico.

## 7. GitHub e integrações

Em 22/11/2026, o `main` público do GhostControl original estava em `9b7023b44427bab7aaebeb8d0f1b3909cc19c420`. Os PRs #29, #32, #33, #34 e #35 permaneciam abertos. A conexão ao upstream concedia somente leitura, portanto nenhuma alteração foi publicada. Referências: [upstream](https://github.com/StonedModder/Ghostcontrol-PS5-USB-Controller-Patcher), [PR #29](https://github.com/StonedModder/Ghostcontrol-PS5-USB-Controller-Patcher/pull/29) e [klogsrv](https://github.com/ps5-payload-dev/klogsrv).

As integrações existentes foram preservadas na fonte limpa; os ZIPs não aplicam automaticamente novamente commits/PRs que já estejam incorporados. O fork do usuário é uma árvore Git separada, sem uma V16 publicada conferível neste pacote.

## 8. Testes executados nesta edição

- **37/37 scripts Python PASS**. Na execução combinada houve interrupção antes do último script; `test_probe_klogsrv.py` foi executado separadamente, com sucesso. Os outros 36 haviam passado na rodada sequencial.
- **USB/GIP C host PASS** com `make -B -C core/tests/usb test`, incluindo verificações de cache e recuperação.
- **Rumble C host PASS** com `make -B -C core/tests/rumble test` com sanitizadores (parser).
- **Sintaxe C PASS** para `host.c` e `le.c` com `-Werror`, e **sintaxe Bash PASS** para scripts de build e testes.
- **Equivalência de tokens verificada:** todos os arquivos de implementação editados em comentários mantiveram tokens C ou linhas executáveis de Makefile idênticos à V16 original.
- **Limitações:** sem SDK PS5/Prospero e sem validação física. Testes host não provam funcionamento do VDA, da guitarra no jogo ou do servidor klog sob OnionHEN.

## 9. Matriz: o que foi mantido e o que não foi alterado

| Componente | Decisão editorial | Risco residual |
| --- | --- | --- |
| USB/HID GH5 | Preservado integralmente; comentários simplificados | mapeamento no console ainda precisa confirmação |
| TCP 3232 e parser MBus | Preservado integralmente | preflight pode fechar com linha incompleta; evento legado com prefixo ignorado |
| `AddDevice` e `UNCERTAIN` | Preservados integralmente | nenhuma identidade V16 comprovada, não forçar bind/retry após chamada |
| Testes | Mantidos; um extrator desatrelado de comentário | suíte host não substitui o PS5 real |
| Deploy e Makefiles | Preservados integralmente | alvos nativos antigos do core desabilitados |
| ELF original | Arquivado sem modificação | não corresponde a uma recompilação da árvore limpa |
| Capturas e docs antigos | Arquivados sem modificação | podem conter endereços privados; não redistribuir publicamente sem revisão |

## 10. Conteúdo da entrega

**Pacote de fontes limpas:** mesma árvore de código V16, comentários técnicos condensados, testes, documentação de uso objetiva, nenhum ELF recompilado ou captura de sessão. Inclui `INVENTARIO-V16-LIMPO-SHA256.txt`, `PATCH-COMENTARIOS-V16-ORIGINAL.diff` e `COMPARACAO-INVENTARIO-V12-V16.json`.

**Pacote histórico original:** todos os 83 arquivos deslocados, preservados byte a byte e sem alterações (ELFs, capturas, análises e manifests obsoletos). Não é necessário para rodar os testes host do pacote limpo.

**Critério para próxima versão funcional:** corrigir a coleta TCP com TDD e teste de fragmentação 10 bytes sem `\n`, validar fluxo real e somente então retomar `AddDevice`; gerar fontes Conservador/Precisão separadas se houver alteração funcional.

