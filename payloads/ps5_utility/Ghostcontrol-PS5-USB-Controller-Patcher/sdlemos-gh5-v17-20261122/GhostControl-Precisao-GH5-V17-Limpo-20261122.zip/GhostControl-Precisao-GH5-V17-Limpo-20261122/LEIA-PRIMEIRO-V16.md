# GhostControl GH5 Precisão V16

Este pacote contém os fontes da variante Precisão V16 e ferramentas para diagnosticar a leitura USB/HID e o transporte TCP do klogsrv.

## Testes locais

```bash
bash run_host_tests.sh
```

## Compilação no SDK do PS5

```bash
export PS5_PAYLOAD_SDK=/caminho/do/ps5-payload-sdk
bash build_elf.sh
```

O build produz `GhosttoothAPI/GhosttoothAPI-GH5-precision.elf` e `GhosttoothAPI/GhostControl-Klog-Check.elf`. O arquivo `ELF-SHA256.txt` é gerado nesse momento. O pacote limpo não distribui os binários da V16 original; a auditoria conserva os seus hashes.

## Coleta de log

Com o klogsrv ativo no PS5, no computador:

```bash
python3 tools/diagnostics/probe_klogsrv.py IP_DO_PS5 --seconds 30
```

Para um teste identificável de ponta a ponta, use `--expect-text GH5_KLOG_CHECK` e execute o ELF `GhostControl-Klog-Check.elf` na mesma janela de captura. Não execute dois serviços de teste da guitarra simultaneamente.

## Estado conhecido

- A entrada USB do dongle `12BA:0100` foi observada nos logs V16.
- A captura independente do PC recebeu 24.314 bytes do klogsrv.
- No serviço V16, um fragmento inicial de dez bytes sem `\n` interrompe a identificação antes de `AddDevice`. O código permanece inalterado nesta edição de limpeza.
- Não existe confirmação de `bind`, `InsertData` ou gameplay.

O histórico técnico, os erros observados e as diferenças V12→V16 estão no relatório que acompanha esta entrega.
