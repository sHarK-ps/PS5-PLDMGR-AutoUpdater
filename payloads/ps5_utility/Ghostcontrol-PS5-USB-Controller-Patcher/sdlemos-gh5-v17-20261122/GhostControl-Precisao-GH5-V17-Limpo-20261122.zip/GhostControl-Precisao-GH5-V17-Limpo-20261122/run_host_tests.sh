#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
for test_file in tools/tests/test_*.py tools/diagnostics/tests/test_*.py; do
  python3 -B "$test_file"
done
make -B -C core/tests/usb test
make -B -C core/tests/rumble test
cc -std=c11 -D_DEFAULT_SOURCE -Wall -Wextra -Werror -fsyntax-only core/src/bt/host.c core/src/bt/le.c
bash -n build_elf.sh
bash -n run_host_tests.sh
echo "PASS host checks; NÃO valida firmware, compilação ELF ou controle real"
