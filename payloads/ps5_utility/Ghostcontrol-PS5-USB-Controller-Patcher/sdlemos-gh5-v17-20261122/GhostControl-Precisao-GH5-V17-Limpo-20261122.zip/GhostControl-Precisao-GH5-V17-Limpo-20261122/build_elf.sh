#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
: "${PS5_PAYLOAD_SDK:?Defina PS5_PAYLOAD_SDK para seu SDK PS5/Prospero instalado}"
if [[ ! -f "$PS5_PAYLOAD_SDK/toolchain/prospero.mk" ]]; then
  echo "Arquivo SDK não encontrado: $PS5_PAYLOAD_SDK/toolchain/prospero.mk" >&2
  exit 2
fi
bash run_host_tests.sh
make -C GhosttoothAPI clean VARIANT=gh5-precision
make -C GhosttoothAPI VARIANT=gh5-precision all klog-check
make -C GhosttoothAPI clean VARIANT=gh5-mapped
make -C GhosttoothAPI VARIANT=gh5-mapped all
artifacts=(
  GhosttoothAPI/GhosttoothAPI-GH5-precision.elf
  GhosttoothAPI/GhosttoothAPI-gh5-mapped.elf
  GhosttoothAPI/GhostControl-Klog-Check.elf
)
for elf in "${artifacts[@]}"; do
  if [[ ! -s "$elf" ]]; then
    echo "ELF não foi gerado: $elf" >&2
    exit 3
  fi
done
sha256sum "${artifacts[@]}" | tee ELF-SHA256.txt
