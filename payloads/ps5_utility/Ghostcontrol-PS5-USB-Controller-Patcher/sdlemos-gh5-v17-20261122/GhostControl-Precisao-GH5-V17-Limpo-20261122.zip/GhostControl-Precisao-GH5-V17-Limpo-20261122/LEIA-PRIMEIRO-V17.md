# GhostControl GH5 V17 Limpa — controle virtual e mapeamento

O fluxo de logs e a identificação do controle virtual funcionaram no novo teste da V16. O PS5 aceitou a primeira entrada virtual duas vezes, incluindo uma reconexão do receptor. A V16 Precisão enviava quadros neutros. A V17 Mapeada usa os estados decodificados da guitarra e ainda precisa ser testada em jogo.

## O que os dados confirmam

| Etapa | Evidência |
| --- | --- |
| Serviço de logs pelo PC | O binário da captura tem 46.762 bytes, 607 quebras de linha e SHA-256 igual ao registrado no JSON. As três mensagens `GH5_KLOG_CHECK 6b038430-100` estão presentes. |
| Primeira ligação no PS5 | `vpad.log`, linhas 166–179. `AddDevice` retornou `0x803B0006`. Chegou um `DEVICE_ADDED` para `0x6030d`. A vinculação retornou `0` e a primeira entrada foi aceita 426 ms após o retorno de `AddDevice`. |
| Reconexão | `vpad.log`, linhas 359 e 432–458. O serviço removeu o primeiro controle virtual. Na reconexão o evento identificou `0x8030d`, a vinculação retornou `0` e a primeira entrada foi aceita em 422 ms. |
| USB e decodificação | Os últimos contadores das duas gerações somaram 2.302 relatórios, com zero falhas de conclusão, erros de endpoint e rejeições de quadro. As 762 amostras brutas do arquivo passaram no decodificador HID e na atualização do estado físico no PC. Em 55 amostras havia bits de trastes ativos. |
| Serviço do aplicativo | O `app-service.log` registrou 746 respostas IPC. Os dois arquivos extraídos são idênticos às cópias no ZIP do teste. |

Neste console, `0x803B0006` antecedeu duas identificações bem-sucedidas. O estado `READY`, o evento correspondente e `first InsertData accepted` são as evidências da entrada virtual. O usuário relatou que a interferência cessou após resolver um conflito com outro homebrew. A captura comprova a volta do fluxo, e os dados disponíveis deixam a identidade do outro aplicativo em aberto.

## Falhas analisadas

- **Três conexões fechadas antes de `AddDevice`.** Na primeira, a V16 leu 8.192 bytes e chegou ao limite de uma passada, com 49 bytes de uma linha parcial. Na segunda havia uma linha parcial de 41 bytes. Na reconexão aconteceu novamente, com 35 bytes. Todos os casos tiveram zero erro de leitura e zero EOF. A V16 fechava o socket e entrava numa nova tentativa, mesmo quando bastava esperar o restante da linha.
- **A V17 mantém o mesmo socket na leitura inicial.** Cada passada continua limitada. A preparação conserva o mínimo de 750 ms e dá até 2,5 s para chegar a uma leitura drenada e a uma linha completa. Se o fluxo terminar, der erro ou continuar incompleto no prazo, a tentativa encerra antes de `AddDevice`. A regressão reproduziu o fechamento antecipado na V16 e passou na V17, incluindo os casos de prazo esgotado e EOF.
- **Trastes em jogo.** Os logs da V16 registram preparação de quadros neutros. A variante `gh5-mapped` da V17 usa os controles decodificados e aplica a mesma leitura TCP corrigida. O serviço libera a fila para nova tentativa apenas quando a falha ocorreu antes da chamada a `AddDevice`.
- **Outras mensagens.** O USB prosseguiu após as duas recusas do pedido `SET_IDLE`. Os avisos de `PFAuthClient` apareceram numa captura que entregou as três mensagens de verificação. Esses avisos pertencem ao cliente de autenticação do sistema. A evidência do GhostControl está no evento MBus, na vinculação e na entrada aceita.

O PR 29 do GhostControl documenta a separação entre captura bruta, quadros neutros e controles mapeados. O código público do klogsrv mostra que o fluxo é entregue em blocos TCP. A V17 espera o limite real de uma linha antes de chamar `AddDevice`. [GhostControl PR 29](https://github.com/StonedModder/Ghostcontrol-PS5-USB-Controller-Patcher/pull/29) · [Código do klogsrv](https://github.com/ps5-payload-dev/klogsrv/blob/v0.9/main.c)

## Build e verificação

A base de trabalho foi `GhostControl-Precisao-GH5-V16-Limpo-20261122`. Os dois ELF V16 disponíveis no disco, na pasta original e na limpa, têm o mesmo SHA-256. Passaram 37 scripts Python e três executáveis C de USB e rumble com sanitizadores. O SDK Prospero gerou as duas variantes V17 e o verificador. Os testes no console citados neste relatório são da V16.

- Pasta da entrega `C:\gh5build\GhostControl-Precisao-GH5-V17-Limpo-20261122`.
- ELF para jogar na pasta `GhosttoothAPI/GhosttoothAPI-gh5-mapped.elf`.
- SHA-256 do ELF Mapeado `0617f5e7c424e65a01ca16ab9d748fbd7e43e8f0013777a2d8e95a000205e757`.
- A variante `GhosttoothAPI-GH5-precision.elf` também foi atualizada e permanece disponível para repetir o teste de quadros neutros.

## Teste da V17 no PS5

1. Mantenha ativo o `klogsrv` que já funcionou e encerre o GhostControl anterior.
2. Abra só o ELF **GH5 Mapeado V17**, conecte o receptor e ligue a guitarra. O ELF Mapeado usa o caminho normal de entrada HID.
3. Verifique se a guitarra é reconhecida no jogo. Pressione e solte um traste por vez. Depois teste a palhetada para cima e para baixo, um acorde e a reconexão do receptor.
4. Se alguma entrada sair errada ou ficar pressionada, anote qual botão físico foi pressionado e o que o jogo mostrou. Guarde `vpad.log` e `app-service.log`. A tag esperada é `GH5-PROBE-V17-20261122`, com `variant=gh5-mapped`. Os principais sinais são `decoded` crescente, `READY` e `first InsertData accepted`.
