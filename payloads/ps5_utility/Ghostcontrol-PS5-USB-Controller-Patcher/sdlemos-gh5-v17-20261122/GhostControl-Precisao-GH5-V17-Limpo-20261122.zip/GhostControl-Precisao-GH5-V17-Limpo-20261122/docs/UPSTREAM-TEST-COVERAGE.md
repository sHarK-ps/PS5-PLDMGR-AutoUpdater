# Public upstream tests not shipped in this local combined tree

At the verified #29 HEAD, upstream includes tests that were **not** bundled in this ZIP: `tools/tests/test_ds4_bridge.py`, `test_vpad_log_source.py`, `test_usb_input_gate.py`. Our tests check overlapping claims but cannot be called a full replacement. The dev should fetch those tests from the verified #29 HEAD, port to combined source if needed and run the real production-code regression before release.

#33 latest `docs/USER-LOG-REGRESSIONS.md` is also not embedded verbatim, though the developer handoff captures current findings. No PS5 SDK/target or hardware test was performed.
