# Ghostcontrol GH5 — next tests and fix plan

This is the working handoff for continuing the Guitar Hero 5 receiver work.
The goals are to establish a correct control mapping, validate virtual-pad input
in a game, and determine whether recurring EBUSY represents normal waiting or a
specific transfer fault. Those three outcomes are not yet verified.

## Console testing credit

[sdlemos](https://github.com/sdlemos) supplied the console tests, diagnostic logs,
test report and developer addendum. His report identifies PS5 firmware 11.60
and the original PS3 GH5 wireless receiver `12ba:0100`.

These hardware details come from his report. We still need the exact combined
source revision and ELF SHA-256 for each session before tying results to a build.

## Current PRs and implemented fixes

- [PR #29](https://github.com/StonedModder/Ghostcontrol-PS5-USB-Controller-Patcher/pull/29),
  latest follow-up `bbf6e42`: HID control fallback is gated by recent validated
  interrupt reception, independently of decoded publication. State and counters
  belong to each connection; retries have a 250 ms minimum interval. A one-second
  quiet window permits fallback again. Control replies decode separately so they
  cannot overwrite an outstanding interrupt buffer or requested length.
- #29 also contains the earlier virtual-pad parser, log-source setup/diagnostic,
  DS4 bridge and known-protocol input-gating fixes. Handshakes and rejected
  protocol packets are not promoted to neutral control samples.
- [PR #32](https://github.com/StonedModder/Ghostcontrol-PS5-USB-Controller-Patcher/pull/32)
  is the other contributor's USB/controller work. Preserve its applicable review
  fixes, short-transfer handling, request-format safeguards and controller support
  when preparing a combined test build.
- [PR #33](https://github.com/StonedModder/Ghostcontrol-PS5-USB-Controller-Patcher/pull/33),
  documentation follow-up `e63a384`: records and credits the latest findings.
  Its functional fixes cover Bluetooth bond storage, forget-result reporting and
  inquiry retry backoff, including failed command sends.

Host regressions and the latest PR CI runs passed when this handoff was written.
A local public #29/#32/#33 combination also passed the six focused host suites
and Bluetooth C11 syntax checks. That is not a reproduction of the private
Experimental tree, a PS5 ELF build or console validation of the new changes.
Nothing was merged upstream.

## What the new captures establish

The supplied `test.zip` and extracted `Downloads/test` folder contain four logs:
an app-service log and a vpad log for each of two sessions. They contain no source
tree or ELF.

| Evidence | Test 1 | Test 2 |
|---|---:|---:|
| Final completion counts, generations 1 and 2 combined | 3,313 | 2,494 |
| RAW samples logged | 256 | 256 |
| 27-byte RAW samples | 151 | 147 |
| Three-byte RAW samples | 105 | 109 |
| RAW capture duration | 5.834 seconds | 5.978 seconds |

The logs show changing 27-byte reports and continued USB delivery between EBUSY
returns. Both explicitly disable VDA probing. They do not establish complete
guitar mapping, virtual-controller binding or gameplay. Their instrumentation
does not prove a separate Conservative run without a matching build manifest.

The Experimental `decode_rejected` counter includes intentional probe-disabled
skips. Do not interpret that counter as the number of failed fret/strum decodes.
Endpoint fields printed after a failed COMPLETE call are snapshots, not valid
completed-packet results.

## First requirement: identify the exact source and build

The Experimental logger, its probe mode and its local `db_forget` rollback are
not in the supplied log-only archive. To modify that exact variant, obtain its
source ZIP or repository/commit and any uncommitted diff. Preserve its intentional
rollback difference during integration; it has not been reviewed or reproduced
from source here.

Ask the build preparer for:

```text
Combined source URL and full commit:
Uncommitted changes/diff, if any:
Included PR #29 commit:
Included PR #32 commit:
Included PR #33 commit:
Variant: Conservative / Experimental
ELF filename:
ELF SHA-256:
Build command and payload SDK revision:
PS5 model and firmware:
Loader/HEN and versions:
Kernel-log provider and configuration:
Probe setting:
```

The build preparer can calculate the ELF hash on Linux:

```sh
sha256sum GhosttoothAPI.elf
```

No new ELF has been compiled in this work. Exact Conservative/Experimental source
ZIPs cannot be claimed reproduced until the corresponding source is available.

## Track A — establish the guitar mapping

### Prepare a longer RAW capture

Use one service instance and a fixed controller/receiver setup. Keep the Toolbox
closed for the baseline, and record any later opening. Start with VDA probe OFF.
Use the supplied build's documented logging controls; do not assume a new switch
or marker exists in another build.

The Experimental logger still needs these corrections in its source:

- Label each report `INTERRUPT_IN` or `CONTROL_GET_REPORT`, including timestamp,
  length and connection generation.
- Separate the control-reply sampling budget from interrupt-report sampling.
- Use bounded change-based/time-windowed sampling that preserves press and release
  transitions throughout the full test instead of exhausting 256 samples early.
- Separate interrupt reception, probe-disabled skips, neutral probe frames,
  decode attempts/success/failure and publication. A neutral probe is not a
  successfully decoded fret or strum action.

Those Experimental-only logger corrections are requirements, not completed fixes.

### Run this physical sequence and record timestamps

1. Release every control and leave the guitar neutral for 10 seconds.
2. Press green for 2 seconds, release for 2 seconds, then repeat three times.
3. Repeat step 2 separately for red, yellow, blue and orange, where present.
4. Strum up repeatedly for 10 seconds, then strum down for 10 seconds.
5. Move whammy slowly from rest through its range and back, three times.
6. Tilt the guitar and return it to its normal position, three times.
7. Test Start/Select and other available controls individually.
8. Hold a fret while strumming; test several combinations, then release everything.
9. Leave the guitar neutral for another 10 seconds.
10. Unplug/replug the receiver and repeat a short fret/strum/whammy sequence.

Write `N/A` for absent controls. Do not infer a byte meaning from unrelated
changes or assume a mapping from the receiver ID alone.

### Developer acceptance criteria

- Correlate repeated press/release actions with report changes; distinguish
  buttons, axes, counters and unrelated changing fields.
- Add a decoder only when the labeled evidence supports the mapping.
- Add behavioral tests for neutral, press, release, held combinations, strum
  directions, axes and short/invalid reports, using appropriately sanitized
  fixtures from the identified capture.
- Preserve other controller decoders and generic HID learning.

## Track B — establish VDA and gameplay

Run a separate clean session with the test build's documented VDA probe enabled.
Do not reuse a RAW-only session as evidence that virtual input works.

Capture the following chain in order:

```text
Valid USB report received
Decoded button/axis state
AddDevice return
Kernel-log bytes, events, EOF and read errors
DEVICE_ADDED and candidate selection
Binding result and selected user
InsertData result
Visible response in a named game/version
```

Record the exact game/version and what controller type the game expects. Determine
whether a standard virtual controller is sufficient or an instrument-specific
interface is required before promising compatibility.

`AddDevice 0x803b0006` alone is not proof of failure: other supplied controller
captures show successful binding after that value. Binding alone is also not
proof of correct input or gameplay. Never guess a handle or force credentials
based on that return value.

Test each mapped control, simultaneous controls, releases, reconnect and return
to the game. Record whether any blocked screen is the PS5 user picker or a
Ghostcontrol profile page, with a screenshot or exact screen text if possible.

## Track C — determine the EBUSY cause

Start with the new fallback fix in an identified combined build. Preserve the
interrupt START/poll/COMPLETE mechanism while collecting evidence.

Collect bounded once-per-second summaries containing:

- Successful START/COMPLETE totals and EBUSY totals.
- Outstanding-transfer age and time since the last successful completion/input.
- Interrupt reception and GET_REPORT attempt/success/failure counters.
- Connection generation, path, fd, interface and endpoint.
- Completed endpoint index after successful COMPLETE.
- Separate decoding/publication counters with the semantics above.

The public fix implements fallback state/counters; the full Experimental summary
and counter relabeling still require its source. An fd can be reused after
reconnect, so it cannot identify a connection by itself.

The key measurement is the longest gap since a successful completion while
actively strumming. Compare an identified baseline with the updated build using
the same physical sequence and setup. Change only one variable per comparison.

| Observation | Next investigation |
|---|---|
| Reports continue between EBUSY returns | Early completion checks or ordinary waiting; do not call it a stall solely from the error count |
| Completions stop during active controls | Transfer lifecycle, receiver state and competing ownership |
| Another reader consumes completions | Multiple service/reader ownership |
| Completions succeed but decoding fails | Report format and mapping |
| Decoding succeeds but binding/input fails | Kernel-log, VDA and user routing |

The fallback defects are demonstrated code defects, but have not been proven to
cause EBUSY. A causal claim needs a repeatable failure, evidence of the mechanism,
a focused fix and a passing repeat of the same sequence. Include reconnect and
other-controller checks before considering the fix ready.

## What sdlemos should send back

Keep separate folders for RAW/probe-OFF, VDA/probe-ON and each comparison build:

```text
GH5-next-tests/
  raw-probe-off/
    build-and-test-notes.md
    app-service.log
    vpad.log
    control-sequence.md
  vda-probe-on/
    build-and-test-notes.md
    app-service.log
    vpad.log
    control-sequence.md
```

Include a separate kernel-log capture if available. Use actual output paths from
the supplied build; these folder names are a suggested package layout. Preserve
original logs, inspect public copies for identifiers, and send sensitive originals
privately. Do not include games, BIOS files, credentials or proprietary SDK files.

Finish each session's notes with:

```text
Raw USB input during active controls: PASS / FAIL / NOT VERIFIED
Labeled control mapping: PASS / FAIL / NOT VERIFIED
Virtual-pad identification/binding: PASS / FAIL / NOT VERIFIED
InsertData accepted: YES / NO / UNKNOWN
Named game/version and observed controls:
Gameplay: PASS / FAIL / NOT VERIFIED
Input after reconnect: PASS / FAIL / NOT VERIFIED
Longest completion gap while actively strumming:
Exact failure timestamp/action:
Single change from baseline, if any:
```

## Next development action

Use the longer labeled RAW sequence to implement and test the decoder, and the
separate VDA session to verify the delivery path. Review the Experimental source
before changing its logger or local rollback. Keep code fixes, host checks, target
builds and console results separate. Require independent PR review; do not merge
or release based solely on host tests or successful USB traffic.
