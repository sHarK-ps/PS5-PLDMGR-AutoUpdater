> **Histórico: superado pela integração de 10/11/2026.** Leia `../INTEGRACAO-ATUALIZADA-PR29-PR32-PR33.md` antes de aplicar correções.

# GhostControl — integração das PRs #29, #32 e #33

**Pacote de código-fonte:** 8 de novembro de 2026  
**Base de trabalho:** GhosttoothAPI/GhostControl diagnóstico GH5 anterior + correções upstream solicitadas  
**Hardware-alvo do diagnóstico:** receptor sem fio Guitar Hero PS3 `12BA:0100`, PS5 firmware 11.60 / OnionHEN.

Este documento é o manifesto de integração. Ele distingue código portado, código que já existia na base diagnóstica, requisitos derivados dos comentários e instrumentação exclusiva da variante experimental. “Teste passou” significa somente o teste indicado; não significa validação no PS5.

## PR #29 — identificação VDA/MBus, ciclo USB e vibração DS4

**Cinco commits listados em `Files changed`:**

| Commit | Alteração | Estado neste pacote |
|---|---|---|
| `1d3170f` | Aguarda prontidão da transferência USB e evita abrir interfaces USB não qualificadas; usa `poll()` antes de `USB_FS_COMPLETE`. | Mantido da base de diagnóstico PR #29; variante experimental acrescenta contexto às falhas GH5. |
| `038142b` | Reconhece o formato atual de evento MBus `DEVICE_ADDED` e extrai `deviceId`/tipo do dispositivo virtual. | Mantido no parser `ps5_vpad.c`. |
| `ef5af46` | Encaminha a vibração solicitada pelo jogo ao DS4 de origem e envia vibração zero ao encerrar/remover a ponte. | Integrado em `gc_ds4_game*`, `gc_ds4_source*` e `gc_ds4_bridge.c`. |
| `a8e1acc` | Corrige a leitura de `deviceType` decimal e hexadecimal. | Integrado e endurecido: decimal por padrão; hexadecimal somente com prefixo `0x`. |
| `c963b4d` | Acrescenta teste host de regressão do parser e execução em CI. | Portado como `tools/tests/test_virtual_device.py` e workflow `vpad-parser.yml`, com casos adicionais de entrada malformada. |

### Comentário #29 — parser decimal

O problema descrito pelo mantenedor é que `deviceType=22` foi interpretado como hexadecimal `0x22` (34), em vez do subtype 22. A implementação anterior baseada diretamente em `strtoul(..., 0)` também deixa uma armadilha: `022` é interpretado como octal 18 em C. Nesta integração, o parser usa decimal como base padrão e muda para base 16 apenas quando há prefixo `0x`/`0X`. Também exige que o token termine em separador reconhecido, rejeitando `22junk`.

Casos cobertos: `22`, `022`, `0x16` e evento legado com `subType:22` são aceitos; `34`, `0x22`, `220`, `22junk`, campo vazio, `deviceId` ausente, `DEVICE_REMOVED` e linha vazia são rejeitados.

### Comentário #29 — `Cross-PR interaction: a USB DS4 can also be selected as a "wireless" bridge source`

Requisito de compatibilidade aplicado: a seleção da fonte RemotePlay não pode presumir que um DS4 é elegível somente quando o transporte reportado é Bluetooth. Um DS4 identificado e conectado via USB também pode ser uma fonte para a ponte, desde que o firmware exponha o handle/identidade válidos necessários. O código não impõe filtro `connection_type == 2`. O comportamento de cada firmware precisa de confirmação em hardware.

### Rumble relay e limite de retry

O stub observa mudanças de vibração do jogo com publicação atômica/sequenciada; a ponte encaminha os motores para o handle DS4 correspondente e envia zero ao remover a ponte. A sequência do jogo é consumida mesmo quando a chamada remota falha, registrando o erro em vez de tentar anexar ao processo-alvo a cada ciclo de 8 ms. Uma nova tentativa ocorre quando houver nova atualização de vibração/rota.

## PR #32 — USB/HID, DS3, Xbox/GIP e DS4

**Dez commits integrados ou já presentes na base diagnóstica:**

| Commit | Alteração | Estado neste pacote |
|---|---|---|
| `67618f7` | Restaura URL completa de `GC_UPDATE_API`. | Presente e verificado. |
| `022cc20` | Usa o `wMaxPacketSize` real do endpoint para o tamanho de transferência. | Presente em `gc_service_inject.c`. |
| `9100315` | Trata desconexão/remoção do dispositivo no ciclo USB e libera feeds mortos; considera `ENXIO`, `ENODEV` e `ENOTTY` no encerramento. | Presente na limpeza USB. |
| `84605d2` | Corrige HID `GET_REPORT` para `bmRequestType=0xA1` e request `0x01`; rejeita resposta totalmente zerada. | Presente no caminho DS3/HID. |
| `4c6cbbb` | Mantém cache do layout HID analisado para não reinicializar handshake em cada varredura. | Presente na base de diagnóstico. |
| `10e84a9` | Acrescenta suporte Xbox One/Series via GIP e handshake limitado; preserva último estado em pacotes que não carregam input. | Presente em `controller_xbox.c`. |
| `c37971f` | Acrescenta relatório de saída para lightbar do DS4 USB. | Presente no caminho DS4. |
| `df5b2db` | Reduz o ciclo do serviço de 32 ms para 8 ms. | Presente na base de diagnóstico. |
| `e9d0e94` | Acrescenta inicialização/protocolo específico de controle DS3/PS3. | Presente em `controller_ds3.c`. |
| `3e4ef90` | Usa fallback HID genérico quando a inicialização DS3 falha. | Presente na base de diagnóstico. |

**Interação importante com GH5:** o receptor Sony de instrumento `12BA:0100` não deve ser enviado ao decodificador de controle DS3. Guitar Hero/Rock Band usam relatórios HID específicos de instrumento. A captura GH5 permanece no caminho bruto e exige decoder próprio para mapear trastes, strum, whammy e demais controles.

O autor da PR #32 descreve teste num PS5 fat com firmware 11.40. Isso não valida a integração no firmware 11.60 do console-alvo.

## PR #33 — persistência de bonds e backoff de inquiry

**Um commit:** `b5b910b`.

- Cria os diretórios-pai ausentes antes de salvar o banco de controles Bluetooth.
- Faz `db_save()` informar sucesso/falha, verifica escrita/flush/close/rename e grava por arquivo temporário seguido de rename.
- Distingue nos logs chaves realmente persistidas de chaves mantidas apenas na memória, tanto para Classic como BLE.
- Usa backoff crescente para recusas de HCI Inquiry: 500 ms, 1 s, 2 s, 4 s e máximo de 8 s; o contador só é zerado após Command Status de sucesso.
- Inclui teste host, workflow de CI e documentação para logs.

### Comentário #33 — `Follow-up: db_forget() still ignores the new save result`

Correção complementar: `db_forget()` agora retorna sucesso/falha e é transacional. Se a persistência falhar, restaura o registro na tabela em memória, mantendo RAM consistente com o registro ainda presente no disco; retorna falha e registra aviso. `host_forget()` propaga a falha e não confirma exclusão. `pair_with()` aborta a substituição de um vínculo antigo caso não consiga removê-lo duravelmente. Os caminhos que apenas atualizam metadados de VID/PID também registram falha de persistência.

## Logs GH5 e escopo da variante experimental

Os registros analisados indicam:

- receptor `12BA:0100` enumerado/aberto em `/dev/ugen2.2`;
- relatórios HID de 27 bytes recebidos, portanto a aquisição inicial funciona;
- `USB_FS_COMPLETE` ainda retorna `EBUSY` em ciclos de leitura;
- nenhum `DEVICE_ADDED` novo ficou visível nos logs comparativos anteriores, então o parser decimal não foi exercitado por esses eventos;
- `/dev/ugen1.2`, identificado no log como `040B:0897`, gerou tempestade de falhas repetidas de abertura.

A variante experimental não muda o ciclo de transferência nem bloqueia o dispositivo `040B:0897`. Ela acrescenta campos de diagnóstico ao `EBUSY` (fd, interface, endpoint, poll revents, frames, tamanho/status do endpoint) e reduz apenas a frequência das mensagens repetidas de `040B:0897`, mantendo as tentativas USB. Os limiares e a intenção estão documentados em `docs/EXPERIMENTAL-FINDINGS-AND-NEXT-STEPS.md`.

## Comentários recuperados e limite da visualização

Os tópicos incluídos são os dois apontamentos da #29 (correção decimal e interação cruzada com DS4 USB) e o follow-up da #33 (`db_forget()` precisa respeitar o resultado de persistência). O corpo integral das threads cruzadas não ficou disponível na visualização pública consultada; os títulos/intenções fornecidos foram transformados em requisitos sem inventar detalhes adicionais. Na #32, o histórico público disponibilizou os dez commits e a descrição de teste do autor; não foi recuperado comentário adicional de revisão.

## Testes e limites

- `tools/tests/test_virtual_device.py`: compila e executa os helpers reais de parser extraídos de `ps5_vpad.c`.
- `tools/tests/test_log_regressions.py`: compila e executa as rotinas reais de persistência, `db_forget()`/rollback e inquiry backoff extraídas de `host.c`, usando a estrutura privada real `host_storage`.
- `tools/tests/test_pr29_pr32_pr33_integration.py`: verifica contratos das integrações de rumble/DS4, mecanismos PR #32 e propagação da persistência/backoff PR #33.
- Na variante experimental, `tools/tests/test_experimental_diagnostics.py` verifica a instrumentação adicional.
- Os testes host passaram no ambiente de empacotamento. A checagem de sintaxe `-Werror` de `host.c`/`le.c` passou; os quatro módulos C da ponte DS4 passaram em syntax-only com avisos de comparação signed/unsigned já presentes em caminhos de identidade de processo. Os módulos USB que incluem `<dev/usb/...>` não puderam ser compilados aqui porque os headers do SDK de destino não estão disponíveis.
- O PS5 Payload SDK/Prospero não está instalado neste ambiente: não foi possível compilar/linkar o ELF completo nem validar o comportamento em runtime no PS5 firmware 11.60.
- Não existe ainda decoder de botões/trastes GH5 concluído neste pacote. Reconhecer o receptor e capturar bytes não equivale a jogar Guitar Hero.
