# GhostControl — README for Lemos: fixes, findings and next PS5 tests

Date: 2026-11-11  
Repository: https://github.com/StonedModder/Ghostcontrol-PS5-USB-Controller-Patcher  
Console testing, captures and GH5 developer reports: **[sdlemos](https://github.com/sdlemos)**  
Status: **Code fixes pushed; host tests and recorded CI pass. PS5 runtime of these revisions is NOT VERIFIED.**

## 1. What we are trying to make work

The target is the PS3 Guitar Hero 5 wireless guitar with its original USB
receiver, VID:PID **12BA:0100**, on the reported PS5 firmware **11.60 / OnionHEN**.

The complete path is:

`Guitar → receiver → USB reports → decoded controls → virtual-pad creation → identification → user binding → InsertData → game`

The supplied captures establish USB delivery and recovery. They do not establish
that the full path works. A virtual DualSense accepting input is also different
from a game recognizing a guitar as an instrument.

## 2. Exact public revisions and PRs

| Work | Branch | HEAD at this handoff | PR |
|---|---|---|---|
| GH5/USB, DS4, virtual-pad identification and diagnostics | `fix/ds4-vpad-identification` | `cd5807073ba6d6741bad232fbb33f618855a3632` | [#29](https://github.com/StonedModder/Ghostcontrol-PS5-USB-Controller-Patcher/pull/29) |
| Bluetooth persistence, inquiry and input lifecycle | `fix/log-reported-input-lifecycle` | `55bc1ae949953ffa7c65fe854e93a67e5109e138` | [#33](https://github.com/StonedModder/Ghostcontrol-PS5-USB-Controller-Patcher/pull/33) |
| Separate contributor's broader USB/controller work | Contributor branch | `3e4ef90c035df2851e6dc65bc0d339a7139da229` when integrated | [#32](https://github.com/StonedModder/Ghostcontrol-PS5-USB-Controller-Patcher/pull/32) |

These are separate PR heads, **not one integrated build**. We did not merge or
release them upstream. Independent maintainer review remains required.

A local integration review tree combines the public branches at
`8911df274723fe670dde82e77a99e9d7e331d3c5`, retaining #32's cached HID reader and
DS3/GIP handling. It is a local validation fixture, not a published ELF or a
reproduction of the private Diagnostic/Precision tree. Its presence in this
handoff does not mean it can be downloaded as a public branch.

## 3. What your latest logs establish

The analyzed archive SHA-256 was:

`1442ffea72c342e6c998ed5897afb067a4b2b011bcff6c73e6a3c52372166464`

It contained two sessions and four files:

- `test 1 diagnostico/vpad.log`
- `test 1 diagnostico/app-service.log`
- `test 2 precisao/vpad.log`
- `test 2 precisao/app-service.log`

| Observation | Diagnostic | Precision |
|---|---:|---:|
| Selected RAW reports | 256 | 660 |
| RAW report length | All 27 bytes | All 27 bytes |
| RAW span | About 18.3 seconds | About 52.2 seconds |
| RAW reports after reconnect | None retained by the capped logger | 436 |
| Latest per-generation successful completion counts | Not separately comparable | At least 2,650 combined |
| GET_REPORT attempts | Not separately counted | Zero in both generations |
| VDA probe | Disabled | Disabled |

Precision's 2,650 completion total is a lower bound from the last generation
snapshots, not necessarily the final lifetime count. Its recorded EBUSY total
at those snapshots is also 2,650. Differing collection lengths and counters do
not establish a throughput improvement.

The receiver opens interrupt-IN endpoint **0x81** and supplies changing reports.
Both sessions recover after device disappearance/reopen. The captured HID
descriptor is **137 bytes**, with **18 semantic fields**, **16 raw fields**, and
**no numbered report ID**.

Precision records **20 excluded RAW log samples**. That is logger-budget
exclusion, not proof that 20 USB packets were lost. Diagnostic's global 256-entry
RAW cap hides post-reconnect byte values even while its traffic counters advance.

All 660 Precision RAW records are labelled INTERRUPT_IN; no three-byte control
samples appear. Zero GET_REPORT attempts during healthy interrupts are consistent
with our fallback suppression, but do not prove idle/no-interrupt fallback works
on the physical device or establish the exact code executed.

The archive includes logs, not source or an executed ELF hash. Folder/variant
names and source ZIP hashes do not identify an executed binary. No synchronized
physical-action diary was supplied. We cannot independently label each recorded
bit transition as a particular physical fret based on those captures alone.

## 4. GH5 and USB fixes actually written

| Commit | Actual change | Evidence / limit |
|---|---|---|
| `bbf6e42` | Base fallback on recent valid interrupt traffic; retain per-connection state, 250 ms retry bounds and a separate control buffer. | Prevents redundant polling during RAW-only reception and overwriting an outstanding interrupt buffer. Host regressions pass. |
| `7aff684` | Continue quiet-pipe fallback after the first decoded control reply. | Reproduced missing later release before the fix; press/release publication now passes in the host harness. |
| `9c059b5` | Reject undecodable control replies instead of publishing neutral learner input, including through saved-profile rescue. Preserve interrupt setup learning. Check completion index before touching IN ownership/status. | Regressions reproduced false publication and OUT completion clearing pending IN. EBUSY still leaves IN pending. |
| `3f2917d` | Correct the default first three buttons specifically for 12BA:0100; preserve original HID usages, custom overrides and unrelated devices. | Uses the captured descriptor/two reports plus published protocol research. Physical mapping still needs your confirmation. |
| `3c4341c` | Require a drained, usable kernel-log stream and complete line boundary before AddDevice. Log the first accepted InsertData once per device. | EOF/error/backlog/partial-line regression failed before repair. Healthy startup and production input construction pass with mocked console APIs. |
| `cd58070` | Add bounded GH5 per-connection progress diagnostics to distinguish EBUSY with progress from a possible stall. | Simulation and production logger/completion tests pass. This is instrumentation, not a proven EBUSY cause/fix. |

The documented default mapping is:

| Guitar control | Virtual gamepad control |
|---|---|
| Green | Cross |
| Red | Circle |
| Yellow | Square |
| Blue | Triangle |
| Orange | L1 |
| Strum up/down | D-pad up/down |
| Whammy | Existing right-stick X interpretation; physical range needs verification |
| Slider | Existing right-stick Y interpretation; physical range needs verification |

The new fret correction changes only the first three default button mappings.
Tests also cover chords, releases, strum and neutral hat values. It does not add
motion calibration, a tilt-to-star-power threshold or virtual guitar identity.
Existing custom profiles that compensated for the old button order need review.

The new creation preflight withholds AddDevice on a known-unusable source. A busy
or partial stream can therefore delay creation and require retry/reconnect. A
quiet stream reaching EAGAIN does not guarantee delivery of a future DEVICE_ADDED.
No device is guessed, bound or deleted from ambiguous identification evidence.

## 5. Other controller work retained

These changes are relevant regression boundaries, not proof of GH5 gameplay:

- **Wireless DS4:** decimal MBus device-type parsing; kernel-log diagnostics;
  wireless transport/ownership filtering; rumble forwarding, delivery retry and
  teardown handling. Physical rumble and target-console behavior remain unverified.
- **Cosmic Byte Blitz in Nintendo-compatible mode (057E:2009):** known-protocol
  handshakes and failed/rejected packets no longer qualify as neutral readable
  input. Earlier captures reached binding, but the reported inactive controls at
  the profile/user-selection screen have not been confirmed resolved.
- **Bluetooth Xbox 045E:0B22:** the profile table and xpadneo identify this as
  Elite Series 2 BLE; retain VID/PID rather than assuming a Series X|S model.
  Earlier logs include successful readiness/binds, persistence errors and 412
  refused inquiry statuses. Binding is not evidence of functioning gameplay.
- **PR #33:** parent-directory handling and persistence-result reporting;
  capped inquiry retries, including failed sends; cancellation bounded to once
  per 500 ms; errors no longer falsely end inquiry; input publication stops on
  disconnected/disconnecting links and across callback teardown boundaries.

A failed forget currently removes the memory record but can retain the old disk
record, which may return after restart. Failure is reported; this is not claimed
to provide durable deletion on unwritable storage. The private local rollback
policy was not supplied or overwritten.

## 6. What EBUSY means here

EBUSY is the USB API's “device busy” error. FreeBSD 11's USB_FS_COMPLETE returns
it when no completion is queued. That reference is **not proof of identical PS5
semantics**. Your captures show successful input between EBUSY returns, so the
count alone does not establish a permanent stall or the cause of missing gameplay.

The current public patch preserves pending IN ownership. It does not blindly
restart transfers, reset the receiver or suppress warnings to appear fixed.

New `usb progress:` summaries are GH5-only and bounded to once per second:

- `generation`: connection identity independent of reused fd/slot values.
- `endpoint_address` versus `transfer_index`: USB 0x81 is distinct from array index 0.
- `starts`, `completions`, `EBUSY`, `complete_errors`.
- `inputs`, `decoded`, `rejected`: transport input versus interrupt decoding.
- `poll_revents`, `busy`, `outstanding_ms`, `since_complete_ms`, `since_input_ms`.
- `GET_REPORT_attempts`: control-fallback activity.

Missing completion/input ages are -1. Decoder counts describe interrupt reports,
not control replies. Successful completion counts can include endpoint-status
errors; valid-input counts are separate.

`phase=possible-stall` means an outstanding transfer is at least one second old
and no successful IN completion has been seen for at least one second. This is
an observation threshold, **not an automatic recovery trigger or proven fault**.
An intentionally quiet device could meet it. `progress-resumed` means the next
sample no longer meets that condition. Samples can miss short episodes and do
not provide a maximum-stall bound or final lifetime totals.

## 7. Validation completed

- PR #29 at `cd58070`: **all nine focused host suites PASS**; recorded GitHub
  Tooling checks and both host runs PASS.
- PR #33 at `55bc1ae`: **all three Bluetooth host suites PASS**; strict host/le
  C11 syntax and recorded GitHub checks PASS.
- Earlier combined public tree `cc8cd1d` passed all ten then-existing focused
  suites. Subsequent integration updates passed the affected virtual-pad and
  completion/progress checks; unchanged suites were not needlessly rebuilt.
- Host syntax checks for ps5_vpad.c pass. Production tests check the host
  120-byte input layout, press/release construction and mocked InsertData behavior.
- Workflow actions remain on **Node.js 24**. Required checks remain enabled.
- **No full local PS5 application build, published integrated ELF, new PS5
  execution, physical rumble or gameplay validation was performed.** Host
  compilation/tests do not prove console ABI, firmware or game compatibility.

## 8. Controlled next test — please keep variables isolated

### Before testing

Record these in a small text note beside the logs:

- PS5 model, firmware, OnionHEN/loader version.
- Receiver/guitar model and VID:PID.
- Exact source/combined revision, local modifications and build variant.
- Executed ELF filename and SHA-256; a source ZIP hash is not an ELF hash.
- VDA/probe state, selected PS5 user and controller assignment.
- Whether Toolbox and other controller/USB-reader processes are active.

Ensure one service owns the receiver. Build/integrate through the project's
normal documented process; this handoff does not supply a tested ELF. The
public code changes are not automatically present in the private Precision build.

### Session A: USB/control capture with VDA OFF

1. Start the known build with Toolbox closed and verify the disabled-mode banner.
2. Capture about 10 seconds idle.
3. Record timestamps for each fret separately: press, hold briefly, release.
4. Repeat for both strum directions, then chords plus strumming.
5. Move whammy through its range, slider through its positions, then tilt.
6. Unplug/replug the receiver and repeat. Preserve the generation change.
7. Save complete vpad.log and app-service.log, not screenshots or selected lines.

Example action diary (replace times with the actual timestamps):

```text
12:00:00 — idle begins
12:00:10 — green pressed
12:00:12 — green released
12:00:14 — red pressed
12:00:16 — red released
... continue each control, combinations and reconnect ...
```

The diary's time base must be related to the log's monotonic timestamps; record
a clear shared event such as receiver insertion or a visible startup timestamp.
If logger budgets drop samples, preserve the drop accounting and repeat a shorter
controlled sequence. Do not call missing log samples lost USB packets.

### Session B: same build/settings with VDA ON

The previously supplied private Diagnostic/Precision variant implements:

`/data/ghostcontrol-app-service/gh5-vpad-probe.enable`

**This marker is not a universal upstream feature.** Use it only with a build
whose source implements it. Create it before restarting that service, and verify
its literal enabled-mode banner. Do not assume placing a file enables probing
in an arbitrary public build.

Capture the whole chain:

1. AddDevice raw return and parameter diagnostics.
2. Identification log-source bytes, events, candidates, EOF/read errors.
3. DEVICE_ADDED/deviceType and the uniquely identified device.
4. Binding result, selected user and handle.
5. First accepted InsertData or exact refusal/recovery logs.
6. The same timed guitar actions; then test actual controls in the intended game.

A neutral probe tests only its own path. It is not fret decoding or gameplay.
AddDevice `0x803B0006` alone must not be classified as definitive creation failure
or success: earlier non-GH5 captures showed it preceding successful binds.

### How we will choose the next fix

| Evidence | Next investigation |
|---|---|
| EBUSY rises, completions/input stay fresh | USB progresses; do not reset solely for the error count. |
| Pending age grows during active strumming and completions stop | Investigate completion ownership, receiver state and exact PS5 API behavior. |
| Completions/input continue but decoding rejects reports | Replay those reports against the captured descriptor/decoder. |
| Decoding succeeds but no virtual pad identifies/binds | Investigate kernel-log delivery, AddDevice and MBus independently of USB. |
| Binding succeeds but InsertData is refused | Investigate exact return codes, handle/user routing and console lifecycle. |
| InsertData is accepted but game ignores controls | Check physical mapping, selected pad/user and game/instrument compatibility. |

## 9. What remains unresolved

- Physical confirmation of all GH5 controls, releases and combinations.
- Tilt/whammy calibration and any intended star-power behavior.
- GH5 virtual-pad identification/binding on a known current build.
- Accepted input reaching the correct user and the intended game.
- Guitar-specific game recognition/virtual instrument identity.
- Exact PS5 EBUSY cause; no permanent stall is established by current captures.
- Private Diagnostic/Precision source differences and reproducible ELF identity.
- Console confirmation of the separate Cosmic Byte, Bluetooth and DS4 fixes.

## 10. References and rollback

Protocol facts were independently implemented; external research is not console
verification of these commits.

- [PS3 Guitar Hero protocol / PlasticBand](https://github.com/TheNathannator/PlasticBand/blob/main/Docs/Instruments/5-Fret%20Guitar/Guitar%20Hero/PS3.md)
- [Santroller PS3 Guitar Hero research](https://santroller.github.io/guitar-configurator/controller-reverse-engineering/ps3-gh-guitar.html)
- [FreeBSD 11 USB generic implementation](https://github.com/freebsd/freebsd-src/blob/releng/11.0/sys/dev/usb/usb_generic.c)
- [Bluetooth SIG HCI specification](https://www.bluetooth.com/wp-content/uploads/Files/Specification/HTML/Core-60/out/en/host-controller-interface/host-controller-interface-functional-specification.html)
- [Bluetooth SIG error-code definitions](https://www.bluetooth.com/wp-content/uploads/Files/Specification/HTML/Core-60/out/en/architecture%2C-change-history%2C-and-conventions/controller-error-codes.html)
- [xpadneo](https://github.com/atar-axis/xpadneo)
- [Public PS5 payload SDK](https://github.com/ps5-payload-dev/sdk)
- [Ghostpad virtual-pad research](https://github.com/almhtar/Ghostpad/blob/main/virtualDS5research.md)
- [Sony PS5/PS4 controller compatibility](https://www.playstation.com/en-gb/support/games/ps5-backward-compatibility-games/)

Rollback is by the relevant focused commit, with maintainer review. Do not force
push, broadly revert another contributor's work, or treat this document as an
instruction to modify firmware. Keep the last known working source/artifact and
logs for comparison. No merge or release is authorized by passing host tests.

**Please return the complete logs, action diary, build/provenance note and exact
visible symptom. That evidence lets the next change target a reproduced failure
rather than guessing at USB resets or controller mappings.**
