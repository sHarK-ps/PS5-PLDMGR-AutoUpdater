> **HISTORICAL RESEARCH SNAPSHOT.** References to "current 9 commits" (#29) or "current 5 commits" (#33) were true for an older retrieval, NOT the 2026-11-11 PR heads. Consult `../AUDIT-2026-11-11-R2.md` for verified updates.

# GhostControl GH5 — Guia Mestre de Integração e Testes do Lemos

**Versão:** 3.0 — consolidada em 10 de novembro de 2026  
**Destinatário/testador:** Lemos  
**Autor do procedimento original:** desenvolvedor do GhostControl  
**Alvo principal:** guitarra Guitar Hero PS3 sem fio + receptor USB `12BA:0100`  
**Console relatado:** PS5 firmware 11.60 / OnionHEN (confirmar novamente antes de cada sessão)

> Este documento consolida o README de testes enviado pelo desenvolvedor, o histórico de logs `test1`/`Experimental test 2`, os relatórios anteriores e o estado público mais recente das PRs #29, #32 e #33 consultado em 10/11/2026. Ele é um roteiro de preparação, execução e coleta. Não é um ELF, não substitui as instruções específicas do ELF que o desenvolvedor entregar e não afirma que todas as mudanças upstream já estejam no pacote antigo.

---

## 1. Objetivo e separação dos problemas

A investigação tem caminhos diferentes. Não misturar os resultados:

1. **USB físico:** o PS5 enumera o receptor, abre a interface e conclui transferências?
2. **Relatório HID:** os bytes mudam quando a guitarra é operada? O decoder aceita o relatório?
3. **VDA/MBus:** o Ghostcontrol cria o dispositivo virtual, recebe o evento `DEVICE_ADDED`, identifica o dispositivo e faz o bind ao usuário?
4. **VDI/input:** depois do bind, `scePadVirtualDeviceInsertData` é chamado com sucesso e os controles realmente funcionam no jogo?
5. **Bluetooth/persistência:** pareamento, salvamento, esquecimento e inquiry retry funcionam após reiniciar?
6. **DS4/RemotePlay/rumble:** o DS4 é classificado pela origem/transporte correto, não fica com duas rotas concorrentes e a vibração chega fisicamente ao controle?

**Não tratar estes eventos como equivalentes:** receptor detectado ≠ relatório USB recebido ≠ relatório decodificado ≠ controle virtual criado ≠ controle associado ao usuário ≠ botões funcionando no jogo.

---

## 2. Estado mais recente das PRs no GitHub

Na consulta de 10/11/2026, as três PRs continuavam marcadas como **Open**. Os números abaixo refletem as páginas atuais de commits, não a quantidade que aparecia nos arquivos antigos.

### 2.1 PR #29 — DS4 discovery, USB reads, rumble forwarding e diagnóstico VDA

[PR #29 — página](https://github.com/StonedModder/Ghostcontrol-PS5-USB-Controller-Patcher/pull/29) · [Commits](https://github.com/StonedModder/Ghostcontrol-PS5-USB-Controller-Patcher/pull/29/commits) · [Files changed](https://github.com/StonedModder/Ghostcontrol-PS5-USB-Controller-Patcher/pull/29/files)

A página atual mostra **9 commits**:

| Commit | Descrição/efeito identificado |
|---|---|
| `1d3170f` | Espera a prontidão da transferência interrupt USB antes de `USB_FS_COMPLETE`; evita abrir interfaces não qualificadas. |
| `038142b` | Reconhece o formato atual de evento virtual `DEVICE_ADDED`/DS4 e seus campos. |
| `ef5af46` | Encaminha a vibração solicitada pelo jogo para o DS4 wireless correspondente. |
| `a8e1acc` | Interpreta `deviceType` decimal por padrão e aceita hexadecimal explícito com `0x`. |
| `c963b4d` | Acrescenta testes de descoberta de dispositivo virtual e validação de tokens. |
| `7279f6d` | Isola fontes RemotePlay e preserva a entrega de rumble. |
| `b9f34d2` | Merge/sincronização de `main` na branch da PR; registrar no manifesto do build, mas não contar como correção funcional independente. |
| `088e1b7` | Verifica a configuração não bloqueante do socket de kernel log e diferencia causas de falha na identificação. |
| `ddb0104` | Exige controles decodificados antes de publicar input de protocolos conhecidos; o fallback de aprendizado neutro fica restrito a HID genérico. |

**Detalhes atuais importantes da #29:**

- O parser deve aceitar decimal `22` e hexadecimal explícito `0x16`, preservar o formato legado e rejeitar tokens malformados/campos de ID ausentes. Não interpretar `deviceType=22` como `0x22` (34).
- `088e1b7` verifica se o socket TCP de klog realmente ficou não bloqueante e registra o retorno bruto de `AddDevice`, bytes/linhas/eventos/candidatos, EOF e `read_errno`. Isso permite distinguir “nenhum byte chegou” de EOF, erro de leitura, evento inexistente ou evento não correspondente.
- `088e1b7` melhora a observabilidade do klog; não altera por si só a transferência USB e não resolve a causa de `EBUSY`.
- `ddb0104` evita publicar estados neutros durante handshakes ou pacotes rejeitados de protocolos conhecidos. Também preserva o último estado decodificado em vez de limpá-lo com pacotes que não são input válido. O aprendizado HID genérico continua existindo para dispositivos sem protocolo conhecido.
- O comentário **“Cross-PR interaction: a USB DS4 can also be selected as a ‘wireless’ bridge source”** deve ser tratado como risco de classificação/ownership cruzado. A descrição atual da PR menciona filtro `ConnectionType 2` na origem RemotePlay e rejeição de pads USB locais para evitar dupla propriedade com a rota USB da #32. Nos testes, registrar o `ConnectionType` realmente reportado e separar DS4 USB de DS4 wireless; não inferir o transporte pelo nome exibido na interface.
- Para rumble, registrar pedido real vindo do jogo, handle/fonte DS4 casados, retorno da chamada de relay e observação física dos motores. Também verificar comando zero/stop ao remover rota, sair do jogo ou suspender. Um retorno de API isolado não prova vibração física.

### 2.2 PR #32 — USB HID, Xbox One/Series GIP, DS3 e DS4 lightbar

[PR #32 — página](https://github.com/StonedModder/Ghostcontrol-PS5-USB-Controller-Patcher/pull/32) · [Commits](https://github.com/StonedModder/Ghostcontrol-PS5-USB-Controller-Patcher/pull/32/commits) · [Files changed](https://github.com/StonedModder/Ghostcontrol-PS5-USB-Controller-Patcher/pull/32/files)

A página atual mostra **10 commits**:

| Commit | Descrição/efeito identificado |
|---|---|
| `67618f7` | Restaura a URL completa `GC_UPDATE_API`, truncada anteriormente. |
| `022cc20` | Solicita o tamanho real `wMaxPacketSize` do endpoint IN em cada transferência HID. |
| `9100315` | Fecha corretamente um feed cujo dispositivo USB desapareceu; trata `ENXIO`, `ENODEV` e `ENOTTY` na aposentadoria do feed. |
| `84605d2` | Corrige HID `GET_REPORT` para `0xA1 / 0x01` no fallback de poll e ignora respostas totalmente zeradas. |
| `4c6cbbb` | Faz cache dos layouts HID já analisados entre varreduras. |
| `10e84a9` | Acrescenta Xbox One/Series por GIP; handshake limitado e preservação do último estado em pacotes sem input. |
| `c37971f` | Envia relatório de saída para a lightbar de DS4 USB genuíno. |
| `df5b2db` | Reduz a pausa do ciclo de serviço de 32 ms para 8 ms. |
| `e9d0e94` | Acrescenta suporte a controles DS3/PS3 no serviço. |
| `3e4ef90` | Usa fallback HID genérico quando a inicialização específica do DS3 falha. |

O autor descreveu teste em PS5 fat com firmware 11.40. Isso **não** valida automaticamente firmware 11.60, o receptor GH5 `12BA:0100` ou a integração combinada deste projeto.

#### Follow-up de revisão da #32 (fora dos dez commits upstream)

O comentário de revisão apontou dois defeitos e uma preocupação de responsividade. O pacote anterior incluiu um follow-up local para esses pontos; confirmar no código e no hash do ELF que o desenvolvedor está entregando:

1. **Cache HID obsoleto após desconexão:** invalidar entradas ligadas a um caminho `/dev/ugen*` quando o feed é aposentado ou o nó desaparece. Um novo dispositivo pode reutilizar o mesmo caminho e não pode herdar o layout anterior.
2. **Primeiro pacote GIP perdido:** guardar o primeiro relatório `INPUT` recebido durante o handshake e entregá-lo depois ao decoder normal. GIP pode enviar input somente quando o estado muda; descartar o primeiro pacote pode deixar botão pressionado invisível até outra mudança.
3. **Handshake síncrono bloqueando USB:** não executar espera de até aproximadamente 1,6 s dentro de `usb_tick()` enquanto o `source_dispatch_lock` está retido. O handshake deve ocorrer em worker/fluxo assíncrono; o serviço deve continuar atendendo outros feeds, juntar o worker e cancelar/encerrar com segurança antes de fechar o descritor USB.

O teste `test_pr32_review_followup.py` do pacote anterior verifica a presença dos hooks de invalidação, fila do primeiro GIP input e worker assíncrono. É uma verificação de contrato/estrutura no código host; não substitui compilação Prospero nem teste de concorrência no PS5.

### 2.3 PR #33 — Bluetooth bond storage, inquiry retry e documentação dos logs

[PR #33 — página](https://github.com/StonedModder/Ghostcontrol-PS5-USB-Controller-Patcher/pull/33) · [Commits](https://github.com/StonedModder/Ghostcontrol-PS5-USB-Controller-Patcher/pull/33/commits) · [Files changed](https://github.com/StonedModder/Ghostcontrol-PS5-USB-Controller-Patcher/pull/33/files)

A página atual mostra **5 commits**:

| Commit | Descrição/efeito identificado |
|---|---|
| `b5b910b` | Cria diretórios-pai ausentes do banco Bluetooth, informa se chaves Classic/LE foram persistidas ou ficaram somente em memória e corrige a política de backoff para recusas de inquiry. |
| `b11e3ee` | Faz `db_forget()`/`host_forget()` devolverem falha quando a remoção não pôde ser persistida; evita mensagem de sucesso sem ressalva. |
| `7a744e7` | Acrescenta `docs/USER-LOG-REGRESSIONS.md` com a evidência dos logs e plano de reteste focado. |
| `82e9249` | Distingue bind bem-sucedido de controle sem input ativo; adiciona orientação para investigar controles inativos após associação. |
| `8c008a8` | Aplica backoff também quando o próprio envio de inquiry falha antes de existir evento Command Status. |

**Cuidado com o follow-up `db_forget()`:** na descrição atual da PR, em caso de falha de gravação a remoção em memória já ocorreu, mas o registro antigo ainda permanece no disco e pode reaparecer depois do restart. O host retorna falha/loga “forgotten in memory” em vez de declarar exclusão persistida. A aceitação assíncrona de um pedido na interface não prova que o host gravou a alteração. O ZIP anterior deste projeto implementou uma restauração do registro em RAM após falha de escrita; isso é uma extensão local diferente do comportamento descrito pelo commit upstream `b11e3ee`. O build entregue para teste deve declarar qual dos dois comportamentos contém e não misturar os dois como se fossem idênticos.

**Backoff Bluetooth atual:** 500 ms, 1 s, 2 s, 4 s e máximo de 8 s. O intervalo só é zerado quando o controlador aceita a inquiry. O commit `8c008a8` cobre ainda o caminho em que o envio falha antes de gerar Command Status; sem isso, o loop poderia tentar a cada tick.

A documentação atual da PR #33 também acrescenta novas evidências e retestes para guitarra, DS4/XUSB, Cosmic Byte Blitz e Xbox LE. A seção Bluetooth deste guia incorpora os pontos relevantes para a coleta do Lemos.

---

## 3. Comparação com os arquivos que já tínhamos

Os ZIPs Conservador/Experimental gerados anteriormente foram produzidos antes das atualizações de 10/11. Eles são úteis como histórico e base de trabalho, mas **não devem ser declarados como contendo integralmente o head atual das PRs #29 e #33**.

### Pendências de sincronização identificadas

- O manifesto anterior da #29 listava cinco commits. Faltam nele `7279f6d`, `b9f34d2`, `088e1b7` e `ddb0104` da versão consultada em 10/11.
- O manifesto anterior da #33 estava baseado em `b5b910b` e no follow-up `db_forget` já portado localmente. Faltam no manifesto os commits documentais `7a744e7`, `82e9249` e o backoff do caminho de falha de envio `8c008a8`.
- A descrição atual da #29 fala explicitamente de seleção RemotePlay por `ConnectionType 2` e rejeição de DS4 USB local para evitar ownership duplicado. A documentação da integração antiga afirmava que não aplicava filtro `connection_type == 2`; isso precisa ser reconciliado no build atualizado.
- A nova `088e1b7` da #29 melhora o diagnóstico de entrega do klog; não presumir que a instrumentação esteja presente só porque existe um resumo antigo de bytes/candidatos.
- O `ddb0104` da #29 introduz a barreira de input decodificado antes de publicar estado de protocolo conhecido. Verificar que essa correção está realmente no build e que o fallback genérico continua limitado a HID genérico.
- O `8c008a8` da #33 trata falha de envio de inquiry, não apenas respostas de recusa HCI.
- A variante Experimental antiga registra amostras de `EBUSY` e reduz o ruído de logs de `040B:0897`, mas isso não equivale ao resumo USB por segundo recomendado pelo desenvolvedor (totais START/COMPLETE/EBUSY, idade de transferência pendente, último input e contadores de decoder).

**Regra de segurança para a próxima coleta:** o desenvolvedor deve entregar um único `GhosttoothAPI.elf` combinado. Não carregar dois ELFs de serviço nem iniciar duas instâncias Ghostcontrol para tentar combinar as correções. Um único processo deve ser o proprietário do receptor e do fluxo de klog.

---

## 4. Antes de testar: identificação exata do build

Peça ao desenvolvedor/build preparer estes dados antes de conectar a guitarra:

- URL do repositório e branch usados.
- Commit completo (40 caracteres) do build combinado.
- Lista de commits completos incorporados de #29, #32 e #33, inclusive follow-ups de revisão.
- Indicação explícita de que `7279f6d`, `088e1b7`, `ddb0104` e `8c008a8` estão presentes ou ausentes.
- Como foram tratados os três pontos do review follow-up da #32.
- Qual comportamento de `db_forget()` foi usado: upstream (`b11e3ee`, falha pode deixar registro no disco e reaparecer após restart) ou extensão local com rollback em RAM.
- Nome do ELF e hash SHA-256 do arquivo efetivamente entregue.
- SDK/toolchain e dependências de destino usados no build.
- Se `GC_GH5_USB_DIAGNOSTIC=1` está ativo e se o log de relatório bruto HID em hexadecimal está implementado.
- Se o marcador `gh5-vpad-probe.enable` é suportado neste ELF, quando é lido e qual mensagem de startup confirma seu estado.
- Fonte de kernel log realmente usada (por exemplo TCP `127.0.0.1:3232`, `/dev/klog` ou outra), configuração e exclusividade do leitor.
- Quais contadores USB adicionais estão implementados. Não considerar os campos recomendados na Seção 8 implementados sem confirmação do desenvolvedor.

O hash deve corresponder ao arquivo que será carregado no PS5, não apenas ao repositório. Em Linux/WSL, por exemplo:

```sh
sha256sum GhosttoothAPI.elf
```

Se algum dado for desconhecido, registrar `UNKNOWN`. Não adivinhar commit, hash, versão ou opção.

---

## 5. Ficha da sessão — preencher antes de cada captura

Copie para `test-notes.md` e preencha:

```text
Tester: Lemos
Test date/time and timezone:
PS5 model:
PS5 firmware:
Jailbreak/HEN and version:
ELF loader and version:
Ghostcontrol/Experimental version:
Repository URL:
Branch:
Combined source commit (full SHA):
PR #29 included commits (full SHA):
PR #32 included commits (full SHA):
PR #33 included commits (full SHA):
PR #32 review-follow-up commit/diff:
PR #33 db_forget behavior: UPSTREAM / LOCAL ROLLBACK / UNKNOWN
ELF filename:
ELF SHA-256:
GC_GH5_USB_DIAGNOSTIC=1: YES / NO / UNKNOWN
Raw HID hex logging enabled: YES / NO / UNKNOWN
Guitar VDA probe marker supported: YES / NO / UNKNOWN
Guitar VDA probe state at startup: ENABLED / DISABLED / UNKNOWN
Kernel-log provider/payload and version:
Kernel-log endpoint/configuration:
Other klog readers active: YES / NO / UNKNOWN
Guitar model:
Receiver VID:PID: 12ba:0100
PS5 USB port:
Cable/adapter/hub used:
Other connected controllers:
Toolbox open or closed during capture:
Foreground application/game:
Diagnostic options enabled:
040b:0897 physically connected: YES / NO / UNKNOWN
USB progress summary available: YES / NO
Video recorded: YES / NO
```

---

## 6. Preparar uma sessão limpa

1. Usar o procedimento normal de jailbreak e ELF loader já conhecido. Não alterar firmware, HEN, loader, credenciais, tamanho de transferência, timing nem opções USB só para preencher a ficha.
2. Confirmar que não existe outra instância do Ghostcontrol/GhosttoothAPI rodando. Usar o procedimento normal e suportado do projeto para parar a instância antiga.
3. Usar **um único ELF combinado** e uma única instância de serviço. Não carregar o ELF conservador e o experimental ao mesmo tempo.
4. Manter `/data/ghostcontrol-app-service` e seus arquivos de configuração. Não apagar nem renomear os logs antigos antes de copiá-los.
5. Iniciar uma captura nova usando o método de logging já fornecido para esse build. Manter `app-service.log` e `vpad.log` juntos e pertencentes à mesma sessão.
6. Para a sessão baseline, deixar a Toolbox fechada e registrar se/ quando ela for aberta. Isso evita confundir a origem da leitura/input; se a interface ou o jogo precisar ficar em primeiro plano, anotar exatamente qual app estava ativo.
7. Deixar um controle normal disponível se o sistema pedir atribuição do controle virtual. Registrar quando ele for ligado/desligado; não deixar outro controle ou app assumir silenciosamente o primeiro slot de entrada.
8. Conectar o receptor diretamente a uma porta USB do PS5, sem hub se possível. Registrar a porta e o horário.
9. Não executar outro leitor de klog na mesma origem/porta TCP durante a captura de VDA. Se a origem for `127.0.0.1:3232`, confirmar com o desenvolvedor se o serviço é exclusivo.

---

## 7. Teste GH5 — sessão 1: USB bruto, sem probe VDA

Esta sessão separa a leitura USB da criação do controle virtual.

1. Confirmar que o marcador abaixo **não existe**:

   `/data/ghostcontrol-app-service/gh5-vpad-probe.enable`

2. Carregar apenas o ELF diagnóstico confirmado pelo desenvolvedor.
3. Confirmar no startup log que o modo está realmente `VDA probe mode disabled: raw USB logging only` (ou mensagem equivalente documentada pelo build).
4. Conectar o receptor `12BA:0100` e ligar a guitarra normalmente. Anotar horário exato da conexão.
5. Executar a sequência controlada abaixo. Um vídeo curto mostrando mãos e tela é útil, mas os timestamps escritos são obrigatórios.

| Etapa | Ação física | Duração sugerida |
|---|---|---:|
| A | Tudo solto, sem tocar na guitarra | 10 s |
| B | Pressionar e soltar cada traste separadamente: verde, vermelho, amarelo, azul e laranja, se existir | 2 s pressionado + 2 s solto por botão |
| C | Strum para cima repetidamente | 10 s |
| D | Strum para baixo repetidamente | 10 s |
| E | Mover o whammy lentamente por toda a faixa e retornar | 10 s |
| F | Inclinar a guitarra e voltar à posição normal | 10 s |
| G | Start/Select e outros botões, cada um separadamente | 2 s pressionado + 2 s solto |
| H | Manter um traste pressionado enquanto faz strum; depois soltar tudo | 10 s |
| I | Tudo solto novamente | 10 s |

Se a guitarra não tiver um botão, marcar `N/A`. Descrever a ação física; não presumir qual byte ou bit corresponde ao controle.

6. Anotar para cada ação o horário de início/fim e se houve mudança visível no log.
7. Salvar imediatamente `app-service.log`, `vpad.log` e o kernel log separado, se disponível.

**Importante:** o build diagnóstico anterior foi descrito como captura de relatórios brutos; ele não tinha decoder GH5 completo. Receber relatório de 27 bytes não prova mapeamento de trastes/strum. A coleta precisa preservar os bytes hexadecimais, caso o build tenha essa instrumentação. Se não aparecer nenhuma linha `gh5: RAW report=...` ou equivalente, registrar isso como `NOT AVAILABLE`; não inventar payloads nem assumir que a captura bruta está ativa.

---

## 8. Teste GH5 — o que os logs precisam registrar

### 8.1 USB / transferência interrupt-IN

Solicitar ao desenvolvedor/build preparer, de preferência com resumo limitado a uma linha por segundo:

| Campo | Para que serve |
|---|---|
| Totais de `USB_FS_START` bem-sucedidos e `USB_FS_COMPLETE` bem-sucedidos | Medir progresso real, não só quantidade de linhas impressas. |
| Total de `EBUSY` | Distinguir contagem real de amostras limitadas pelo logger. |
| Tempo desde último COMPLETE bem-sucedido | Mostrar quanto tempo a transferência ficou sem conclusão válida. |
| Tempo desde último input recebido | Mostrar se o receptor parou de entregar input ou se os pacotes apenas não mudaram. |
| Idade da transferência pendente | Identificar uma transação que permanece ativa tempo demais. |
| Sucessos e rejeições do decoder | Separar recebimento USB de mapeamento/protocolo. |
| Geração da conexão, caminho do dispositivo, fd, interface e endpoint | Diferenciar reconexões e reutilização do número do fd. |
| Índice de endpoint concluído | Identificar a origem após um COMPLETE que realmente teve sucesso. |
| Relatório bruto HID em hexadecimal, comprimento e timestamp | Permitir identificar quais bytes mudam ao operar os controles. |

**Regra de interpretação:** `endpoint status`, `aFrames`, `actual length` e endpoint concluído só devem ser apresentados como resultado de conclusão quando `USB_FS_COMPLETE` tiver sucesso. Valores impressos depois de `EBUSY` ainda podem descrever a requisição pendente, não uma conclusão nova.

O valor `poll_revents=0x41` deve ser mantido exatamente como observado. Não atribuir significado simbólico sem confirmação dos headers/constantes usados no ambiente PS5/FreeBSD. Os snapshots anteriores não provam, sozinhos, a causa de EBUSY ou que a fila esteja travada.

### 8.2 VDA / klog / MBus

Preservar as linhas completas e o contexto ao redor de:

```text
AddDevice ...
identification source=... add_rc=... bytes=... lines=...
device_added=... mbus_events=... candidates=... eof=... read_errno=...
virtual pad not identified ...
device ... bound to user ...
InsertData ...
```

A nova #29 pede que o processo confirme o modo não bloqueante do socket TCP. Capturar também a origem usada e os contadores da janela de identificação.

Interpretação:

- `bytes=0`: nenhum byte chegou ao leitor nessa janela. O parser decimal não foi exercitado; verificar provider, dono do stream, configuração, janela e concorrência de leitores antes de mudar parser.
- `EOF` ou `read_errno`: preservar exatamente valor e mensagem; não classificar como ausência normal de evento.
- Bytes sem `DEVICE_ADDED`: o stream entregou dados, mas o evento necessário não apareceu no trecho observado.
- Evento bruto presente sem candidato: preservar o formato real da linha e os campos para revisão do parser/filtro.
- `AddDevice 0x803b0006`: registrar literalmente. Não chamar automaticamente de falha nem de sucesso; as capturas mostram que esse retorno também pode anteceder bind bem-sucedido em outras sessões.
- Candidato/handle identificado e bind com retorno zero: comprova uma etapa de associação, não o funcionamento dos botões.
- `InsertData` bem-sucedido e estado decodificado: registrar separadamente. Só o teste físico em jogo confirma que o input chegou e foi mapeado corretamente.

Não publicar IDs de usuário, handles ou identificadores de console em comentário público. Enviar originais por canal privado.

### 8.3 Estado decodificado e input real

O desenvolvedor quer distinguir associação correta de controle inativo. Registrar separadamente:

- controle virtual criado;
- evento MBus identificado;
- bind efetuado e retorno;
- usuário selecionado (redigir o ID nos envios públicos);
- número/resultado das chamadas `InsertData`;
- botão/estado decodificado para cada ação física;
- resultado no jogo: `PASS`, `FAIL` ou `NOT VERIFIED`.

Um controle pode estar associado e ainda não transmitir botões úteis. Não encerrar o teste na tela de atribuição ou no retorno de bind.

---

## 9. Teste GH5 — sessão 2: probe VDA/MBus opcional

Executar somente depois de salvar a sessão 1. Antes de criar o marcador, confirmar com o desenvolvedor que o ELF carregado implementa exatamente esse mecanismo.

1. Parar/descarregar o serviço conforme o procedimento suportado.
2. Criar um arquivo de zero bytes em:

   `/data/ghostcontrol-app-service/gh5-vpad-probe.enable`

3. Reiniciar/carregar o mesmo ELF. O estado é lido no início do processo; criar o arquivo com o processo já em execução não ativa o probe.
4. Confirmar no startup log uma mensagem inequívoca de probe habilitado. Se não aparecer, interromper e registrar `probe enablement NOT VERIFIED`.
5. Repetir a sequência da Seção 7 e salvar os dois logs e o kernel log.
6. Neste modo anterior, cada relatório GH5 pode fazer o serviço enviar um `ScePadData` neutro pelo caminho VDA. Isso verifica criação/identificação/bind, **não mapeia os botões da guitarra**.
7. Não testar em jogo até que os logs demonstrem identificação/bind e o desenvolvedor confirme que o caminho de input é seguro para esse teste.
8. Depois de salvar a coleta, parar o payload e remover o marcador.

Se o resultado terminar em `virtual pad not identified` ou zero candidatos, não relançar repetidamente o probe. O serviço foi projetado para não adivinhar handles. Salvar logs, remover o marcador, parar o payload e seguir a orientação do desenvolvedor; o README diagnóstico anterior recomenda reiniciar o PS5 para limpar estado VDA pendente antes de repetir uma nova tentativa. Não executar outro leitor de klog TCP 3232 durante a janela.

---

## 10. Teste de desconexão/reconexão USB

Fazer em uma sessão separada, com a captura ativa:

1. Marcar o horário e retirar o receptor.
2. Aguardar 5 segundos.
3. Recolocar no mesmo conector USB e ligar a guitarra normalmente.
4. Repetir estado neutro, um traste, strum para cima/baixo e whammy.
5. Anotar separadamente:
   - feed antigo aposentado/fechado;
   - nova geração de conexão;
   - receiver reaberto;
   - novo START/COMPLETE bem-sucedido;
   - novos relatórios HID;
   - decoder retomou;
   - VDA/bind retomou;
   - input funcionou no jogo.

Uma mensagem `opened` sozinha não prova que o input voltou. O fd pode ser reutilizado; usar o contador de geração da conexão, se estiver disponível. Se repetir a falha, fazer uma sessão comparativa mudando somente um item, por exemplo a porta USB.

---

## 11. Sessões opcionais separadas

### 11.1 Dispositivo `040B:0897`

Executar somente se esse dispositivo estiver fisicamente conectado e sua identidade puder ser confirmada. Nos logs anteriores do arquivo test1/Experimental test2 não apareceu um identificador correspondente, então não sabemos se estava conectado naquela coleta.

Registrar:
- VID:PID observado e caminho USB;
- quantas tentativas de abertura ocorreram;
- intervalo/taxa das tentativas;
- contagem de falhas e contagem de linhas efetivamente impressas;
- se as tentativas continuam após rate limit do logger.

Log mais silencioso não prova que o serviço continua tentando abrir. É necessário contador de tentativas ou evidência equivalente. Não pedir ao usuário para bloquear o dispositivo nem mudar a política de admissão sem instrução do mantenedor.

### 11.2 DS4 USB, DS4 wireless e rumble (PR #29 + interação com #32)

Usar sessões distintas para não misturar origem USB e origem RemotePlay/wireless.

- Registrar a identidade do DS4 e o `ConnectionType` observado no runtime.
- Verificar startup e hotplug.
- Confirmar que o mesmo DS4 não é capturado ao mesmo tempo por rota USB local e ponte RemotePlay.
- Se a origem aparecer como wireless, registrar o valor real de `ConnectionType`; não inferir pelo rótulo da interface.
- Iniciar jogo que emita vibração real; capturar comando `scePadSetVibration`, fonte/handle pareado, retorno do relay e observação física dos motores.
- Testar comando de parada/zero e verificar que os motores param em remoção de rota, saída do jogo e suspend.
- Repetir após resume/reconexão.

### 11.3 Bluetooth Classic/LE (PR #33)

Usar controle Bluetooth que possa ser pareado novamente e fazer sessão independente da guitarra.

1. Parear o controle e guardar os logs de persistência. Distinguir “key(s) stored” de “key(s) only in memory”.
2. Reiniciar o serviço/console pelo procedimento normal e verificar se o bond continua disponível.
3. Fazer `Forget` pela interface e registrar retorno real do host, mensagem de persistência e estado após reiniciar.
4. Não interpretar aceitação assíncrona na interface como prova de que o banco foi gravado.
5. Em falha de escrita, registrar se o comportamento é o upstream `b11e3ee` (remoção em memória, registro antigo ainda no disco e potencial retorno após reinício) ou uma extensão local com rollback de RAM. Não provocar falha de permissões nem danificar diretórios deliberadamente.
6. Se ocorrer naturalmente, capturar recusas Inquiry `0x0c` e falha de envio. A sequência esperada é 500 ms, 1 s, 2 s, 4 s, máximo 8 s; o backoff deve reiniciar somente após aceitação pelo controlador.
7. Se o input só aparecer depois de “desligar alguma coisa”, registrar o que foi desligado e o momento exato. Comparar em sessões separadas: busca ativa vs. busca expirada e Toolbox aberta vs. fechada. Manter o modo físico do controle fixo.
8. Não parar automaticamente a descoberta só porque o link ficou ready: a janela de busca pode ser necessária para parear outros controles, e um link pronto não prova que o controle físico saiu do modo de pareamento.

**Histórico Bluetooth já observado:** uma captura anterior identificou Xbox LE `045e:0b22`, em estado ready-as-Xbox e bind em quatro tentativas; também registrou 412 respostas Inquiry recusadas e falhas de gravação/forget. Isso é evidência de comportamento anterior, não validação do build atualizado.

---

## 12. O que os registros antigos já provam — e o que não provam

A documentação do desenvolvedor que acompanha a #33 interpreta os arquivos enviados anteriormente da seguinte forma:

- O receptor `12ba:0100` foi detectado; descritor HID de 137 bytes lido e relatórios interrupt de 27 bytes recebidos.
- Uma sessão tem oito payloads distintos de 27 bytes, com alterações no primeiro byte de botões. Isso mostra que a operação da guitarra chega ao logger, mas não identifica cada traste/strum/controle analógico.
- As duas sessões anteriores tinham `VDA probe mode disabled: raw USB logging only`. Portanto, uma pasta chamada VDA/MBus não prova injeção ativa.
- Também aparecem respostas de controle constantes de três bytes `00 00 6e`; não tratá-las como estado completo do controle.
- Os dois `vpad.log` de `test1` e `Experimental test 2` têm 24 conclusões bem-sucedidas registradas com input de 27 bytes. Isso é quantidade de conclusões registradas, não throughput contínuo nem prova de mapeamento.
- O Test 2 tem 54 linhas de diagnóstico `EBUSY` amostradas, com o contador de amostra chegando a `2432`. **2432 é o valor do contador de amostras, não 2.432 linhas impressas nem prova de 2.432 travamentos independentes.**
- O tuple amostrado foi `fd=12`, interface `0`, endpoint `0x81`, poll flags `0x41`, um frame solicitado, zero frames concluídos, comprimento pedido/atual 64 e endpoint status zero. Metadados de uma conclusão que falhou não são resultado de conclusão válida; não deduzir causa raiz somente desses valores.
- Os dois testes registraram `AddDevice 0x803b0006` e depois zero bytes/linhas/eventos MBus/candidatos na janela. Isso não valida nem invalida o parser decimal: nenhum evento chegou.
- Há evidência de fechamento de handle após `ENOTTY` e reabertura do receptor; input/bind bem-sucedido depois da reconexão não ficou estabelecido.
- Nenhum identificador `040b:0897` aparece nos arquivos; a taxa de retry/rate limit desse dispositivo não foi verificada.
- O significado de `0x803b0006` deve ser preservado como retorno observado, sem rotular como erro ou sucesso isoladamente.

**Prioridade da investigação:** primeiro demonstrar a entrega de klog/MBus e correlacionar START → poll → COMPLETE; depois demonstrar relatórios brutos e estado decodificado; por último testar bind/InsertData e gameplay. Não alterar o parser decimal enquanto não existir evento bruto para analisar.

---

## 13. Estrutura dos arquivos a enviar ao desenvolvedor

Manter o original, sem editar, e organizar um ZIP por conjunto de sessões:

```text
Lemos-Ghostcontrol-tests/
  build-info/
    build-notes.md
    sha256.txt
    included-commits.txt
  guitar-baseline-raw/
    test-notes.md
    app-service.log
    vpad.log
    kernel-log.txt              # somente se capturado separadamente
    video.mp4                   # opcional
  guitar-vda-probe/
    test-notes.md
    app-service.log
    vpad.log
    kernel-log.txt              # somente se capturado separadamente
  guitar-reconnect/
    test-notes.md
    app-service.log
    vpad.log
  device-040b-0897/             # somente se o dispositivo estiver presente
    test-notes.md
    app-service.log
    vpad.log
  ds4-wireless-rumble/          # somente se testado
    test-notes.md
    app-service.log
    vpad.log
  bluetooth-bond-inquiry/       # somente se testado
    test-notes.md
    app-service.log
    vpad.log
```

`kernel-log.txt` é nome sugerido para um arquivo separado, não é uma saída garantida do serviço. Não incluir jogos, BIOS, credenciais nem SDK proprietário. Antes de postagem pública, remover IDs pessoais/handles de usuário/IDs de console. Originais sensíveis devem ser enviados por canal privado.

---

## 14. Fechamento da ficha de cada sessão

Preencher ao terminar:

```text
USB receiver detected: PASS / FAIL / NOT VERIFIED
HID descriptor read: PASS / FAIL / NOT VERIFIED
USB START succeeded: PASS / FAIL / NOT VERIFIED
USB COMPLETE succeeded: PASS / FAIL / NOT VERIFIED
EBUSY interleaved with successful completions: YES / NO / UNKNOWN
Successful START total:
Successful COMPLETE total:
EBUSY total (actual counter):
EBUSY lines printed/sampled:
Longest gap during active controls:
Last successful COMPLETE timestamp:
Last input timestamp:
Raw HID payload changed with controls: PASS / FAIL / NOT VERIFIED
Decoded state changed with controls: PASS / FAIL / NOT VERIFIED
Kernel-log socket nonblocking setup: PASS / FAIL / UNKNOWN
Kernel-log bytes/events received: YES / NO / UNKNOWN
DEVICE_ADDED observed: YES / NO / UNKNOWN
Virtual device identified: PASS / FAIL / NOT VERIFIED
User bind: PASS / FAIL / NOT VERIFIED
InsertData: PASS / FAIL / NOT VERIFIED
Each physical control mapped correctly: PASS / FAIL / NOT VERIFIED
Game input: PASS / FAIL / NOT VERIFIED
Input after unplug/replug: PASS / FAIL / NOT VERIFIED
DS4 physical rumble (if tested): PASS / FAIL / NOT VERIFIED
Bluetooth bond persisted after restart (if tested): PASS / FAIL / NOT VERIFIED
Forget persisted after restart (if tested): PASS / FAIL / NOT VERIFIED
Inquiry retry backoff observed (if tested): PASS / FAIL / NOT VERIFIED
Exact failure timestamp and action:
One change from previous session:
Other observations:
```

---

## 15. Critério para considerar uma correção demonstrada

Uma correção forte deve:

1. Reproduzir o defeito no build baseline identificado por commit e SHA-256.
2. Mostrar nos logs a condição causal, e não apenas um sintoma amostrado.
3. Aplicar uma correção focada, com o restante do ambiente constante.
4. Repetir a mesma sequência no build corrigido.
5. Testar hotplug/reconnect e outros controles para procurar regressões.
6. Separar testes host/CI, build completo do SDK e teste físico no PS5. Um não substitui o outro.

Até essa evidência existir, manter como **NOT VERIFIED**: causa raiz do `EBUSY`, entrega de klog/MBus no firmware 11.60, funcionamento completo do GH5, mapeamento de trastes/strum/whammy, recuperação de input após reconnect e rumble físico quando não observado no hardware.

---

## 16. Referências

- [PR #29 — fix: repair DS4 discovery, USB reads, and rumble forwarding](https://github.com/StonedModder/Ghostcontrol-PS5-USB-Controller-Patcher/pull/29)
- [PR #29 — commits atuais](https://github.com/StonedModder/Ghostcontrol-PS5-USB-Controller-Patcher/pull/29/commits)
- [PR #29 — diff atual](https://github.com/StonedModder/Ghostcontrol-PS5-USB-Controller-Patcher/pull/29/files)
- [PR #32 — USB HID, Xbox GIP, DS3 e DS4 lightbar](https://github.com/StonedModder/Ghostcontrol-PS5-USB-Controller-Patcher/pull/32)
- [PR #32 — commits atuais](https://github.com/StonedModder/Ghostcontrol-PS5-USB-Controller-Patcher/pull/32/commits)
- [PR #32 — diff atual](https://github.com/StonedModder/Ghostcontrol-PS5-USB-Controller-Patcher/pull/32/files)
- [PR #33 — Bluetooth bond storage e inquiry retry](https://github.com/StonedModder/Ghostcontrol-PS5-USB-Controller-Patcher/pull/33)
- [PR #33 — commits atuais](https://github.com/StonedModder/Ghostcontrol-PS5-USB-Controller-Patcher/pull/33/commits)
- [PR #33 — diff e documentação USER-LOG-REGRESSIONS.md](https://github.com/StonedModder/Ghostcontrol-PS5-USB-Controller-Patcher/pull/33/files)

**Limite da consulta:** as listas e descrições públicas das PRs e o conteúdo visível de `USER-LOG-REGRESSIONS.md` foram usados para atualizar este guia. O corpo integral de todas as conversas/review threads não ficou visível no carregamento público; para a #32, o follow-up técnico foi preservado do relatório de revisão já existente no pacote anterior e deve ser confirmado contra o commit/diff exato do ELF entregue.
