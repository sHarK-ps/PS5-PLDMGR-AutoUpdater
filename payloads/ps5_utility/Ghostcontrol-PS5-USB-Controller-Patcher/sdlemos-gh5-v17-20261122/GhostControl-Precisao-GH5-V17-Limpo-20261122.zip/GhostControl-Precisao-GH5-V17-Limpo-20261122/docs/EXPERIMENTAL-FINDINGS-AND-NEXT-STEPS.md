# GhostControl GH5 — Diagnóstico experimental adicional

Esta variante contém as mesmas integrações conservadoras das PRs #29, #32 e #33. Além disso, modifica apenas a observabilidade dos dois gargalos nos logs; não altera a estratégia de transferência, não bloqueia dispositivos e não inventa handles.

## Instrumentação adicional

### 1. `USB_FS_COMPLETE` / `EBUSY` no receptor GH5

Para `12BA:0100`, registra amostras detalhadas na falha de `USB_FS_COMPLETE`: caminho, file descriptor, interface, endpoint IN, errno, estado busy, `poll_revents`, número de frames solicitados, frames concluídos (`aFrames`), comprimento informado, tamanho de transferência solicitado e status do endpoint. Registra as primeiras 16 falhas e depois uma amostra a cada 64 falhas para limitar volume.

A intenção é distinguir: descriptor/endpoint incorreto, ausência de prontidão, frames ainda não concluídos e erro devolvido pelo ioctl. O código não presume que `EBUSY` seja seguro para rearmar nem troca o ciclo USB sem evidência.

### 2. Ruído repetitivo do dispositivo `040B:0897`

As tentativas `open` continuam ocorrendo normalmente. Apenas a mensagem repetida é limitada: primeiras quatro falhas e depois uma amostra a cada 256 tentativas, com contador acumulado. O dispositivo não é ignorado, desabilitado nem removido da enumeração.

### 3. O que permanece igual

- Parser MBus decimal/hexadecimal e captura de eventos da variante conservadora.
- Captura HID bruta específica de `12BA:0100`.
- Ciclo VDA/MBUS já existente na base diagnóstica.
- Sem tentativa de associar um handle por adivinhação.
- Sem alteração da lógica de transferência USB para “corrigir” `EBUSY` sem conhecer o resultado dos novos campos.

## Critério para o próximo diagnóstico

- `poll_revents=0` / sem prontidão: investigar estado/descritor e semântica de `poll` no endpoint FreeBSD USB FS.
- Prontidão presente, `aFrames=0`, `status=0` e `EBUSY`: solicitar revisão do ciclo START/COMPLETE e dos requisitos do ioctl para esse endpoint.
- `aFrames=1` ou comprimento preenchido apesar do retorno EBUSY: investigar se o ioctl reporta a conclusão por um caminho parcial e se o buffer foi atualizado; não consumir os bytes sem validar a semântica da API.
- `MBus bytes=0`: a etapa de captura não recebeu bytes; priorizar exclusividade/entrega do klog, não o parser decimal.
- Evento bruto presente, mas nenhum candidato: conferir formato real, subtype/deviceType, deviceId e janela temporal antes de mudar o filtro.

## Limites

Esta variante é código-fonte diagnóstico. Ela não foi compilada com o PS5 Payload SDK, não gerou ELF e não foi executada no firmware 11.60. Os dados adicionais precisam ser coletados no console antes de decidir uma alteração funcional.


## Instrumentação exclusiva Experimental — nova revisão

`VARIANT=gh5-precision` liga `GC_GH5_USB_DIAGNOSTIC=1` e `GC_GH5_PRECISION_DIAGNOSTIC=1` e produz `GhosttoothAPI-GH5-precision.elf`. A variante Conservadora não possui esses extras.

A cada ~1 s, enquanto houver feed `12BA:0100`, escreve `gh5: progress` incluindo: `generation` (incrementa a cada reabertura; fd sozinho pode repetir), `path`, `fd`, interface, endpoint, START bem-sucedidos, COMPLETE bem-sucedidos e status zero, EBUSY acumulado, sucesso/rejeição de **publicação decodificada**, tempo desde última conclusão, último relatório de input bruto, idade de transferência pendente, status busy e último índice `done.ep_index` após sucesso. Um resumo final é emitido ao fechar feed. `-1` nas idades significa que ainda não houve evento ou que não existe transferência pendente.

Também mantém as amostras dos primeiros 16 erros EBUSY e depois a cada 64, agora com prefixo `pending-snapshot`: `aFrames`, `len` e `ep_status` registrados após erro **não são resultado válido de conclusão**; são estado pendente e não provam stall. Só as linhas `FS_COMPLETE ok` reportam metadata validada pela conclusão. `040B:0897` mantém as mesmas tentativas USB, com log das primeiras 4 falhas e uma a cada 256; nenhum dispositivo é bloqueado.

**Interpretação cautelosa:** no estágio de captura bruta sem marcador, o decoder GH5 devolve intencionalmente “não publicar”; `decode_rejected` pode crescer mesmo com relatórios válidos. É um contador de amostras não publicadas, não prova rejeição por mapeamento ou erro da guitarra. A captura dos bytes hex (`gh5: RAW report`) é a evidência de mudança física. Os contadores não alteram o comportamento do ioctl USB, temporização, endpoint, credenciais ou seleção VDA.
