> **Histórico: superado pela integração de 10/11/2026.** Leia `../INTEGRACAO-ATUALIZADA-PR29-PR32-PR33.md` antes de aplicar correções.



## PR #33 follow-up: db_forget persistence result

The follow-up review note said `db_forget()` still ignored the new `db_save()` result. This integration checks that result. A failed save restores the bond in the live in-memory database so RAM remains consistent with the still-existing on-disk record. The operation returns failure and emits a warning; `host_forget()` does not claim durable deletion.


### Follow-up implementation detail

`db_forget()` now returns a durability result and rolls back its in-memory mutation if saving fails. `host_forget()` propagates failure instead of showing success. Pairing replacement aborts if it cannot durably remove the old bond.
