> **LOCAL LEGACY SUMMARY, NOT LATEST FULL #33 UPSTREAM DOC.** The full latest public document is tracked in [PR #33 files](https://github.com/StonedModder/Ghostcontrol-PS5-USB-Controller-Patcher/pull/33/files). See `../AUDIT-2026-11-11-R2.md` for an up-to-date overview.

# Resultados dos logs e próximos testes

Este documento acompanha as correções de Bluetooth da PR #33 e registra o que os logs do usuário realmente demonstram. As alterações de armazenamento/inquiry não corrigem por si só a guitarra nem afirmam compatibilidade total.

## Bluetooth — PR #33

Os problemas da PR incluem falhas de escrita do `controllers.db.new` com `errno=2` quando a pasta-pai ainda não existe, seguidas por mensagens que afirmavam que as chaves foram armazenadas. Agora o salvamento cria diretórios ausentes e retorna sucesso/falha. Classic e LE informam se as chaves foram persistidas ou se existem apenas na memória desta sessão.

A documentação da PR #33 também descreve uma captura Xbox LE com 412 respostas de inquiry `0x0c`. O backoff de HCI Inquiry foi ajustado para não reiniciar antes do retorno do comando. Respostas recusadas repetidas (`0x0c`) aguardam 500, 1000, 2000, 4000 e no máximo 8000 ms; o backoff é zerado somente quando o controlador aceita o comando.

O teste host `tools/tests/test_log_regressions.py` compila as rotinas reais de store, `db_forget` e inquiry extraídas do código de produção. Ele inclui o follow-up da revisão: se a remoção não for persistida, `db_forget()` restaura o vínculo em RAM, retorna falha e `host_forget()` não anuncia sucesso.

## Guitar Hero — receptor `12BA:0100`

Nos logs mais recentes analisados:

- o receptor `12BA:0100` abriu em `/dev/ugen2.2`;
- o serviço recebeu 16 relatórios `len=27`;
- foram observadas 6 falhas `USB_FS_COMPLETE errno=16 (Device busy)`;
- não apareceu evento novo `DEVICE_ADDED`, e a sessão terminou em `virtual pad not identified (0 candidates)`;
- houve aproximadamente 2.745 falhas de abertura do outro dispositivo `/dev/ugen1.2`, VID:PID `040B:0897`, principalmente `Inappropriate ioctl for device`, com algumas `Device not configured` e `Broken pipe`.

A leitura de 27 bytes demonstra que dados USB chegam ao serviço, mas não revela, por si só, o significado de cada botão/traste nem confirma a criação/associação do controle virtual. A ausência de `DEVICE_ADDED` nos logs antigos também significa que eles não exercitaram a correção decimal do parser.

## USB e vibração DS4

A PR #32 propõe/integra tratamento de retirada USB, tamanho de transferência e pedidos HID. A PR #29 encaminha o rumble do jogo ao DS4 de origem. A vibração física precisa ser confirmada no console com uma solicitação real do jogo, o handle do controle correspondente, retorno da chamada de relay e observação do usuário. Nenhuma confirmação física é inferida apenas de uma compilação ou de registros de serviço.

## Próxima captura recomendada

1. Execute primeiro a captura USB bruta, sem o marcador de probe VDA, e confirme que o log informa os relatórios de 27 bytes.
2. Depois de guardar a captura bruta, habilite o marcador `/data/ghostcontrol-app-service/gh5-vpad-probe.enable` conforme `README-GH5-DIAGNOSTIC.md`; confirme no log de inicialização que o modo probe foi ativado.
3. Registre uma linha de base neutra e, separadamente, cada traste, strum para cima/baixo, whammy e tilt, com sequência anotada e timestamps correspondentes.
4. Colete a criação do dispositivo virtual, evento MBus bruto, parse de `deviceType`/`deviceId`, bind do usuário e resultado de `InsertData`.
5. Só depois da confirmação de bind e injeção teste os controles dentro do jogo. O tráfego USB bruto não é suficiente.

O modo de probe é diagnóstico; não é o decoder final da guitarra. Não repita a criação do dispositivo em sequência quando o handle não for identificado. Siga o procedimento de desligamento/limpeza no README para evitar estado virtual pendente.
