# GitHub CI HEAD checks verified on 2026-11-11

- PR #29 `147e1cc`: DS4 bridge and virtual pad parser PASS (run 42950454891), CI PASS (42950454877).
- PR #32 `3e4ef90`: CI PASS (42428696681).
- PR #33 `9ee7019`: CI PASS (42950454815), User log regressions PASS (42950454718).

These checks run on *individual PR heads*, not this combined local tree. Local combined tests have been executed separately (see HOST-TEST-RESULTS). No PS5 SDK/ELF/hardware validation has been done.
