# Changes 2026-11-12 — Precisão

- PR #29: `7aff684` (fallback remains active for quiet input after decoded control), `9c059b5` (invalid control replies do not publish neutral/saved-profile input; OUT completion cannot clear pending IN), `3f2917d` (default guitar Button1/2/3 mapped to Square/Cross/Circle only for 12BA:0100), `3c4341c` (klog preflight and first InsertData success), `cd58070` (bounded per-connection GH5 transport progress).
- PR #33: `ebbbdfb`/`55bc1ae` updated lifecycle guards and capped cancellation while preserving local rollback on failed bond persistence.
- PR #32: no HEAD change; prior endpoint-size, GET_REPORT, cached descriptor and invalidation, async GIP, DS3 and DS4 support retained.


The default `gh5-diagnostic` build **does not decode physical frets**: raw-only when the marker is OFF and neutral-frame VDA probe when ON. The new device-specific default HID mapping is reachable in the standard `resident` decoder, not proof the GH5 diagnostic ELF produces playing controls. Do not infer game compatibility from successful neutral InsertData.

The `gh5-precision` build retains the same raw-only/neutral-probe GH5 behavior, plus source-labelled RAW reports (`INTERRUPT_IN`/`CONTROL_GET_REPORT`), generation-aware per-source 24/s + 3/s log budgets, drop counters, EBUSY snapshots, controlled `040B:0897` message rate and legacy `gh5: progress`. In addition, the upstream `usb progress:` line records possible-stall/progress-resumed and distinguishes `endpoint_address` vs `transfer_index`. The legacy `last_completed_ep` label is clarified as `last_completed_transfer_index`. These are separate diagnostic lines; not independent USB completions.
