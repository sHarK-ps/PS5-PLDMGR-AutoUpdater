# Alterações efetivas desde GhostControl_Experimental.zip

Este patch compara o ZIP anterior com a árvore atual. Não inclui imagens/binários nem é comprovante de compilação.

## Arquivos novos ou modificados:

- `.github/workflows/log-regressions.yml`
- `.github/workflows/vpad-parser.yml`
- `COMPILE-PS5-FIRST.md` (novo)
- `GhosttoothAPI/Makefile`
- `INTEGRACAO-ATUALIZADA-PR29-PR32-PR33.md` (novo)
- `LEIA-ME-PT-BR.md`
- `PACKAGE-INFO.md`
- `build_elf.sh` (novo)
- `core/src/bt/host.c`
- `core/src/bt/ps5_vpad.c`
- `core/src/gc_ds4_bridge.c`
- `core/src/gc_ds4_source.c`
- `core/src/gc_service_inject.c`
- `docs/EXPERIMENTAL-FINDINGS-AND-NEXT-STEPS.md`
- `docs/GUIA-MESTRE-Lemos-v3.md` (novo)
- `docs/INTEGRACAO-PR29-PR32-PR33.md`
- `docs/PR_INTEGRATION_NOTES.md`
- `docs/README-Lemos-Ghostcontrol-Testing.md` (novo)
- `run_host_tests.sh` (novo)
- `tools/tests/test_experimental_diagnostics.py`
- `tools/tests/test_log_regressions.py`
- `tools/tests/test_pr29_followups.py` (novo)
- `tools/tests/test_pr29_pr32_pr33_integration.py`
