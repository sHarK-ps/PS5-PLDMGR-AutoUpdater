# Ghostcontrol testing guide for Lemos

Thank you for testing. This guide explains what to run, what to record, and what
to send back so we can investigate the Guitar Hero receiver without guessing.

## 1. What we are testing

There are two separate paths to check:

1. **USB input:** does the receiver keep delivering reports while you operate the guitar?
2. **Virtual controller:** does Ghostcontrol create, identify and bind the controller so a game can use it?

The previous captures show successful 27-byte USB reports interleaved with
`USB_FS_COMPLETE / EBUSY`. They also show `AddDevice 0x803b0006` and an
identification window with zero kernel-log bytes and zero candidates. These
observations do not establish the EBUSY root cause or successful gameplay.

Related pull requests:

- [PR #29 — virtual-pad discovery, USB readiness and DS4 rumble](https://github.com/StonedModder/Ghostcontrol-PS5-USB-Controller-Patcher/pull/29)
- [PR #32 — controller and USB lifecycle work](https://github.com/StonedModder/Ghostcontrol-PS5-USB-Controller-Patcher/pull/32)
- [PR #33 — Bluetooth persistence, inquiry retry and log findings](https://github.com/StonedModder/Ghostcontrol-PS5-USB-Controller-Patcher/pull/33)

The latest follow-up commits when this guide was written are `088e1b7` for #29
and `7a744e7` for #33. Record the actual commits used in your build; a PR number
or the name “Experimental” does not identify its contents precisely.

## 2. Check the test build first

Ask the person preparing the combined build to provide:

- The source repository and exact combined-build commit.
- The included commits from #29, #32 and #33, including review fixes.
- The ELF filename and SHA-256 hash.
- The Experimental instrumentation changes, preferably as a commit or diff.
- Instructions for its existing logging/probe options.

Do not combine separate service ELFs by running them together. The combined
build must contain the intended changes in one service, with one service
instance owning the receiver.

If you are only testing a supplied build, you do not need to compile anything.
The build preparer can calculate the ELF hash, for example on Linux:

```sh
sha256sum GhosttoothAPI.elf
```

### Already implemented in the #29 follow-up

- Check that the TCP kernel-log socket was successfully made nonblocking.
- Report the AddDevice return value together with identification byte, line,
  event and candidate counts, EOF and read errno.
- Distinguish silent log input from failed reads, an ended TCP stream, missing
  device events and events that do not match a virtual DualSense.

These changes improve diagnosis. They do not change the USB transfer mechanism
or resolve the guitar's EBUSY root cause.

### Recommended instrumentation — not yet implemented by these PRs

Ask the Experimental build preparer for a bounded, once-per-second USB summary
containing the following. If the build does not have it, say so in the report;
do not invent values or expect a menu switch that has not been supplied.

| Measurement | Why we need it |
|---|---|
| Successful START and COMPLETE totals, plus EBUSY total | Shows progress between errors |
| Time since the last successful completion and input | Shows whether input actually stops |
| Outstanding-transfer age | Identifies a transfer that remains pending |
| Decode successes and rejections | Separates USB delivery from mapping problems |
| Connection generation, device path, fd, interface and endpoint | Separates sessions when an fd is reused |
| Completed endpoint index after successful COMPLETE | Shows which endpoint supplied a completion |

Record endpoint status, completed frames and actual length as completion results
only after COMPLETE succeeds. Values printed after EBUSY may still describe the
pending request. The existing sampled error lines alone cannot establish a stall.

## 3. Record the environment

Copy this into `test-notes.md` and fill it in:

```text
Tester: Lemos
Test date/time and timezone:
PS5 model:
PS5 firmware:
Jailbreak/HEN and version:
ELF loader and version:
Ghostcontrol/Experimental version:
Combined source URL and full commit:
PR #29 commit:
PR #32 commit:
PR #33 commit:
ELF filename and SHA-256:
Kernel-log provider/payload and version:
Kernel-log configuration:
Guitar model:
Receiver VID:PID: 12ba:0100
USB port, cable/adapter/hub used:
Other connected controllers:
Toolbox open or closed during capture:
Diagnostic/probe options enabled:
Game/title and version, if tested:
Extra USB progress summary available: YES / NO
```

If something is unknown, write `UNKNOWN`. Avoid changing firmware, loader,
payload settings or USB options just to fill a field.

## 4. Prepare one clean session

1. Use your normal working jailbreak and loader procedure.
2. Confirm that an older Ghostcontrol service instance is not still running.
   Use the project's supported stop/start procedure. If its state is uncertain,
   use your normal reboot and payload-loading procedure before testing.
3. Start the intended test build once, with the guitar receiver unplugged.
4. Start a fresh log capture using your existing logging method. Keep
   `app-service.log` and `vpad.log` from this same session together.
5. Close the Ghostcontrol Toolbox for the baseline test. Record any later opening
   of the Toolbox and its time. Keep a normal controller available if needed.
6. Connect the receiver directly to one PS5 USB port, without a hub where possible.
7. Turn on/connect the guitar normally. Note the time of connection.

Do not change transfer sizes, timing, endpoint-reset behavior or credential
settings during the baseline. We need a reproducible starting point.

## 5. Run the guitar sequence

Record the time for every step. A phone video showing your hands and the screen
can help correlate actions, but written timestamps are sufficient.

| Step | Action | Suggested duration |
|---|---|---|
| A | Leave every control released | 10 seconds |
| B | Press/release green, red, yellow, blue and orange separately, if present | Hold each 2 seconds, then release 2 seconds |
| C | Strum up repeatedly, then strum down repeatedly | 10 seconds each |
| D | Move the whammy slowly through its range and return it | 10 seconds |
| E | Tilt, then return to the normal position | 10 seconds |
| F | Test Start/Select and other available controls separately | Hold each 2 seconds, then release |
| G | Hold one fret while strumming, then release everything | 10 seconds |
| H | Leave every control released again | 10 seconds |

Mark controls that do not exist on this model `N/A`. Describe the physical
action; do not assume a report byte or bit corresponds to that control yet.

The most useful observation is: **how long since the last successful USB
completion while the guitar is actively being operated?**

## 6. Capture virtual-pad identification

Keep these lines, including the surrounding context:

```text
AddDevice ...
vpad: slot ... identification source=... add_rc=... bytes=... lines=...
device_added=... candidates=... eof=... read_errno=...
virtual pad not identified ...
device ... bound to user ...
```

The identification summary is one log line; it is wrapped above for readability.
Do not publish user identifiers from binding messages in a public comment.

- **No bytes:** the parser received nothing to identify. Check the configured
  kernel-log provider before changing parsing rules.
- **EOF or read error:** preserve the exact message and errno for investigation.
- **Bytes but no device events:** log delivery exists, but the required event was
  not observed in that window.
- **Device events but no match:** preserve their format for parser review.
- **Binding success:** proceed to a suitable game and test each control. Creation
  or binding alone is not proof that gameplay and mapping work.

The meaning of `0x803b0006` remains unconfirmed. Record it exactly; do not use it
as a reason to force retries, guess a device handle or change credentials.

## 7. Test unplug/replug

1. Keep the capture running and note the time.
2. Unplug the receiver. Wait 5 seconds.
3. Reconnect it to the same port and reconnect the guitar normally.
4. Repeat neutral input, one fret, strum up/down and whammy.
5. Record separately whether the receiver reopened, new USB reports arrived,
   decoding resumed, the virtual pad bound, and game input worked.

An `opened` message alone does not prove input recovered. An fd number may be
reused, so keep the connection-generation value if the build supplies one.

If a failure is repeatable, make a separate session changing only one item,
such as the USB port. Use a new notes file and log folder for that comparison.

## 8. Optional separate checks

### Device 040b:0897

Only run this if you have that device. Capture its connection and exact device
identifier, open-attempt count and rate-limited failure summary. Quieter logging
does not prove retries continue; that needs an attempt counter or equivalent
instrumentation. The last archive did not contain a matching device identifier.

### PR #29 — DS4 transport and rumble

Use separate sessions for the USB DS4 and the intended wireless DS4 source.

- Check startup and hotplug. A USB DS4 should not also be selected by the
  RemotePlay bridge.
- Record the observed wireless handle's ConnectionType. The current bridge
  expects 2; report a different value without changing the filter yourself.
- Test game-triggered rumble and zero/stop commands. Observe the physical motors.
- Check that motors stop on game exit, bridge disable and suspend, and record
  recovery after resume.

API return codes alone do not confirm physical vibration.

### PR #33 — Bluetooth persistence and inquiry retry

Use a separate Bluetooth session and a controller you can pair again.

- Pair, restart the service normally, and check whether the pairing is retained.
- Forget the controller, restart normally, and check whether it remains forgotten.
- Preserve any storage-failure messages. Do not deliberately change PS5 storage
  permissions or break directories; failed-write behavior already has host tests.
- If inquiry refusals occur naturally, capture timestamps. The intended retry
  delays grow from 500 ms to 1, 2, 4 and at most 8 seconds, resetting on acceptance.

Request acceptance in the app is not proof that a queued operation was persisted.

## 9. What to send back

Keep the original captures. Make one folder per session and zip them together:

```text
Lemos-Ghostcontrol-tests/
  guitar-baseline/
    test-notes.md
    app-service.log
    vpad.log
    kernel-log.txt          # if captured separately
  guitar-port-comparison/  # only if run
    test-notes.md
    app-service.log
    vpad.log
  ds4-or-bluetooth/        # only if run
    test-notes.md
    app-service.log
    vpad.log
```

Copy your actual kernel-log capture into `kernel-log.txt` only if available;
that name is a suggested archive name, not a promised output file. Include the
Experimental source URL/diff and artifact hash in the notes. A short video is
optional. Inspect logs for personal identifiers before public posting, and use
a private channel for sensitive originals. Do not include games, BIOS files,
credentials or proprietary SDK files.

Finish each session's notes with:

```text
USB reports while controls move: PASS / FAIL / NOT VERIFIED
EBUSY interleaved with successful completions: YES / NO / UNKNOWN
Longest gap during active controls:
Kernel-log bytes/events received: YES / NO / UNKNOWN
Virtual-pad binding: PASS / FAIL / NOT VERIFIED
Each physical control mapped correctly: PASS / FAIL / NOT VERIFIED
Game input: PASS / FAIL / NOT VERIFIED
Input after unplug/replug: PASS / FAIL / NOT VERIFIED
Exact failure timestamp and action:
One change from the previous session, if any:
Other observations:
```

## 10. What establishes a fix

A strong result reproduces the failure on an identified baseline build, shows
the cause in the capture, then passes the same sequence with one focused fix.
It also checks reconnect and other controllers for regressions. Until that
evidence exists, the guitar EBUSY root cause and gameplay remain NOT VERIFIED.
