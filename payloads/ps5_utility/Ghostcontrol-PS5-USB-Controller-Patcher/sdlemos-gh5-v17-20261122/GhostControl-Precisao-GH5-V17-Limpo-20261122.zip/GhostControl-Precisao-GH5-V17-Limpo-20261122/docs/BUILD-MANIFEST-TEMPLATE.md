# Build/test record — fill this in for every PS5 session

Combined source ZIP SHA-256:
Local source-tree SHA-256 manifest:
PR #29: `147e1ccaa52b758c79b673eed6c4ca5975374424`
PR #32: `3e4ef90c035df2851e6dc65bc0d339a7139da229`
PR #33: `9ee7019f797d64162e39b784eec97d900271506c`
ELF path:
ELF SHA-256:
PS5 firmware / model:
Payload SDK revision:
Build command and full output log:
Loader / OnionHEN version:
Kernel log provider/config:
Single USB feed owner confirmed:
VDA marker present at service start? YES/NO:
Test session ID and clock:
Physical action timeline:
USB last completion during active strum:
USB control decode demonstrated? YES/NO:
VDA AddDevice, klog bytes/events, binding, InsertData:
Game/version and button response:
Result: PASS / FAIL / NOT VERIFIED:
