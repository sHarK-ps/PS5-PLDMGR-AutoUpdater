# GhostControl GH5 — matriz de integração e conflitos (14/11/2026 R5)

**Fonte pública:** https://github.com/StonedModder/Ghostcontrol-PS5-USB-Controller-Patcher

**Política:** R4 local foi a base exata. Não foi feito `git merge` de cinco PRs abertos no `main`; são integrações locais com verificação de supersessões. O pacote de ELFs do desenvolvedor Cold permanece separado e não foi usado como fonte desta build. Este arquivo é código-fonte, não contém ELF.

| PR / fonte | HEAD consultado | Aplicação local | Deduplicação / risco |
|---|---|---|---|
| #29 | `ffb4c90d` | Incorporados os modos públicos GH5 de `d9d2e9c` e replays de `ffb4c90`; preservados os anteriores de `cd580707` | NÃO reintroduzir parser decimal/hex MBus, loop USB ou contadores de progresso já integrados; modo público só no receptor 12ba:0100 |
| #32 | `d530b1b` | R4 já continha `bcdDevice`, invalidação de cache HID, worker GIP e preservação do primeiro INPUT; preservados e testados | Sem substituir o worker local por um segundo worker concorrente; evitar duplicar GC_UPDATE_API |
| #33 | `55bc1ae` | R4 já integrava correções Bluetooth e rollback de `db_forget` | Ainda há risco de inquiry travada após `0x0C` e Inquiry Complete perdido; sem conserto seguro homologado nesta rodada |
| #34 | `4fcb1fb` | Parser de vibração por registros/bit ativo já estava no R4, com flag `RUMBLE_READBACK=0` por padrão | Sem ativar automaticamente: `GetRemoteSetting`/ABI e saída Bluetooth não validados na GH5 11.60; pode concorrer com relay DS4 #29 |
| #35 | `181426f` | Correção de URL `GC_UPDATE_API` já integrava R4 | Não aplicar duas vezes |

## Conflito tratado: diagnóstico privado vs modos GH5 públicos

O público #29 escolhe por `VARIANT=gh5-raw`, `gh5-neutral` e `gh5-mapped`, retornando resultados explícitos `GC_USB_DECODE_SKIPPED`, `GC_USB_DECODE_NEUTRAL_PROBE`, `GC_USB_DECODE_CONTROLS` e `GC_USB_DECODE_REJECTED`. No R4, `GC_GH5_USB_DIAGNOSTIC` interceptava o mesmo `usb_decode_report` e escolhia RAW/neutral por arquivo marcador. **Não se podem empilhar os dois métodos**: isto faria `gh5-mapped` registrar RAW e abortar mapeamento.

R5 implementa portas isoladas, selecionadas pelo Makefile. O `#error` bloqueia combinação incoerente de flags; `gh5-raw` não publica; `gh5-neutral` cria apenas frames neutros *após input interrupt validado*; `gh5-mapped` e `resident` seguem decodificação/prof. O marcador legado é exclusivo dos modos privados `gh5-diagnostic`/`gh5-precision`. RAW/neutral públicos inibem GET_REPORT GH5, sem afetar outros VID/PID; privado mantém seu protocolo histórico. Um `GC_GH5_MODE=3` no cabeçalho é o padrão de *mapped* público, **não uma prova de pad virtual funcional**.

## Contadores e evidência

`raw_only_skipped`/`neutral_probe_frames` antigos são mantidos para séries de log antigas **privadas**. `decode_attempts`, `decoded`, `rejected`, `decode_skipped`, `neutral_probes` são os contadores da implementação pública. Uma amostra transportada não é automaticamente uma tentativa de decodificação. O arquivo `tools/tests/fixtures/gh5-hid-20261114.json` foi reconstruído **a partir do test.zip do usuário**, SHA-256 acima, e conserva 49 e 81 amostras RAW únicas com número de linha e SHA de cada log. É equivalente em propósito ao fixture do upstream, mas não foi comparado byte a byte com o GitHub; não reivindicar cópia idêntica.

## Correção experimental local (apenas Precisão)

O sampler R4 atualizava `trace_raw_prev` antes de decidir se a transição caberia no orçamento (24 INTERRUPT-IN/s ou 3 CONTROL/s). Se a única amostra desse novo estado fosse descartada, os próximos relatórios iguais seriam ignorados por igualdade com `prev`, mesmo depois de abrir uma nova janela. R5 experimental guarda **último estado realmente logado**; uma transição não registrada fica elegível na janela seguinte. A correção foi verificada compilando a função C extraída da árvore real (`test_precision_sampler_transition.py`). É uma mudança de registro, **não de transporte**, nem demonstra falhas do controlador.

## Outras pendências externas sem correção comprovada

- PR #29: entrega de rumble pode fazer `PT_ATTACH` a cada atualização; interlock e sessão persistente exigem teste específico e não são introduzidos às cegas.
- PR #29: `ConnectionType==2` requer confirmação no firmware; `ENOTTY` fatal pode causar reopen repetido. Falta quarantine/backoff e testes para `usb_supported` e geração.
- PR #33: possível inquiry permanentemente ativo quando `0x0C` recusa cancelamento e o evento Complete se perde; IPC forget assíncrono pode responder antes de persistir.
- PR #34: read-back de vibração é opcional e não testado no Bluetooth local.
- Virtual pad ainda não confirmado no PS5 11.60: nenhum ELF R5 compilado, nenhuma confirmação de `DEVICE_ADDED`, bind, `InsertData` aceito ou gameplay. O `main` oficial permanece no SHA indicado.

Recomendação: primeiro RAW público para confirmar loader/USB; depois neutral para `AddDevice`, `DEVICE_ADDED`, bind e `InsertData`; por último mapped e testes físicos com movimentos rotulados. Executar **um serviço por vez**, sem misturar com build de terceiros, registrar ELF SHA-256, firmware, loader e logs de cada fase.
