# Changelog — 2026-11-11

Common: ported upstream PR #29 HID fallback (per UsbFeed lifetime, 250 ms retry, 1 s quiet), removed global polls/polled_ok, refactored USB decoder to accept separate control buffers without changing #32 GIP/DS3 or previous local #33 bond rollback. Added behavioral C fallback test and combined host workflow, preserved PR29/PR32/PR33 local review corrections. Maintained original project README.


## Precision variant

This tree retains exactly the same functional developer code and adds diagnostic-only changes from the previous local Experimental branch plus targeted repairs:

- Per-generation once-per-second START/COMPLETE/EBUSY progress, timing since successful completion/input, outstanding-transfer age and completed endpoint index only after a successful COMPLETE.
- Per-feed `GcUsbFallback` counters for interrupt reception, `GET_REPORT` attempts/success/failures; 250-ms fallback retry and quiet-window gating remain *the same functional code as Conservative*.
- Separate bounded changed RAW trace streams: up to **24 interrupt-IN** and **3 GET_REPORT control** changes per second, per generation, with monotonic timestamps and source tags; emitted drops are counted and not hidden. No six-second global 256-record cap in this variant. **This still samples**; very dense transitions may be dropped and appear in `RAW dropped`.
- Distinct `probe_disabled_skips`, `neutral_probe_frames`, `decode_attempts/success/failure`, `neutral_publish_success`; neutral VDA probe frames are NOT a mapped fret decoder success.
- Short CONTROL_GET_REPORT replies do **not** count as neutral VDA probe input.
- Existing rate limit for unrelated USB `040B:0897`; its behavior was not verified in latest GH5 captures because it was absent from them.

`bash build_elf.sh` with PS5 SDK builds `GhosttoothAPI/GhosttoothAPI-GH5-precision.elf`. No ELF was built in this environment.

The optional marker `/data/ghostcontrol-app-service/gh5-vpad-probe.enable` exists **only for diagnostic builds** and is checked once per service process. Start a fresh service after changing it. Probe ON sends neutral frames for diagnosis; it does **not** implement frets/strum mapping, and a VDA bind still requires separate validation.

**Session A:** marker absent, RAW capture with time-labelled actions and unplug/replug. **Session B:** marker present before fresh start, verify AddDevice -> klog -> DEVICE_ADDED -> bind -> InsertData -> visible game input. Compare with identical hardware/configuration and recorded ELF SHA256. Do not change USB START/poll/COMPLETE on speculative EBUSY explanations.


## Audit revision 2 (2026-11-11)

Corrected historical package metadata, labeled historical research snapshots, added source/test coverage audit and separate developer summary, and made host script check Bluetooth C11 and shell syntax. No functional USB/VDA/BT production source changes were made during this audit revision.
