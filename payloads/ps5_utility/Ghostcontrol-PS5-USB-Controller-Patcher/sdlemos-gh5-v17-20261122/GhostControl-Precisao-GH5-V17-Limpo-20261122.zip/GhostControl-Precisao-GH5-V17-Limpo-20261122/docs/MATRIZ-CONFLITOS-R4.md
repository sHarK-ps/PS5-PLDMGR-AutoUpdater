# Matriz de conflitos e riscos — revisão R4

A matriz principal está em `PR29-PR32-PR33-PR34-PR35-AUDITORIA-R4.md`.

## Duplicações evitadas

- cache HID local único: `gc_usb_forget_path` preservado como alias, API nova `gc_usb_hid_layout_forget`, sem dois caches concorrentes.
- worker de handshake Xbox: `gip_worker_threads` da versão local, um só dono do fd, **não** incorpora `gc_usb_opener.c` upstream, que seria uma implementação paralela.
- `xbox_take_initial_report`: reutiliza buffer `pending_input` já validado, sem criar um segundo estado de primeira amostra.
- GC_UPDATE_API: patch #35 e a parte de #32/#34 referem-se à **mesma** linha, já incluída localmente.
- `scePadVirtualDeviceGetRemoteSetting`: implementação do #34 condicional a RUMBLE_READBACK=1, não usada por padrão; ainda é possível colisão com forwarding do #29 quando opt-in é ligado.

## Pendências sem correção forçada

- #29: alta frequência PT_ATTACH de rumble DS4, ENOTTY sem quarantine, lacunas de teste.
- #33: busca Bluetooth com cancel recusado sem evento final, falta de correlação assíncrona e política explícita de recuperação.
- #34: API ABI PS5 11.60 e vibração Bluetooth não validadas; necessidade de arbitrar uma única rota de rumble ao lado do #29.
- #32: CI novo necessita rodar no GitHub; eventual espera durante cancelamento do worker USB só simulada em host; 64B report limit e Guide gate mantidos.
