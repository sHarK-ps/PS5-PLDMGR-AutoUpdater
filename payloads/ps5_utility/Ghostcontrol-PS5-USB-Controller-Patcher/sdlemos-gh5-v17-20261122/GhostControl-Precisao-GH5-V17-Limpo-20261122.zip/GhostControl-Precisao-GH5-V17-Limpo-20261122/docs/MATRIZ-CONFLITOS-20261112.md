## Conflict / supersession / deduplication matrix

| Overlap | Resolution in this local integration | Risk / validation gap |
|---|---|---|
| #29 vs #32 USB START/poll/COMPLETE | A single existing transport path retained; completion index checked **before** consuming IN state, and transient EBUSY preserves pending ownership | Full console USB ABI unavailable; inspect with hardware logs |
| #29 vs #32 HID GET_REPORT and descriptor cache | Keep #32 cached HID/retirement and #29 connection-scoped fallback. Remove gate on `control_decoded`; do not publish neutral input on undecodable CONTROL_GET_REPORT, even with saved profile | Idle device fallback not physically tested |
| #29 GH5 HID mapping vs local GH5 raw-only logger | Mapping installed only on VID:PID 12BA:0100 in common HID decoder; the pre-existing diagnostic special path still skips real decoding | Normal build profile must be tested independently; current neutral probe is not game input |
| #29 VDA parser vs local preflight | Parser remains decimal-aware (`deviceType=22`); require drained EAGAIN log source with complete line before AddDevice; log first successful InsertData | An unavailable kernel log now blocks creation intentionally |
| #33 BT inquiry vs local rollback | Retain local prior `db_forget` rollback on disk-write failure while adding cancel-inquiry rate-limiting, failure semantics and disconnection guards | Upstream policy differs; maintainer must review |
| Precision vs Conservative | Identical shared `core/src` except `gc_service_inject.c`; variant Makefile differs, Precision includes additional logging/tests | Precision is NOT a pure merge-commit descendant; both share common fixes |

