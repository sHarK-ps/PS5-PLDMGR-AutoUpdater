# Precision diagnostic limitations

1. `probe_disabled_skips` denotes intentionally skipped GH5 reports (not failed fret mapping); `neutral_probe_frames` denotes only neutral VDA probing.
2. Sample limits 24 interrupt changed reports/s and 3 GET_REPORT replies/s can drop fast changes; `RAW dropped` reports this. A clean, manually annotated control sequence is mandatory.
3. `GET_REPORT` fallback source separation is tested with a host fake, not verified on PS5.
4. No full validated fret/strum/whammy/tilt decoder exists; no gameplay is claimed.
5. VDA marker is read on first report in process lifetime. Separate sessions, fresh restart.
6. A single `AddDevice` result, including 0x803b0006, does not prove success/failure. Confirm klog and bound user.
7. No causal explanation for EBUSY; do not alter transfer lifecycle based on count alone.
