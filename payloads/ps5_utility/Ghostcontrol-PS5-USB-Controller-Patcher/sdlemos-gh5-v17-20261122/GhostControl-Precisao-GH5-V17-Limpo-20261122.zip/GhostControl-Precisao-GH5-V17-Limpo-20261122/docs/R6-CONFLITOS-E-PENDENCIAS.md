# Matriz de conflitos e pendências — GH5 R6

| Origem | Atualização | R6 | Risco/decisão |
|---|---|---|---|
| PR29 `ffb4c90` | Modos públicos RAW, Neutral, Mapped; replay 130 | R5 retido | NÃO misturar com o interceptador privado `GC_GH5_USB_DIAGNOSTIC` |
| PR32 `d530b1b` | USB cache com bcdDevice, GIP INPUT, worker | R5 retido | Sem alterações funcionais USB em R6 |
| PR33 `55bc1ae` | Bluetooth armazenamento e inquiry | R5 retido | Bounded recovery 0x0C pendente |
| PR34 `4fcb1fb` | Vibration remote-setting parser | Retido opt-in | BT físico/ABI não confirmado, padrão OFF |
| PR35 `181426f` | GC_UPDATE_API URL | Já incorporado | Deduplicar, não aplicar novamente |
| R5 privado | RAW/Precision; neutral marker | Retido | `GC_GH5_MODE` público NÃO representa mode privado; banner esclarecido |
| R6 comum | `GH5_VDA_R6` estados, janela e quarentena | Adicionado em duas variantes | Observação apenas, sem alterar propriedade/cleanup |
| R6 Precisão | Limpeza de duas regras redundantes do Makefile | Aplicado | Seleção/flags de compilação antes ambígua; sem alteração em protocolo |

**Conservador:** adaptação fiel e instrumentação de estado sem nova heurística de resolução. **Precisão:** mesma instrumentação, mantendo a captura avançada do R5. Nenhuma reidentificação automática sem evidência de MBus.
