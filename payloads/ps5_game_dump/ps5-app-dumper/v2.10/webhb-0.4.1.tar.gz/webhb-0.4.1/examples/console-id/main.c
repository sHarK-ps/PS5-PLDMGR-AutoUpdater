/* Copyright (C) 2026 slopmaster33

This program is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the
Free Software Foundation; either version 3, or (at your option) any
later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; see the file COPYING. If not, see
<http://www.gnu.org/licenses/>.  */

/* console-id: shows the id a test build knows this console by, and the
   firmware - as a toast on the TV, as a line back to the sender, and as
   console-id.txt on every USB drive and in /data, for when the toast is gone
   too soon. It reads nothing else. The id is whb_console_id() from
   webhb/testgate.c: eight hex digits of a SHA-256 over the console's PSID,
   never the PSID itself - a one-way hash, and most of it thrown away. */

#include <stdio.h>
#include <string.h>
#include <stdint.h>
#include <sys/types.h>
#include <sys/sysctl.h>
#include <sys/stat.h>

#include "webhb.h"

int sceKernelSendNotificationRequest(int, SceNotificationRequest *, size_t, int);

int main(void)
{
    char id[9];
    whb_console_id(id);

    uint32_t v = 0;
    size_t len = sizeof(v);
    sysctlbyname("kern.sdk_version", &v, &len, NULL, 0);

    char msg[128];
    snprintf(msg, sizeof(msg), "Console id %s\nfirmware %x.%02x", id, (v >> 24) & 0xffu, (v >> 16) & 0xffu);
    printf("%s\n", msg);

    /* the file: on each drive that is there, and on the console itself */
    const char *roots[] = { "/mnt/usb0", "/mnt/usb1", "/mnt/usb2", "/mnt/usb3",
                            "/mnt/usb4", "/mnt/usb5", "/mnt/usb6", "/mnt/usb7", "/data" };
    for (size_t i = 0; i < sizeof(roots) / sizeof(roots[0]); i++) {
        struct stat st;
        if (stat(roots[i], &st) != 0) continue;
        char path[64];
        snprintf(path, sizeof(path), "%s/console-id.txt", roots[i]);
        FILE *f = fopen(path, "w");
        if (!f) continue;
        fprintf(f, "%s\n", msg);
        fclose(f);
        printf("written to %s\n", path);
    }

    SceNotificationRequest req;
    memset(&req, 0, sizeof(req));
    req.use_icon_image_uri = 1;
    snprintf(req.message, sizeof(req.message), "%s", msg);
    sceKernelSendNotificationRequest(0, &req, sizeof(req), 0);
    return 0;
}
