// what tools/stylecheck.js walks the viewer's page through
module.exports = [
  ["main", ``, 1500],
  ["filtered", `var f = document.getElementById("k-filter"); f.value = "usb"; f.dispatchEvent(new Event("input"));`, 400],
  ["marked", `document.getElementById("k-mark").click();`, 1500],
  ["settings", `document.getElementById("k-filter").value = ""; location.hash = "#settings";`, 700],
  ["unlock", `document.getElementById("unlock").hidden = false;`, 300],
  ["offline", `document.getElementById("unlock").hidden = true; location.hash = ""; ["offline","offline-start","offline-spin"].forEach(function(i){ document.getElementById(i).hidden = false; });`, 400],
  ["everything", `Array.prototype.forEach.call(document.querySelectorAll("[hidden]"), function(e){ e.hidden = false; });`, 500],
];
