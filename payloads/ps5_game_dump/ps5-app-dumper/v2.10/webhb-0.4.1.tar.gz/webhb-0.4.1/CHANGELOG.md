# Changelog

## 0.4.1

- `TEST_FIRMWARE` takes a list too: `5.10,12.00`.

## 0.4.0

- Builds for testers: `make TEST_EXPIRES=... TEST_FIRMWARE=... TEST_CONSOLES=...`
  makes a build that runs only until that day, on that firmware and on those
  consoles; `whb_start()` ends it with a toast otherwise (`webhb/testgate.c`).
  `whb_console_id()` is the console's id for that list, a hash of its PSID.

## 0.3.2

- A hidden QR card can be brought back under Settings ("Show again").

## 0.3.1

- The QR code also for a PC that is in already - without the access code in
  it, the phone then asks once - and never on a phone. The console's browser
  keeps getting it with the code.

## 0.3.0

- A QR code for the phone: `GET /api/whb/qr` renders the page's address with
  the access code as an SVG - only for the console's own browser, which is
  the screen it is read off. The kit shows it in the access card
  (`row-qr`), and a page opened with `?code=NNNNNN` in its address unlocks
  itself. `webhb/qr.c` is a QR encoder of its own (byte mode, level M,
  versions 1-6), nothing to link.
- The home-screen tile is a setting: `WHB_CFG_STD_TILE` (`home_tile`, on by
  default) puts the tile on the home screen at start and keeps it current;
  the kit's tile row has a switch that installs or removes it
  (`POST /api/whb/tile/remove` is new) and a Reinstall button.
- `Dockerfile.sdk`: the SDK release in a container, so a payload builds the
  same everywhere; the workflow builds the example and a scaffolded project
  with it.
- The QR code as a card on the main page too (`qr-card`), for the console's
  browser, with a Hide button the browser remembers.
- The tile row is locked, with a spinner, while the install service works.
- Removal of the tile goes through `sceAppInstUtilAppUnInstall`, opened the
  way the install is: bare, that call never returned.

Moving from 0.2.x: add `WHB_CFG_STD_TILE` to the key table of an app with a
tile, or leave it out to keep installing by hand only.

## 0.2.1

- `tools/snapshot.sh`: every route's answer, normalised, into a file; `make
  check` compares the template project and the klog viewer with references in
  the repository, `make snapshots` renews them. Nothing changed in the core.
- `RELEASE_URL` says where release archives live.

## 0.2.0

- The folder picker is the kit's: `<!-- @WHB:picker@ -->` and
  `whbPickFolder({ mount, onUse, ... })`, with optional title, button labels,
  notice, preview leaf and a row of drives to switch between.
- `GET /api/whb/drives`: where files can go - the drives that are plugged in
  and the console's own storage.
- The template shows both.
- A workflow that scaffolds a project and builds it and the example for the
  host on every push.

Moving from 0.1.0: nothing to change. A page that had its own copy of the
picker can drop markup, script and the `.picker-note` / `.picker-drives` rules.

## 0.1.0

The core as it came out of ps5-app-dumper: web server with `whb_req_t`
handlers, settings with registered keys, storage on a drive or on the console,
access code, single running copy, Payload Manager self-store, home-screen
tile, cached page, surviving rest mode, the page kit (`whb.css`, `whb.js`,
shared markup), `webhb.mk`, host stubs, the project template, the release
installer, and the klog viewer as the example.
