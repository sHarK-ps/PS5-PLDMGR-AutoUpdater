# Notes from the console

What cost time to find out, and what webhb does about it. Observed on FW 12.00
(and 5.10 where noted) unless said otherwise.

## The PS5's browser

The tile opens the page in the console's own browser, a WebKit from before
several CSS features. None of them error; they just drop. Chrome never shows
any of this - ask for a photo of the TV.

- `inset` is unknown: absolutely positioned boxes get no size. Use
  `top/right/bottom/left`.
- Flexbox `gap` is ignored (grid `gap` works), and `@supports` cannot tell. A
  probe in the head (`@WHB:head@`) measures it and sets `.no-flexgap` on
  `<html>`; margins stand in. **Every flex container with `gap` needs a line
  in the fallback block**, in the file that holds the rule; an element with
  `margin-left:auto` is excluded through the `:not(...)` list the kit's lines
  share.
- Children of a flex column are squeezed below their content. **Every child of
  a scrolling flex column gets `flex:none`.**
- An unknown function voids the whole declaration: `min()` and `env()` need a
  plain declaration in front of them.
- Closest check on a desktop: add `no-flexgap` to `<html>` and inject
  `*{gap:0!important}` for flex containers.
- Service workers need HTTPS, so the offline page uses the application cache.
  iOS has neither for plain HTTP: no offline start there.

## Processes

- `syscall(SYS_thr_set_name, -1, name)` names the process. At most 19
  characters, and **it must end in `.elf`**: payload managers only list such
  processes.
- elfldr runs a payload as a process of its own; it can be loaded while a game
  runs. When a payload "just disappears", read the kernel log before building
  theories (`examples/klogview`).
- Connection threads get a small stack by default; the server gives them
  512 KB. Large buffers still belong on the heap.

## Rest mode

The network stack is deactivated and the USB drives unmount. `accept()` fails
with errno 163 (`SCE_NET_ERROR_EINACTIVEDISABLED`, 0x804101A3; libc has no text
for it). Processes live on. The server closes the socket, looks for the network
every three seconds and listens on the same port again; storage falls back to
the console and returns to the drive when it is back.

## Home-screen tile

A tile is a title directory under `/user/app/<TITLEID>` with a `param.json`
(`applicationCategoryType` 65536 and a `deeplinkUri`) and an `icon0.png`,
registered through the app-install service. Registering makes the shell fetch
catalog metadata over HTTPS; without `libSceHttp2`, `libSceSsl` and `libSceNet`
loaded in the calling process that fetch faults and the kernel kills the
caller. `tile.c` loads what it needs at the moment the user asks for the tile,
on a thread with a 2 MB stack, and never at start-up - a console that takes
the install badly cannot keep the payload from starting. The tile does not
start the payload; it opens the (cached) page, which can ask pldmgr to.

## Tile: install at start

Registering a title at start-up used to be avoided because a console that
takes it badly would end the payload before it answered. It is done after the
server listens, on a thread of its own, and only when the `home_tile` setting
is on - so a console like that is switched off in config.ini. Removal goes
through `sceAppInstUtilAppUnInstall`, then the folder under `/user/app` goes.

## QR code

The console's browser shows the page's address with the access code as a QR
code (`/api/whb/qr`, refused for any other peer). A phone that scans it opens
`/?code=NNNNNN`; the kit trades the code for a token and strips it from the
address. `qr.c` is a small encoder written for this: byte mode, level M,
versions 1-6, mask 0 - readers do not mind the mask. Payload Manager does the
same in React with `qrcode.react`; a single cached page for the console's
WebKit cannot bring a library along.

## Payload Manager (pldmgr, port 8084)

- The version it shows comes from the **file name** (`_v1.12`), hence
  `<elf_basename>_v<version>.elf`.
- Upload: `POST /manage:upload?filename=<name>`, raw body. List:
  `GET /list_payloads`. Start: `GET /loadpayload:<path>`. CORS `*`.
- A payload sent over the network has no file of its own, so the build is
  two-stage: stage 1 is embedded in the final ELF (`self_elf`), which can then
  store "itself". A copy started from the stored file has nothing embedded and
  says `canStore:false` - it is stored already.

## Test builds

The console keeps its clock in UTC; "valid until 2026-09-27" ends at 00:00 UTC
on the 28th. Nothing on the console stops the clock from being turned back,
which is why a clock before the build day counts as expired, and why the
console list is the real lock: `machdep.openpsid_for_sys` is the 16-byte PSID
the system itself identifies the console by (etaHEN gates its betas with it);
firmware `kern.sdk_version` (`kernel_get_fw_version()`) is BCD, `12.00` prints
as `%x.%02x` of the top two bytes.

## Settings

A drive that carries a `config.ini` in `homebrew/<app>/` wins over the console's
copy: it travels with the stick and can be edited on a PC. Values out of range
in a hand-edited file are pulled into range, never refused. `access_code` and
`access_token` are never served; `require_code` can only be changed from
127.0.0.1.
