# webhb - web homebrew core for PS5 payloads

A PS5 payload with a web interface needs the same things every time, and most
of them cost more than the payload's actual job: a web server that survives a
vanishing client, a page that works in the console's old WebKit, settings that
live on a USB stick or on the console, an access code so that not everybody on
the network can press the buttons, a home-screen tile, a place in Payload
Manager, exactly one running copy, and coming back after rest mode.

webhb is that part, carved out of [ps5-app-dumper](https://github.com/EchoStretch/ps5-app-dumper)'s
web console. An app written on it is a `main.c`, a page and a seven-line
Makefile. `examples/klogview/` - the kernel log in a browser - is about 200
lines of C and 60 lines of script.

Tested on firmware 5.10 and 12.00. Other firmwares are untested, not known to
fail. GPL-3.0, see `COPYING`.

## Start a project

```sh
tools/new-app.sh myapp "My App" ../myapp 8280
cd ../myapp
make WEBHB_DIR=../webhb sim && make WEBHB_DIR=../webhb run    # http://127.0.0.1:8280/
PS5_PAYLOAD_SDK=/opt/ps5-payload-sdk make                     # myapp.elf
# or without an SDK on this machine, in a container (built from Dockerfile.sdk once):
docker run --rm -v "$PWD":/src -w /src webhb-sdk make WEBHB_DIR=...
cat myapp.elf | nc -w 6 <console> 9021
```

The new project has one setting and one route, to be replaced by what the app
is about, and everything below already working. `make sim` builds the same
program for this machine with the console's business stubbed
(`webhb/host/stubs.c`), which is where a page is developed.

### How a project gets webhb

A project does not carry a copy. It pins a release in `webhb.lock` -

```
version=0.1.0
url=https://github.com/<owner>/webhb/releases/download/v0.1.0/webhb-0.1.0.tar.gz
sha256=<printed by make dist>
```

- and its Makefile installs exactly that archive into `ext/webhb/` on the
first `make` (`tools/get-webhb.sh`, copied into the project; the archive is
checked against the sha256 before it is unpacked). Moving to a newer webhb is
a change of those three lines. To work on webhb and a project side by side,
`make WEBHB_DIR=../webhb` uses a checkout instead.

Cutting a release: bump `VERSION`, add to `CHANGELOG.md`, commit, `make dist`,
tag `v<version>`, and upload `dist/webhb-<version>.tar.gz` as the release's
asset - that very file, because projects pin its checksum. `RELEASE_URL` holds
where such archives can be downloaded; `tools/new-app.sh` writes it into new
projects.

## What an app writes

```c
static const whb_cfg_key_t keys[] = {                 /* config.ini + /api/whb/config */
    { .ini_name = "greeting", .web_name = "greeting", .type = WHB_CFG_STRING, .def_str = "Hello" },
    WHB_CFG_STD_WEB_PORT, WHB_CFG_STD_LOGGING, WHB_CFG_STD_ACCESS,
};

static void handle_hello(whb_req_t *req)              /* everything below /api/ but /api/whb/ */
{
    whb_send_json(req, 200, "{\"said\":\"hello\"}");
}

int main(void)
{
    whb_config_register(keys, 4);
    if (whb_start(&app) != 0) return 0;               /* name, settings, replaces an idle copy */
    whb_route("POST", "/api/hello", handle_hello);
    return whb_serve(0);                              /* built-in routes, then the server */
}
```

`whb_app_t` says who the app is: names, data folder, ELF name, tile title id,
default port, the embedded page and icon, and `busy()` - the one callback the
core needs, asked before quitting, before a newer copy takes over and before a
tile install. `webhb/include/webhb.h` is the whole interface and is commented
for reading.

The page is one file with marker lines that the build fills in
(`tools/inline.sh`): `/* @WHB_CSS@ */`, `/* @WHB_JS@ */`, and
`<!-- @WHB:name@ -->` for the markup every app shares - `head` (flex-gap
probe), `chips` (lock and connection), `offline` (the banner of the cached
page), `row-tile`, `row-store`, `access`, `foot`, `unlock`, `toast`, `picker`, `qr-card`. The app's
script fills in `whb.app` and calls `whbBoot()`; the top of
`webhb/web/whb.js` lists the fields and hooks.

## What comes with it

| | |
| --- | --- |
| Server | threads per connection, form and query parameters, JSON string builder, 401 for a POST without the token |
| Routes below `/api/whb/` | `status` (log feed, busy), `config`, `config/console`, `self`, `self/store`, `self/compare`, `tile`, `tile/remove`, `qr`, `drives`, `browse`, `mkdir`, `access`, `access/show`, `unlock`, `quit` |
| Settings | registered keys with type, range, default and the comment for config.ini; flags for secrets, for what only the console's own browser may change, and for folders below a mount |
| Storage | `<drive>/homebrew/<app>/` when a drive carries a config.ini, otherwise `/data/homebrew/<app>/`; log files; drive detection |
| Access | reads are open, a POST needs a token bought with the six-digit code from the TV; 127.0.0.1 is trusted |
| One copy | a resent payload replaces an idle older copy of the same app and leaves a busy one alone |
| Payload Manager | the ELF embeds its own first stage and can store itself in pldmgr as `<app>_v<version>.elf` |
| Home-screen tile | a setting: put on the home screen at start and kept current, or switched off; a deeplink tile that opens the page in the console's browser |
| QR code | the page's address with the access code, shown in the console's browser only; a phone that scans it is in |
| Cached page | application cache manifest, so the tile opens the page while the payload is down; the page then offers to start it through pldmgr |
| Rest mode | the listening socket dies with the network (errno 163); the server waits and listens on the same port again |
| Page kit | tokens, header, cards, rows, switches, segmented controls, buttons, modal, live console, toasts, a folder picker (`whbPickFolder()`) - written for the PS5's WebKit |

`docs/NOTES.md` has what was learned the hard way about the console: the CSS
its browser lacks, what a tile install needs, process names, pldmgr's
conventions.

## Changing the core

`make check` scaffolds a project from the template, builds it and the klog
viewer for this machine, asks both everything the core serves - every route
below `/api/whb/`, with nonsense such as `../..`, empty values and numbers out
of range among the questions, and the access lock over the LAN address - and
compares the answers with the references in the repository
(`template/snapshot.txt`, `examples/klogview/snapshot.txt`). A change that is
not meant to alter behaviour leaves them as they are. One that is meant to
brings new references along: `make snapshots`, and the diff of those two files
is what a review looks at. The workflow in `.github/` runs `make check` on
every push and pull request.

What this cannot show is what only exists on the console: the tile install,
taking over a running copy, rest mode, and the PS5's browser. Say in a pull
request what was tried on hardware, and on which firmware.

## Builds for testers

A build that should not travel: `make TEST_EXPIRES=2026-09-27
TEST_FIRMWARE=5.10,12.00 TEST_CONSOLES=1ffc2e73,b81e0c44` runs until that day
(UTC), on those firmwares and on those consoles only, and `whb_start()` ends it
with a toast otherwise. Each variable is optional and checked only when given.
A console's id is eight hex digits of a SHA-256 over its PSID
(`whb_console_id()`): an accepted build shows it in its toast, so a tester
sends it in and is on the list of the next build. `examples/console-id/` is a payload that shows a console its id and
nothing else, for a tester who has no build yet. A refused build says only
that it refuses, and a clock turned back before the build reads as expired -
nothing to learn from it. A deterrent, not protection: the console and the
file are the tester's.

## Building payloads the same way everywhere

`Dockerfile.sdk` holds the PS5 payload SDK as the release it names
(`SDK_VERSION`, 0.43 today) with the clang and lld it wants. `docker build -t
webhb-sdk -f Dockerfile.sdk .` once, then `docker run --rm -v "$PWD":/src -w
/src/<app> webhb-sdk make` builds an ELF that is the same on a Mac, on Linux
and in the workflow. Tested on firmware 5.10 and 12.00 with that SDK.

## Checking a page

`tools/stylecheck.js` walks a page through its views in headless Chrome and
writes down the computed style of every element; `tools/stylediff.js` compares
two such files. That is how a change to the kit's stylesheet or markup is shown
not to be visible - see `examples/klogview/check-steps.js` for the steps of
one page. `make check` scaffolds a project and builds it and the example.

## Credits

The dumper this came out of is EchoStretch's
[ps5-app-dumper](https://github.com/EchoStretch/ps5-app-dumper); parts of the
log, notification and storage code are his. Built with John Törnblom's
[PS5 payload SDK](https://github.com/ps5-payload-dev/sdk). Payload Manager is
[ps5-payload-manager](https://github.com/itsPLK/ps5-payload-manager).
