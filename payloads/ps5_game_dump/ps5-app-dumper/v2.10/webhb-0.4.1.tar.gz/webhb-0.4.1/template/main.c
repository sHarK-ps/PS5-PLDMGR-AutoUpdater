/* @APP_NAME@ - a web homebrew for the PS5, standing on webhb.

   What is written here is what this payload is about. The web server, the
   page kit, config.ini with /api/whb/config, the access code, the home-screen
   tile, a place in Payload Manager, the single running copy and surviving
   rest mode come with webhb (ext/webhb, see webhb.lock). */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "webhb.h"

#define APP_VERSION "0.1"

/* embedded at build time (webhb.mk) */
extern const unsigned char web_index_html[];
extern const size_t        web_index_html_len;
extern const unsigned char app_icon_png[];
extern const size_t        app_icon_png_len;

/* ------------------------------------------------------------------ */
/*  Settings: config.ini and /api/whb/config follow from this table    */
/* ------------------------------------------------------------------ */

static const whb_cfg_key_t g_keys[] = {
    { .ini_name = "greeting", .web_name = "greeting", .type = WHB_CFG_STRING, .def_str = "Hello",
      .comment = "; === @APP_NAME@ ===\n"
                 "; greeting -> what /api/hello says\n" },
    WHB_CFG_STD_WEB_PORT,
    WHB_CFG_STD_TILE,
    WHB_CFG_STD_LOGGING,
    WHB_CFG_STD_ACCESS,
};

/* ------------------------------------------------------------------ */
/*  Routes: everything below /api/ except /api/whb/ is this app's       */
/* ------------------------------------------------------------------ */

static void handle_hello(whb_req_t *req)
{
    char greeting[WHB_CFG_STR_MAX];
    whb_config_str("greeting", greeting, sizeof(greeting));

    /* shows up in the page's live console, and in logs/ when logging is on */
    write_log(g_log_path, "%s, %s!", greeting, whb_param(req, "name", "world"));

    sb_t sb;
    sb_init(&sb);
    sb_puts(&sb, "{\"said\":");
    sb_json_str(&sb, greeting);
    sb_puts(&sb, "}");
    whb_send_sb(req, 200, &sb);
}

/* ------------------------------------------------------------------ */

static const whb_app_t *the_app(void)
{
    static whb_app_t app = {
        .name          = "@APP_NAME@",
        .short_name    = "@APP_NAME@",        /* what fits under an icon */
        .version       = APP_VERSION,
        .process_name  = "@APP_ID@.elf",      /* must end in .elf, 19 characters at most */
        .data_dirname  = "@APP_ID@",          /* <drive>/homebrew/@APP_ID@/ or /data/homebrew/@APP_ID@/ */
        .elf_basename  = "@APP_ID@",          /* stored in pldmgr as @APP_ID@_v<version>.elf */
        .tile_title_id = "@APP_TITLE_ID@",    /* NULL for an app without a home-screen tile */
        .default_port  = @APP_PORT@,
        /* .busy / .busy_with: set them once there is work that must not be interrupted */
    };

    /* the generated lengths are variables, not constants */
    app.page     = web_index_html;
    app.page_len = web_index_html_len;
    app.icon_png = app_icon_png;
    app.icon_len = app_icon_png_len;
    return &app;
}

int main(void)
{
    whb_config_register(g_keys, (int)(sizeof(g_keys) / sizeof(g_keys[0])));

    /* names the process, reads the settings, replaces an idle older copy */
    if (whb_start(the_app()) != 0) return 0;

    whb_route("POST", "/api/hello", handle_hello);

    int port = 0;                       /* 0: the port from the settings */
#ifdef WHB_HOST
    if (getenv("WHB_PORT")) port = atoi(getenv("WHB_PORT"));
#endif
    return whb_serve(port) == 0 ? 0 : 1;
}
