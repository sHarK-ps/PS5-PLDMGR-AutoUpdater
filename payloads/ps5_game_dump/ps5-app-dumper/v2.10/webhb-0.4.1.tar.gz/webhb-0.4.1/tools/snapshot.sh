#!/bin/sh
# Starts a freshly built simulator (make sim), asks it everything the core
# serves - nonsense included - plus what the app adds, and writes the
# normalised answers to a file. Two such files must diff clean across a change
# to the core that is not meant to alter behaviour; `make check` compares
# against the references in the repository.
#
#   usage: tools/snapshot.sh <sim binary> <output file> [requests file] [port]
#          requests file: one request per line, "GET /path" or "POST /path body"
set -u
SIM="$(cd "$(dirname "$1")" && pwd)/$(basename "$1")"; OUT="$2"; MORE="${3:-}"; PORT="${4:-8290}"
B="http://127.0.0.1:$PORT"
RUN="$(dirname "$SIM")/snapshot-run"

# a simulator left over from `make run` would answer in place of the fresh one
if curl -s -m 2 -o /dev/null "$B/"; then
    echo "snapshot: something already answers on $B - stop it first" >&2; exit 1
fi
rm -rf "$RUN"; mkdir -p "$RUN"
( cd "$RUN" && WHB_PORT="$PORT" "$SIM" > sim.log 2>&1 & )
for i in 1 2 3 4 5 6 7 8 9 10; do curl -s -o /dev/null "$B/" && break; sleep 0.4; done

LAN="$(ipconfig getifaddr en0 2>/dev/null || ipconfig getifaddr en1 2>/dev/null || hostname -I 2>/dev/null | cut -d' ' -f1)"

# what differs from run to run and says nothing: counters, clocks, the made-up
# code, this machine's address, the page's checksum, and the log feed - how
# far it got depends on the moment, and its lines may hold any character
norm() {
    sed -E -e 's/"log":\{"lines":\[.*\],"seq":[0-9]+\}/"log":{...}/' \
           -e 's/"code":"[0-9]{6}"/"code":"CODE"/g' -e 's/# page [0-9a-f]{8}-[0-9]+/# page X/' \
           -e "s/${LAN:-no-lan-address}/LAN/g"
}
q() {
    printf '\n### %s %s %s\n' "$1" "$2" "${3:-}"
    if [ "$1" = GET ]; then curl -s -m 5 -w '\n[%{http_code} %{content_type}]' "$B$2"
    else curl -s -m 5 -w '\n[%{http_code} %{content_type}]' -X POST -d "${3:-}" "$B$2"; fi | norm
}
head_only() { printf '\n### GET %s (status and type only)\n' "$1"; curl -s -m 5 -o /dev/null -w '[%{http_code} %{content_type}]' "$B$1"; }

{
  # the page carries a build stamp, so only that it is served is recorded
  head_only /; head_only /index.html; head_only /icon.png; head_only /apple-touch-icon.png
  q GET /cache.appcache; q GET /app.webmanifest; q GET /nope; q GET /api/nope; q GET /api/whb/nope
  q GET /api/whb/status; q GET "/api/whb/status?since=99999"; q GET /api/status
  q GET /api/whb/self; q GET "/api/whb/self/compare?path=/etc/passwd"; q GET /api/whb/tile; q POST /api/whb/tile ""
  q GET /api/whb/config; q POST /api/whb/config "webPort=80"; q POST /api/whb/config "webPort=99999&enableLogging=7"
  q POST /api/whb/config "webPort=&nonsense=1"; q GET /api/whb/config
  q GET /api/whb/drives; q GET "/api/whb/browse?mount=data&path="; q GET "/api/whb/browse?mount=/etc&path="
  q GET "/api/whb/browse?mount=data&path=../.."; q GET "/api/whb/browse?mount=data&path=no/such/folder"
  q POST /api/whb/mkdir "mount=data&path=&name=made"; q POST /api/whb/mkdir "mount=data&path=&name=../evil"
  q POST /api/whb/mkdir "mount=data&path=&name="; q POST /api/whb/mkdir "mount=/etc&path=&name=x"
  q GET "/api/whb/browse?mount=data&path="
  q GET /api/whb/access; q POST /api/whb/unlock "code=abc"; q POST /api/whb/unlock "code=000000"
  q POST /api/whb/config/console ""

  # what the app adds
  if [ -n "$MORE" ] && [ -f "$MORE" ]; then
    grep -v '^#' "$MORE" | while read -r method path body; do [ -n "$method" ] && q "$method" "$path" "$body"; done
  fi

  # 127.0.0.1 is trusted, so the lock itself is asked over the LAN address
  printf '\n### -- over the LAN address --\n'
  if [ -n "$LAN" ]; then
    B="http://$LAN:$PORT"
    q GET /api/whb/access; q GET "/api/whb/access?token=nope"; q POST /api/whb/config "webPort=8300"
    q POST /api/whb/config "requireCode=0"; q POST /api/whb/mkdir "mount=data&path=&name=lan"
    q POST /api/whb/unlock "code=abc"; q POST /api/whb/access/show ""; q POST /api/whb/quit ""
    q GET "/api/whb/browse?mount=data&path="
    B="http://127.0.0.1:$PORT"
  else
    printf '\n### (no LAN address on this machine: the access lock was not asked)\n'
  fi
  q POST /api/whb/quit ""
} > "$OUT" 2>&1

sleep 1; pkill -f "$SIM" 2>/dev/null
echo "$(grep -c '^###' "$OUT") requests -> $OUT"
