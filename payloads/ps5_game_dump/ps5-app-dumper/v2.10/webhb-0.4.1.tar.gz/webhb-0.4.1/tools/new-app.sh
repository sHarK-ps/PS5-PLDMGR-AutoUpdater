#!/bin/sh
# Starts a new web homebrew from template/: a payload that builds, runs on
# this machine and on the console, and has one setting and one route to be
# replaced by what the app is about.
#
#   usage: tools/new-app.sh <id> "<Name>" <target dir> [port]
#          id    lower case, letters, digits and '-', at most 15 characters:
#                process <id>.elf, data folder homebrew/<id>/, ELF name <id>_v<version>.elf
#          port  first TCP port tried for the web UI (default 8280)
set -eu
HERE="$(cd "$(dirname "$0")/.." && pwd)"
ID="${1:-}"; NAME="${2:-}"; DEST="${3:-}"; PORT="${4:-8280}"
[ -n "$ID" ] && [ -n "$NAME" ] && [ -n "$DEST" ] || { sed -n '2,10p' "$0"; exit 1; }
echo "$ID" | grep -Eq '^[a-z][a-z0-9-]{1,14}$' || { echo "new-app: '$ID' is no usable id (the process name <id>.elf may have 19 characters)" >&2; exit 1; }
[ ! -e "$DEST" ] || { echo "new-app: $DEST exists already" >&2; exit 1; }

# a title id for the home-screen tile: four letters and five digits
TITLE="$(echo "$ID" | tr -cd 'a-z' | tr 'a-z' 'A-Z' | cut -c1-4)"
while [ ${#TITLE} -lt 4 ]; do TITLE="${TITLE}X"; done
TITLE="${TITLE}00001"

VERSION="$(cat "$HERE/VERSION")"
URL="$(grep -v '^#' "$HERE/RELEASE_URL" 2>/dev/null | head -1 | sed "s/@VERSION@/$VERSION/g")"
SHA=""; [ -f "$HERE/dist/webhb-$VERSION.tar.gz.sha256" ] && SHA="$(cut -d' ' -f1 "$HERE/dist/webhb-$VERSION.tar.gz.sha256")"

mkdir -p "$DEST/web" "$DEST/assets" "$DEST/tools"
fill() { sed -e "s/@APP_ID@/$ID/g" -e "s/@APP_NAME@/$NAME/g" -e "s/@APP_PORT@/$PORT/g" -e "s/@APP_TITLE_ID@/$TITLE/g" "$1" > "$2"; }
fill "$HERE/template/main.c"         "$DEST/main.c"
fill "$HERE/template/web/index.html" "$DEST/web/index.html"
fill "$HERE/template/Makefile"       "$DEST/Makefile"
cp "$HERE/template/assets/icon0.png" "$DEST/assets/icon0.png"
cp "$HERE/template/gitignore"        "$DEST/.gitignore"
cp "$HERE/tools/get-webhb.sh"        "$DEST/tools/get-webhb.sh"
cat > "$DEST/webhb.lock" <<LOCK
# The webhb release this project builds on - tools/get-webhb.sh installs it
# into ext/webhb. Set url to where the release's archive can be downloaded.
version=$VERSION
url=${WEBHB_URL:-$URL}
sha256=$SHA
LOCK

echo "new-app: $NAME is in $DEST"
echo "  cd $DEST && make WEBHB_DIR=$HERE sim && make WEBHB_DIR=$HERE run     # http://127.0.0.1:$PORT/"
[ -n "$SHA" ] || echo "  webhb.lock has no sha256 yet: run 'make dist' in $HERE and copy it in"
