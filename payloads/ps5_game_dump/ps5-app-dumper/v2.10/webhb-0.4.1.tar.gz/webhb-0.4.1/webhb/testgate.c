/* Copyright (C) 2026 slopmaster33

This program is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the
Free Software Foundation; either version 3, or (at your option) any
later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; see the file COPYING. If not, see
<http://www.gnu.org/licenses/>.  */

/* A build handed to testers: it runs until a day, on one firmware, on the
   consoles it was built for - and says so on the TV when it does not. The
   app's Makefile sets it (webhb.mk turns the variables into WHB_TEST_*):

     make TEST_EXPIRES=2026-09-27 TEST_FIRMWARE=5.10,12.00 TEST_CONSOLES=1ffc2e73,b81e0c44

   A console is known by its id: eight hex digits of a SHA-256 over its PSID,
   so that no PSID stands in a build and none has to be sent around. A build
   that is let in shows the id in its toast; one that refuses says only that
   it does, and the refusal for a clock turned back reads like the expiry -
   whoever passes a build on learns nothing from it.

   A deterrent, not protection: the console and the file are the tester's. */

#include <stdio.h>
#include <string.h>
#include <time.h>

#include "webhb.h"

#ifndef WHB_HOST
#include <sys/types.h>
#include <sys/sysctl.h>
#include <ps5/kernel.h>
#endif

/* ---- SHA-256 (FIPS 180-2), static: the app may carry one of its own ---- */

static const uint32_t K[64] = {
    0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
    0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
    0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
    0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
    0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
    0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
    0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
    0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2
};

#define ROTR(x, n) (((x) >> (n)) | ((x) << (32 - (n))))

static void sha256_block(uint32_t h[8], const uint8_t p[64])
{
    uint32_t w[64], a, b, c, d, e, f, g, hh;
    for (int i = 0; i < 16; i++)
        w[i] = (uint32_t)p[4 * i] << 24 | (uint32_t)p[4 * i + 1] << 16 | (uint32_t)p[4 * i + 2] << 8 | p[4 * i + 3];
    for (int i = 16; i < 64; i++) {
        uint32_t s0 = ROTR(w[i - 15], 7) ^ ROTR(w[i - 15], 18) ^ (w[i - 15] >> 3);
        uint32_t s1 = ROTR(w[i - 2], 17) ^ ROTR(w[i - 2], 19) ^ (w[i - 2] >> 10);
        w[i] = w[i - 16] + s0 + w[i - 7] + s1;
    }
    a = h[0]; b = h[1]; c = h[2]; d = h[3]; e = h[4]; f = h[5]; g = h[6]; hh = h[7];
    for (int i = 0; i < 64; i++) {
        uint32_t t1 = hh + (ROTR(e, 6) ^ ROTR(e, 11) ^ ROTR(e, 25)) + ((e & f) ^ (~e & g)) + K[i] + w[i];
        uint32_t t2 = (ROTR(a, 2) ^ ROTR(a, 13) ^ ROTR(a, 22)) + ((a & b) ^ (a & c) ^ (b & c));
        hh = g; g = f; f = e; e = d + t1; d = c; c = b; b = a; a = t1 + t2;
    }
    h[0] += a; h[1] += b; h[2] += c; h[3] += d; h[4] += e; h[5] += f; h[6] += g; h[7] += hh;
}

/* the digest of a short message (under 56 bytes: one padded block) */
static void sha256_short(const char *msg, uint8_t out[32])
{
    uint32_t h[8] = { 0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a,
                      0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19 };
    uint8_t block[64] = {0};
    size_t n = strlen(msg);
    if (n > 55) n = 55;
    memcpy(block, msg, n);
    block[n] = 0x80;
    uint64_t bits = (uint64_t)n * 8;
    for (int i = 0; i < 8; i++) block[63 - i] = (uint8_t)(bits >> (8 * i));
    sha256_block(h, block);
    for (int i = 0; i < 8; i++) {
        out[4 * i] = (uint8_t)(h[i] >> 24); out[4 * i + 1] = (uint8_t)(h[i] >> 16);
        out[4 * i + 2] = (uint8_t)(h[i] >> 8); out[4 * i + 3] = (uint8_t)h[i];
    }
}

/* ---- the console's id ---- */

void whb_console_id(char out[9])
{
    uint8_t psid[16] = {0};
    int have = 0;
#ifndef WHB_HOST
    size_t len = sizeof(psid);
    have = sysctlbyname("machdep.openpsid_for_sys", psid, &len, NULL, 0) == 0;
#endif
    if (!have) { snprintf(out, 9, "unknown"); return; }
    /* the prefix keeps the id apart from what another project makes of the PSID */
    char msg[56] = "ps5-app-dumper-test:";
    for (int i = 0; i < 16; i++) snprintf(msg + 20 + 2 * i, 3, "%02x", psid[i]);
    uint8_t h[32];
    sha256_short(msg, h);
    snprintf(out, 9, "%02x%02x%02x%02x", h[0], h[1], h[2], h[3]);
}

/* ---- the gate ---- */

#ifdef WHB_TEST_BUILD

/* is `item` one of the comma-separated `list`? */
static int listed(const char *list, const char *item)
{
    char haystack[600], needle[80];
    snprintf(haystack, sizeof(haystack), ",%s,", list);
    snprintf(needle, sizeof(needle), ",%s,", item);
    return strstr(haystack, needle) != NULL;
}

#ifdef WHB_TEST_EXPIRES
static time_t day_start(const char *ymd, int plus_days)
{
    int y = 0, m = 0, d = 0;
    if (sscanf(ymd, "%d-%d-%d", &y, &m, &d) != 3) return (time_t)-1;
    struct tm t = { .tm_year = y - 1900, .tm_mon = m - 1, .tm_mday = d + plus_days };
    return mktime(&t);
}
#endif

int whb_test_gate(void)
{
    const char *name = whb_app()->name;
    char id[9];
    whb_console_id(id);

#ifdef WHB_TEST_FIRMWARE
    char fw[8] = "?";
#ifndef WHB_HOST
    uint32_t v = kernel_get_fw_version();
    snprintf(fw, sizeof(fw), "%x.%02x", (v >> 24) & 0xffu, (v >> 16) & 0xffu);
#endif
    if (!listed(WHB_TEST_FIRMWARE, fw)) {
        printf_notification("%s test build\nfor firmware %s only - this console runs %s", name, WHB_TEST_FIRMWARE, fw);
        return 0;
    }
#endif

#ifdef WHB_TEST_EXPIRES
    /* the console keeps its clock in UTC, so the last day ends at 00:00 UTC.
       A clock that stands before the day this build was made has been turned
       back; that is reported as expired, the build date being nobody's
       business. */
    time_t now = time(NULL);
    time_t built = day_start(WHB_TEST_BUILT, 0), limit = day_start(WHB_TEST_EXPIRES, 1);
    if (built == (time_t)-1 || limit == (time_t)-1) return 0;
    if (now < built || now >= limit) {
        printf_notification("%s test build\nexpired on %s", name, WHB_TEST_EXPIRES);
        return 0;
    }
#endif

#ifdef WHB_TEST_CONSOLES
    if (!listed(WHB_TEST_CONSOLES, id)) {
        printf_notification("Not built for this console");
        return 0;
    }
#endif

    printf_notification("%s TEST BUILD\n"
#ifdef WHB_TEST_EXPIRES
                        "valid until " WHB_TEST_EXPIRES
#ifdef WHB_TEST_FIRMWARE
                        " on firmware " WHB_TEST_FIRMWARE
#endif
                        "\n"
#endif
                        "console id %s - please do not pass it on", name, id);
    return 1;
}

#else

int whb_test_gate(void) { return 1; }

#endif
