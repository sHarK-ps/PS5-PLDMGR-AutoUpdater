/* Copyright (C) 2025 EchoStretch
   Copyright (C) 2026 slopmaster33

This program is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the
Free Software Foundation; either version 3, or (at your option) any
later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; see the file COPYING. If not, see
<http://www.gnu.org/licenses/>.  */

/* What every web homebrew serves besides its own business: the page and its
   icons, the home-screen tile, a place in Payload Manager, the folder picker,
   shutting down. */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <pthread.h>

#include "webhb.h"

/* Refuses with what the app says it is busy with ("a dump"). */
static void send_busy(whb_req_t *req, const char *fmt)
{
    char msg[120];
    snprintf(msg, sizeof(msg), fmt, whb_app()->busy_with ? whb_app()->busy_with : "the running work");
    whb_send_error(req, 409, msg);
}

/* What this copy is, and whether it carries an ELF it could store. */
static void handle_self(whb_req_t *req)
{
    sb_t sb;
    sb_init(&sb);
    sb_puts(&sb, "{\"version\":");
    sb_json_str(&sb, whb_app()->version);
    sb_puts(&sb, ",\"file\":");
    sb_json_str(&sb, whb_elf_name());
    sb_printf(&sb, ",\"canStore\":%s}", self_store_available() ? "true" : "false");
    whb_send_sb(req, 200, &sb);
}

/* Is the file pldmgr holds this very build? The page passes the path it
   got from pldmgr's list; self_store_matches() only accepts a file of our
   name inside a payload manager's storage. */
static void handle_self_compare(whb_req_t *req)
{
    int rc = self_store_matches(whb_param(req, "path", ""));

    char json[64];
    snprintf(json, sizeof(json), "{\"match\":%s}",
             rc == 1 ? "\"same\"" : rc == 0 ? "\"other\"" : "\"unknown\"");
    whb_send_json(req, 200, json);
}

static void handle_self_store(whb_req_t *req)
{
    char err[192] = {0};
    if (self_store_to_pldmgr(err, sizeof(err)) != 0) {
        whb_send_error(req, 409, err[0] ? err : "could not store the payload");
        return;
    }

    sb_t sb;
    sb_init(&sb);
    sb_puts(&sb, "{\"stored\":true,\"file\":");
    sb_json_str(&sb, whb_elf_name());
    sb_puts(&sb, "}");
    whb_send_sb(req, 200, &sb);
}

/* Whether the home-screen shortcut is in place. Reads two small files and
   nothing else, so the settings tab can ask without waking a system service. */
static void handle_tile_state(whb_req_t *req)
{
    /* "installed" without "current" is a tile from an older build, or one
       that points at a port this server is not on */
    int current = tile_is_current(http_server_port());

    char json[96];
    snprintf(json, sizeof(json), "{\"installed\":%s,\"current\":%s}",
             (current || tile_exists()) ? "true" : "false",
             current ? "true" : "false");
    whb_send_json(req, 200, json);
}

static void handle_install_tile(whb_req_t *req)
{
    /* Registering a title makes the shell rework its app database. Keep that
       away from work that may be reading the very same titles. */
    if (whb_busy()) {
        send_busy(req, "wait for %s to finish first");
        return;
    }

    char err[160];
    if (tile_install(http_server_port(), err, sizeof(err)) != 0) {
        whb_send_error(req, 500, err[0] ? err : "could not install the shortcut (see log.txt)");
        return;
    }
    whb_send_json(req, 200, "{\"installed\":true}");
}

static void handle_remove_tile(whb_req_t *req)
{
    if (whb_busy()) { send_busy(req, "wait for %s to finish first"); return; }

    char err[160];
    if (tile_remove(err, sizeof(err)) != 0) {
        whb_send_error(req, 500, err[0] ? err : "could not remove the shortcut (see the log)");
        return;
    }
    whb_send_json(req, 200, "{\"installed\":false}");
}

/* The page's address as a QR code for a phone's camera. The console's own
   browser gets it with the access code in it, so that a phone gets in
   without typing - that is the screen the code is meant to be read off. A
   device that is in already gets the address alone: the phone then asks
   for the code once. Everybody else gets nothing. */
static void handle_qr(whb_req_t *req)
{
    int local = whb_peer_is_local(req);
    if (!local && !whb_access_token_ok(whb_param(req, "token", NULL))) {
        whb_send_error(req, 403, "the QR code is for the console's browser and for devices that are in");
        return;
    }

    char ip[64], code[8], url[128];
    http_server_address(ip, sizeof(ip));
    whb_access_get(code, sizeof(code), NULL, 0);
    if (local && whb_access_required() && code[0])
        snprintf(url, sizeof(url), "http://%s:%d/?code=%s", ip, http_server_port(), code);
    else
        snprintf(url, sizeof(url), "http://%s:%d/", ip, http_server_port());

    char *svg = malloc(12288);
    if (!svg || whb_qr_svg(url, svg, 12288) != 0) {
        free(svg);
        whb_send_error(req, 500, "could not render the QR code");
        return;
    }
    whb_send(req, 200, "image/svg+xml", svg, strlen(svg), NULL);
    free(svg);
}

static void handle_quit(whb_req_t *req)
{
    if (whb_busy()) {
        send_busy(req, "%s is running");
        return;
    }

    whb_send_json(req, 200, "{\"stopping\":true}");
    printf_notification("%s: web UI closed", whb_app()->name);
    http_server_stop();
}

/* The logo as PNG, the one picture the payload carries anyway (the tile
   uses it). iOS wants a PNG for "Add to Home Screen" - it ignores an SVG
   favicon - and Android takes it from the web manifest. */
static void handle_app_icon(whb_req_t *req)
{
    whb_send_cc(req, 200, "image/png", whb_app()->icon_png, whb_app()->icon_len,
                     "max-age=86400", NULL);
}

static void handle_web_manifest(whb_req_t *req)
{
    sb_t sb;
    sb_init(&sb);
    sb_puts(&sb, "{\"name\":");
    sb_json_str(&sb, whb_app()->name);
    sb_puts(&sb, ",\"short_name\":");
    sb_json_str(&sb, whb_app()->short_name);
    sb_puts(&sb,
        ",\"start_url\":\"/\",\"display\":\"standalone\","
        "\"background_color\":\"#07090d\",\"theme_color\":\"#07090d\","
        "\"icons\":[{\"src\":\"/icon.png\",\"sizes\":\"512x512\",\"type\":\"image/png\","
        "\"purpose\":\"any maskable\"}]}");

    if (sb.oom) { whb_send_sb(req, 500, &sb); return; }
    whb_send(req, 200, "application/manifest+json", sb.buf, sb.len, NULL);
    sb_free(&sb);
}

static void handle_index(whb_req_t *req)
{
    /* "no-store" would keep the page out of the browser's application cache,
       which is what lets the home-screen tile open it while the payload is
       not running. The manifest below takes care of freshness. */
    whb_send_cc(req, 200, "text/html; charset=utf-8",
                     whb_app()->page, whb_app()->page_len, "no-cache", NULL);
}

/* The application cache manifest. A browser that knows the mechanism - the
   PS5's does - keeps the page and serves it even when nothing answers on
   this port; the page then says so and offers to start the payload. The
   comment line carries a checksum of the page: any change to it makes the
   browser fetch the new one. Everything else always goes to the network. */
static void handle_manifest(whb_req_t *req)
{
    uint32_t sum = 2166136261u;   /* FNV-1a */
    for (size_t i = 0; i < whb_app()->page_len; i++)
        sum = (sum ^ whb_app()->page[i]) * 16777619u;

    /* tells, in the live console, whether a browser uses the cache at all */
    write_log(g_log_path, "Web UI: cache manifest requested (page %08x)", (unsigned)sum);

    char body[160];
    int n = snprintf(body, sizeof(body),
                     "CACHE MANIFEST\n"
                     "# page %08x-%zu\n"
                     "\n"
                     "CACHE:\n"
                     "/\n"
                     "\n"
                     "NETWORK:\n"
                     "*\n",
                     (unsigned)sum, whb_app()->page_len);

    whb_send(req, 200, "text/cache-manifest", body, (size_t)n, NULL);
}

/* Resolves the drive to browse: the caller-named mount if it is one of ours,
   otherwise the drive holding config.ini. Returns NULL when none is usable. */
static const char *browse_mount(const whb_req_t *req)
{
    const char *mount = whb_param(req, "mount", NULL);
    if (mount && *mount && target_is_known(mount) == 0) return mount;
    return NULL;
}

/* What is on a stick is no secret to the network it is plugged into; what is
   on the console is only shown to those who may change things anyway. */
static int may_browse(whb_req_t *req, const char *mount)
{
    if (strcmp(mount, storage_internal_root()) != 0) return 1;
    return whb_peer_is_local(req) || whb_access_token_ok(whb_param(req, "token", NULL));
}

static void handle_browse(whb_req_t *req)
{
    const char *mount = browse_mount(req);
    if (!mount) { whb_send_error(req, 400, "unknown drive"); return; }
    if (!may_browse(req, mount)) { whb_send_error(req, 401, "enter the code shown on the TV first"); return; }

    const char *rel = whb_param(req, "path", "");
    if (!fs_path_is_safe(rel)) { whb_send_error(req, 400, "invalid path"); return; }

    /* the listing can be large; keep it off the connection thread's stack */
    char (*names)[FS_NAME_MAX] = calloc(FS_BROWSE_MAX, FS_NAME_MAX);
    if (!names) { whb_send_error(req, 500, "out of memory"); return; }

    int count = fs_list_dirs(mount, rel, names, FS_BROWSE_MAX);
    if (count < 0) { free(names); whb_send_error(req, 404, "cannot open folder"); return; }

    sb_t sb;
    sb_init(&sb);
    sb_puts(&sb, "{\"mount\":");
    sb_json_str(&sb, mount);
    sb_puts(&sb, ",\"path\":");
    sb_json_str(&sb, rel);
    sb_puts(&sb, ",\"dirs\":[");
    for (int i = 0; i < count; i++) {
        if (i) sb_puts(&sb, ",");
        sb_json_str(&sb, names[i]);
    }
    sb_puts(&sb, "]}");

    free(names);
    whb_send_sb(req, 200, &sb);
}

static void handle_mkdir(whb_req_t *req)
{
    const char *mount = browse_mount(req);
    if (!mount) { whb_send_error(req, 400, "unknown drive"); return; }

    const char *rel  = whb_param(req, "path", "");
    const char *name = whb_param(req, "name", NULL);
    if (!name || !*name)          { whb_send_error(req, 400, "no folder name"); return; }
    if (!fs_name_is_safe(name))   { whb_send_error(req, 400, "invalid folder name"); return; }
    if (!fs_path_is_safe(rel))    { whb_send_error(req, 400, "invalid path"); return; }

    char newrel[128];
    if (fs_make_subdir(mount, rel, name, newrel, sizeof(newrel)) != 0) {
        whb_send_error(req, 400, "could not create the folder (name too long or not writable)");
        return;
    }

    sb_t sb;
    sb_init(&sb);
    sb_puts(&sb, "{\"path\":");
    sb_json_str(&sb, newrel);
    sb_puts(&sb, "}");
    whb_send_sb(req, 200, &sb);
}

/* Where files can go: the drives that are plugged in and the console's own
   storage - what a page offers before it opens the folder picker. */
static void handle_drives(whb_req_t *req)
{
    target_entry_t list[TARGET_SCAN_MAX];
    int count = target_scan(list, TARGET_SCAN_MAX);

    sb_t sb;
    sb_init(&sb);
    sb_puts(&sb, "{\"drives\":[");
    for (int i = 0; i < count; i++) {
        sb_puts(&sb, i ? ",{\"mount\":" : "{\"mount\":");
        sb_json_str(&sb, list[i].mount);
        sb_puts(&sb, ",\"fs\":");
        sb_json_str(&sb, list[i].fs);
        sb_printf(&sb, ",\"writable\":%s,\"internal\":%s,\"totalBytes\":%llu,\"freeBytes\":%llu}",
                  list[i].writable ? "true" : "false", list[i].internal ? "true" : "false",
                  (unsigned long long)list[i].total_bytes, (unsigned long long)list[i].free_bytes);
    }
    sb_puts(&sb, "]}");
    whb_send_sb(req, 200, &sb);
}

/* What the page's poll needs and every app can give: the live console's feed
   and whether work is going on. An app with more to tell has a status route
   of its own, keeps "log" and "busy" in it and points the page there
   (whb.app.statusPath) - one question a second instead of two. The next copy
   of the payload asks this one, whatever the app. */
static void handle_status(whb_req_t *req)
{
    sb_t sb;
    sb_init(&sb);
    sb_puts(&sb, "{\"log\":");
    json_log(&sb, (unsigned)whb_param_int(req, "since", 0));
    sb_printf(&sb, ",\"busy\":%s}", whb_busy() ? "true" : "false");
    whb_send_sb(req, 200, &sb);
}

/* The tile is put on the home screen, and kept current, at start - when the
   app registered the home_tile setting and it is on. It goes through the
   app-install service, so it waits until the server is up and runs beside
   it; a console that takes the install badly cannot keep the payload from
   answering. */
static void *auto_tile_thread(void *arg)
{
    int port = (int)(intptr_t)arg;
    char err[160];
    if (tile_install(port, err, sizeof(err)) != 0)
        write_log(g_log_path, "Tile: automatic install failed - %s (switch home_tile off to stop trying)", err);
    return NULL;
}

static void on_listening(int port)
{
    if (!whb_app()->tile_title_id || tile_is_current(port)) return;

    if (!whb_config_int("home_tile", 0)) {
        if (tile_exists())
            write_log(g_log_path, "Tile: the home-screen shortcut is out of date - "
                                  "update it under Menu > Settings");
        return;
    }

    write_log(g_log_path, "Tile: %s the home-screen shortcut", tile_exists() ? "updating" : "installing");
    pthread_t tid;
    pthread_attr_t attr;
    pthread_attr_init(&attr);
    pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);
    pthread_create(&tid, &attr, auto_tile_thread, (void *)(intptr_t)port);
    pthread_attr_destroy(&attr);
}

void whb_routes_init(void)
{
    http_on_listening(on_listening);
    whb_config_routes_init();
    whb_access_routes_init();

    whb_route("GET",  "/",                     handle_index);
    whb_route("GET",  "/index.html",           handle_index);
    whb_route("GET",  "/cache.appcache",       handle_manifest);
    whb_route("GET",  "/icon.png",             handle_app_icon);
    whb_route("GET",  "/apple-touch-icon.png", handle_app_icon);
    whb_route("GET",  "/apple-touch-icon-precomposed.png", handle_app_icon);
    whb_route("GET",  "/app.webmanifest",      handle_web_manifest);
    whb_route("GET",  WHB_API "/status",           handle_status);
    whb_route("GET",  WHB_API "/self",             handle_self);
    whb_route("GET",  WHB_API "/self/compare",     handle_self_compare);
    whb_route("POST", WHB_API "/self/store",       handle_self_store);
    whb_route("GET",  WHB_API "/tile",             handle_tile_state);
    whb_route("POST", WHB_API "/tile",             handle_install_tile);
    whb_route("POST", WHB_API "/tile/remove",      handle_remove_tile);
    whb_route("GET",  WHB_API "/qr",               handle_qr);
    whb_route("GET",  WHB_API "/drives",           handle_drives);
    whb_route("GET",  WHB_API "/browse",           handle_browse);
    whb_route("POST", WHB_API "/mkdir",            handle_mkdir);
    whb_route("POST", WHB_API "/quit",             handle_quit);
}

int whb_serve(int port)
{
    whb_routes_init();
    return http_server_run(port ? port : whb_config_int("web_port", whb_app()->default_port));
}
